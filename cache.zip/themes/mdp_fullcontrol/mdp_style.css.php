<?php
        	/***HEADER***/
			//background header
			$cor = "background:linear-gradient(to left, {$custom_background} 0%, {$custom_background} 50%, {$custom_rodape} 100%);";
			//class header
			$classcolor = "gradient";
			/***MENU***/
			//class menu
			$classmenu ="link transition radius";
			//cor menu
			$cormenu = "background:linear-gradient(to left, {$custom_btn} 0%, {$custom_background} 50%, {$custom_btn} 100%);";
			
			//Cor menu hover
			$cormenuh =  "background:linear-gradient(to left, {$custom_btn_hover} 0%, {$custom_background} 50%, {$custom_btn_hover} 100%);"; 
			//font menu
			$fontmenu = (isset($custom_color) ? $custom_color : '');  
			$fontmenuh = (isset($custom_btn_hover) ? $custom_btn_hover : '');  
			
			/***SUB MENU***/
			//class sub menu
			$classsubmenu ="sub";
			//cor menu
			$corsubmenu =  "background:linear-gradient(to left, {$custom_btn_hover} 0%, {$custom_background} 50%, {$custom_btn_hover} 100%);"; 
		  
			//Cor menu hover
			$corsubmenuh = "background:linear-gradient(to left, {$custom_btn_hover} 0%, {$custom_background} 50%, {$custom_btn_hover} 100%);"; 
			//font menu
			$fontsubmenu = (isset($custom_color) ? $custom_color : '');  
			$fontsubmenuh = (isset($custom_color) ? $custom_color : '');  
			/***LOGIN***/
			//cor menu login admin
			$corloginadm = "border: solid 3px {$custom_btn}; background:linear-gradient(to right, {$custom_color} 0%, {$custom_color} 50%, {$custom_color} 100%);";
			$rodape = (isset($custom_rodape) ? $custom_rodape : '');
?>
<style>
.main_header_nav_links a,.main_header_nav_links li a{
<?= $fontmenu;?>

}
.main_header_nav_links {
	 <?= $cormenu;?>
		 <?= $fontmenu;?>
	 border:none;
	 
}
.main_header_nav_links .link:hover {
	 <?= $cormenuh;?>
		 color:<?= $fontmenuh;?>;
	 border:none;
}
			
		

.main_header_nav .sub li a:hover{
	  <?= $corsubmenuh;?>
	   color: <?= $fontsubmenuh;?>;
}

@media (max-width: 62em) {

	.main_header_nav_mobile {
		display: block;
		font-size: var(--font-medium);
		cursor: pointer;
		padding: 4px 8px;
		 <?= $cormenuh;?>
		 <?= $fontmenuh;?>
	}

	.main_header_nav_mobile:hover {
	  <?= $cormenu;?>
		 <?= $fontmenu;?>
	}
	.main_header_nav_links{background:#000!important;}
}

.main_header_nav_links{background:<?= $custom_background;?>!important;}
</style>		
		    			
			
         
<style>
   

/* MAIN HEADER */
.main_header {
    padding: 15px 0;
    color: #ffffff;
}

.main_header .container {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

/*logo*/
.main_header_logo h1 a {
    font-weight: var(--weight-normal);
    color: #ffffff;
    text-decoration: none;
    text-shadow: 1px 1px 0 rgba(0, 0, 0, 0.5);
}

/*nav*/
.main_header_nav {
    display: flex;
    align-items: center;
}

.main_header_nav_links {
    display: block !important;
}

.main_header_nav_links .link {
    display: inline-block;
    padding: 6px 12px;

    text-decoration: none;
    text-transform: uppercase;
    color: var(--gradient-green);
    font-weight: var(--weight-bold);
    font-size: var(--font-small);
    
   
}
/*
.main_header_nav_links li .link:hover,
.main_header_nav_links .link:hover {
     background-image: var(--gradient-green);
	 color:#fff!important;
	 border:none;
}
*/
.main_header_nav_links .login {
    background: var(--gradient-blue);
		 color:#fff!important;

}
.main_header{
    background: #1586fc;
    padding: 25px 0;
}

.main_header header{
    float: left;
    text-align: center;
    color: #fff;
}

.main_header header h1{
    font-size: 1.8em;
}

.main_header_nav{
    float: right;
}

.main_header_nav ul{
    margin-top: 10px;
    display: block;
    width: 100%;
}

.main_header_nav li{
    display: inline-block;
    position: relative;
}

.main_header_nav li a{
    display: inline-block;
    padding: 10px;
    color: #fff;
    text-decoration: none;
}
.main_header_nav li:hover,
.main_header_nav li a:hover{
  border_bottom:solid 3px var(--gradient-green)!important;
  color:#fff!important;
  
}

.main_header_nav li:hover .sub,
.main_header_nav li a:hover .sub{
    display: block;
}


.main_header_nav .sub{
    display: none;
    z-index: 99;
    position: absolute;
    width: 210px;
    background: linear-gradient(to right, #000 0%, #36373c 50%, #000 100%);
    margin: 0;
    font-size:0.9em;
}

.main_header_nav .sub li,
.main_header_nav .sub li a{
    color: var(--color-green);
    display: block;
    width: 100%;
    margin: 10px 0;
}
/*
.main_header_nav .sub li a:hover{
   background-image: var(--gradient-green);
    color: #fff;
}
*/
/*mobile*/
.main_header_nav_mobile,
.main_header_nav_mobile_close {
    display: none;
}

/*CONTENT*/

/*home featured*/
.home_featured {
    position: relative;
    background: rgba(0, 0, 0, 0.5);
    color: #ffffff;
}

.home_featured:after {
    content: "";
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    position: absolute;
    z-index: var(--index-back);
    
    background-size: cover;
    background-attachment: fixed;
}

.home_featured_content {
    padding: 80px 0 0 0;
}

.home_featured_header {
    width: 760px;
    max-width: 100%;
    margin: 0 auto;
    text-align: center;
}

.home_featured_header h1 {
    font-size: 3em;
    font-weight: var(--weight-bold);
    text-shadow: 0 1px 1px rgba(0, 0, 0, 0.8);
}

.home_featured_header p {
    margin: 30px 0 50px 0;
    font-weight: var(--weight-normal);
    font-size: var(--font-medium);
}

.home_featured_header .features {
    font-size: var(--font-small);
    text-transform: uppercase;
    letter-spacing: 2px;
}

.home_featured_btn {
    cursor: pointer;
    display: inline-block;
    padding: 30px;
    text-transform: uppercase;
    font-weight: var(--weight-black);
    text-shadow: 0 1px 1px rgba(0, 0, 0, 0.5);
}

.home_featured_app {
    text-align: center;
    display: block;
    margin: 10px auto;
    position: relative;
    z-index: var(--index-fold);
}

.home_featured_app img {
    max-width: 90%;
    -webkit-border-radius: var(--radius-medium);
    -moz-border-radius: var(--radius-medium);
    border-radius: var(--radius-medium);
    -webkit-box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5);
    -moz-box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5);
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5);
}

.home_featured_app:after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 50%;
    background: #ffffff;
    z-index: var(--index-back);
}

/*home features*/
.home_features_header {
    text-align: center;
    margin: 20px 0 40px 0;
    color: #555555;
}

.home_features_header p {
    margin-top: 10px;
}

.home_features_content {
    display: flex;
	 flex-wrap: wrap;
	
}

.home_features_content article {
   border-top: 3px solid #eee;
    -webkit-box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.3);
    -moz-box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.3);
    box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.3);
    flex-basis: calc(33.33% - 20px);
    margin: 10px!important;
    padding: 30px;
    text-align: center;
}

.home_features_content article.active,
.home_features_content article:hover {
    border-top: 3px solid var(--color-green);
    -webkit-box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.3);
    -moz-box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.3);
    box-shadow: 0 4px 4px 0 var(--color-green);
}

.home_features_content article img {
    width: 90%;
}

.home_features_content article h3 {
    margin: 20px 0 10px 0;
    font-size: var(--font-medium);
    font-weight: var(--weight-normal);
}

.home_features_content article p {
    font-size: var(--font-small);
}

/*optin*/
.home_optin {
    background: #FBFBFB;
}

.home_optin_content {
    display: flex;
    align-items: flex-start;
    color: #555555;
}

.home_optin_content_flex {
    flex-basis: 50%;
    padding: 20px;
}

.home_optin_content_flex .icon {
    display: block;
    text-align: center;
    font-size: 5em;
    color: var(--hover-color-green);
}

.home_optin_content header h2 {
    margin-top: 10px;
    font-size: 2em;
    font-weight: var(--weight-bold);
}

.home_optin_content header p {
    margin-top: 30px;
    font-size: var(--font-medium);
}

.home_optin_content h4 {
    font-size: var(--font-medium);
    text-align: center;
    margin-bottom: 30px;
}

.home_optin_content form input {
    display: block;
    width: 100%;
    font-size: var(--font-small);
    padding: 15px;
    margin-bottom: 15px;
    border: 1px solid #cccccc;
    -webkit-border-radius: var(--radius-normal);
    -moz-border-radius: var(--radius-normal);
    border-radius: var(--radius-normal);
}

.home_optin_content form button {
    cursor: pointer;
    border: none;
    display: block;
    width: 100%;
    text-align: center;
    padding: 20px;
    font-size: var(--font-medium);
    font-weight: var(--weight-black);
    color: #ffffff;
    text-shadow: 0 1px 1px rgba(0, 0, 0, 0.5);
}

/*BLOG*/
.blog_content {
    padding-bottom: 0;
}

.blog_header {
    text-align: center;
    margin-bottom: 30px;
    color: #555555;
}

.blog_header h2 {
    font-size: 2em;
    font-weight: var(--weight-light);
}

.blog_header p {
    margin-top: 10px;
}

.blog_articles {
    display: flex;
    flex-wrap: wrap;
}

.blog_article {
    flex-basis: calc(33.33% - 40px);
    margin: 20px;
    color: #555555;
}

.blog_article img {
    -webkit-border-radius: var(--radius-medium);
    -moz-border-radius: var(--radius-medium);
    border-radius: var(--radius-medium);
    border-bottom: 3px solid #E9E9E9;
}

.blog_article:hover img {
    border-color: var(--color-green);
}

.blog_article h2 {
    font-size: var(--font-medium);
    font-weight: var(--weight-bold);
}

.blog_article .meta {
    font-size: var(--font-small);
    font-weight: var(--weight-light);
}

.blog_article p {
    font-size: var(--font-small);
    margin: 20px 0;
}

.blog_article a {
    text-decoration: none;
    color: #555555;
}

.blog_article a:hover {
    text-decoration: underline;
}

/*video*/
.home_video {
    position: relative;
    background: rgba(0, 0, 0, 0.5);
}

.home_video:after {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    background: url("images/home-featured.jpg") top center;
    background-size: cover;
    background-attachment: fixed;
    z-index: var(--index-back);
}

.home_video_content {
    color: #ffffff;
    text-align: center;
    padding: 80px 0;
}

.home_video_content h2 {
    font-weight: var(--weight-light);
    font-size: 2em;
}

.home_video_content span {
    cursor: pointer;
    font-size: 6em;
    margin-top: 15px;
    text-shadow: 0 4px 4px rgba(0, 0, 0, 0.8);
}

.home_video_content span:hover {
    color: var(--hover-color-green);
}

.home_video_modal {
    position: fixed;
    display: none;
    background: rgba(0, 0, 0, 0.5);
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    z-index: var(--index-modal);
}

.home_video_modal_box {
    margin: auto;
    width: 800px;
    max-width: 90%;
}

/*opt out*/
.footer_optout {
    background: url("images/footer-bg.jpg") top center no-repeat;
    background-size: cover;
    padding-top: 20px;
    margin-top: 40px;
}

.footer_optout_content {
    text-align: center;
    width: 500px;
    max-width: 100%;
    margin: 0 auto;
    padding: 20px 0;
}

.footer_optout .icon {
    font-size: 5em;
    color: #555555;
}

.footer_optout h2 {
    font-size: 2em;
    font-weight: var(--weight-black);
    color: #555555;
}

.footer_optout p {
    margin: 20px 0 40px;
}

.footer_optout_btn {
    display: inline-block;
    cursor: pointer;
    padding: 15px 40px;
    font-size: var(--font-medium);
    color: #ffffff;
    font-weight: var(--weight-black);
    text-shadow: 0 1px 1px rgba(0, 0, 0, 0.5);
    text-decoration: none;
}

/*MAIN FOOTER*/
.main_footer {
    background:var(--gradient-green);
}

.main_footer_content {
    display: flex;
}

.main_footer_content article {
    flex-basis: 25%;
    padding: 20px;
    color: #fff
}

.main_footer_content article h2 {
    font-size: var(--font-medium);
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid #cccccc;
}

.main_footer_content article p,
.main_footer_content article a {
    font-size: var(--font-small);
    display: block;
    margin-top: 10px;
}

.main_footer_content article a {
    color: #ffffff;
    font-weight: var(--weight-bold);
    text-decoration: none;
    transition-duration: var(--hover-duration);
}

.main_footer_content article a:hover {
    color: var(--hover-color-green);
}

.main_footer_content article a:before {
    color: #ffffff;
    background-image: var(--gradient-green);
    background-size: 200%;
    padding: 6px;
    -webkit-border-radius: var(--radius-round);
    -moz-border-radius: var(--radius-round);
    border-radius: var(--radius-round);
    transition-duration: var(--hover-duration);
}

.main_footer_content article a:hover:before {
    background-position: right center;
}

.main_footer_content .social a {
    display: block;
    margin-bottom: 20px;
}

/*NOT FOUND PAGE 404*/
.not_found {
    text-align: center;
    color: #fff;
}

.not_found .error {
    font-size: 8em;
    font-weight: var(--weight-light);
    color: #cccccc;
}

.not_found_header {
    width: 500px;
    max-width: 100%;
    margin: 0 auto;
}

.not_found_btn {
    display: inline-block;
    margin-top: 30px;
    padding: 20px 40px;
    color: #ffffff;
    text-decoration: none;
    font-weight: var(--weight-bold);
}

/*ABOUT PAGE*/
.about_header {
    text-align: center;
    width: 800px;
    max-width: 100%!important;
    margin: 0 auto 40px auto;
    color: #555555;
}

.about_header h1 {
    font-size: 2em;
    font-weight: var(--weight-light);
}

.about_page_steps {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.about_page_steps article {
    flex-basis: calc(33.33% - 40px);
    margin: 20px;
    text-align: center;
    padding: 30px;
    color: #555555;
}

.about_page_steps article .icon {
    display: inline-block;
    padding: 15px 20px;
    background: var(--gradient-green);
    font-size: 2em;
    color: #ffffff;
    -webkit-border-radius: var(--radius-medium);
    -moz-border-radius: var(--radius-medium);
    border-radius: var(--radius-medium);
    background-size: 200%;
}

.about_page_steps article h3 {
    margin: 20px 0 0 0;
    font-size: var(--font-medium);
    font-weight: var(--weight-normal);
}

.about_page_steps article p {
    line-height: 1.4;
    margin-top: 15px;
}

/*media*/
.about_page_media {
    position: relative;

}

.about_page_media:after {
    content: "";
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 60%;
		max-width:500px;

    background-size: 100%;
    z-index: var(--index-back);
}

.about_media_video {
    width: 860px;
    max-width: 90%!important;
    margin: 0 auto;
    -webkit-border-radius: var(--radius-medium);
    -moz-border-radius: var(--radius-medium);
    border-radius: var(--radius-medium);
    overflow: hidden;
    -webkit-box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5);
    -moz-box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5);
    box-shadow: inset 0 2px 4px 0 rgba(0, 0, 0, 0.5);
}

/*cta*/
.about_page_cta {
    background: linear-gradient(to right, #000 0%, #36373c 50%, #000 100%);
    background-size: 100%;
	border-top:2px solid #36373c;
    text-align: center;
}

.about_page_cta_content {
    width: 600px;
    max-width: 100%;
}

.about_page_cta_content p {
    margin: 20px 0;
}

.about_page_cta_btn {
    display: inline-block;
    padding: 20px 40px;
    background: var(--hover-color-green);
    cursor: pointer;
    font-size: var(--font-medium);
    font-weight: var(--weight-black);
    color: #ffffff;
    text-shadow: 1px 1px 0 rgba(0, 0, 0, 0.5);
    margin-top: 20px;
    text-decoration: none;
}

.about_page_cta_btn:hover {
    background: var(--color-green);
}

/*faq*/
.faq_header {
    text-align: center;
    margin-bottom: 30px;
}

.faq_header h3 {
    font-size: 2em;
    font-weight: var(--weight-light);
    margin-bottom: 20px;
}

.faq_asks {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-start;
    justify-content: center;
}

.faq_ask {
    flex-basis: calc(50% - 30px);
    cursor: pointer;
    padding: 20px;
    margin: 15px;
    border: 1px solid #cccccc;
    border-bottom: 3px solid var(--color-green);
    color: var(--color-default);
    -webkit-border-radius: var(--radius-medium);
    -moz-border-radius: var(--radius-medium);
    border-radius: var(--radius-medium);
}

.faq_ask h4 {
    font-size: var(--font-medium);
    font-weight: var(--weight-bold);
}

.faq_ask p {
    font-size: var(--font-small);
}

.faq_ask_coll {
    display: none;
}

/*BLOG PAGE*/
.blog_page_header {
    text-align: center;
    padding: 40px;
    background: linear-gradient(to right, #000 0%, #36373c 50%, #000 100%) ;
    background-size: 200%;
}

.blog_page_header h1 {
    font-size: 3em;
    color: rgba(0, 0, 0, 0.4);
}

.blog_page_header p {
    margin: 10px 0 30px 0;
}

.blog_page_header form {
    display: inline-block;
    width: 400px;
    max-width: 100%;
}

.blog_page_header form label {
    display: flex;
    align-items: center;
    background: #ffffff;
    justify-content: center;
    -webkit-border-radius: var(--radius-large);
    -moz-border-radius: var(--radius-large);
    border-radius: var(--radius-large);
    overflow: hidden;
}

.blog_page_header form input {
    flex-basis: 100%;
    padding: 12px 12px 12px 20px;
    font-size: var(--font-normal);
    border: none;
    background: #ffffff;
    outline: none;
    color: #555555;
}

.blog_page_header form button {
    padding: 0 20px 0 0;
    font-size: var(--font-medium);
    border: none;
    cursor: pointer;
    outline: none;
    color: #555555;
}

/*POST PAGE*/
.post_page_hero {
    width: 860px;
    max-width: 90%;
    margin: 0 auto;
    padding: 40px 0;
}

.post_page_header {
    position: relative;
    text-align: center;
}

.post_page_header h1 {
    font-size: 2.4em;
    font-weight: var(--weight-normal);
    margin: 30px 0;
    color: #FBFBFB;
    text-shadow: 1px 1px 0 rgba(0, 0, 0, 0.3);
}

.post_page_header:after {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 70%;
    background: linear-gradient(to left,#000,#282828,#000);
    background-size: 200%;
    z-index: var(--index-back);
}

.post_page_cover {
    -webkit-border-radius: var(--radius-medium);
    -moz-border-radius: var(--radius-medium);
    border-radius: var(--radius-medium);
    border-bottom: 3px solid var(--color-green);
}

.post_page_content {
    width: 860px;
    max-width: 90%;
    margin: 0 auto;
}

.post_page_meta {
    display: flex;
    align-items: center;
    margin-top: 20px;
    justify-content: space-between;
    color: #555555;
}

.post_page_meta .author {
    display: flex;
    align-items: center;
}

.post_page_meta .author .name {
    padding-left: 10px;
}

.post_page_meta .author img {
    width: 40px;
    -webkit-border-radius: var(--radius-round);
    -moz-border-radius: var(--radius-round);
    border-radius: var(--radius-round);
}

.post_page_related.content {
    padding-bottom: 0;
}

.post_page_related_header {
    text-align: center;
    color: #555555;
    margin-bottom: 30px;
}

.post_page_related header h4 {
    font-size: 3em;
    font-weight: var(--weight-light);
}

.post_page_related header p {
    margin-top: 10px;
    font-size: var(--font-small);
}

/*AUTH IN*/
.auth_content {
    color: #555555;
}

.auth_content a {
    font-weight: var(--weight-bold);
    color: var(--color-green);
    text-decoration: none;
    transition: var(--hover-duration);
}

.auth_content a:hover {
    color: var(--hover-color-green);
}

.auth_header {
    text-align: center;
    margin-bottom: 50px;
}

.auth_header h1 {
    font-size: 2.4em;
    font-weight: var(--weight-light);
}

.auth_form {
    width: 500px;
    max-width: 100%;
    margin: 0 auto;
}

.auth_form label {
    display: block;
    margin-top: 30px;
}

.auth_form label div {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
    justify-content: space-between;
    font-size: var(--font-small);
    font-weight: var(--weight-bold);
}

.auth_form label input {
    color: #555555;
    display: block;
    width: 100%;
    font-size: var(--font-normal);
    padding: 15px 20px;
    outline: none;
    border: 1px solid #cccccc;
    border-radius: var(--radius-medium);
    -webkit-border-radius: var(--radius-medium);
    -moz-border-radius: var(--radius-medium);
}

.auth_form .check {
    cursor: pointer;
    display: flex;
    align-items: center;
    margin: 20px 0 30px 0;
    font-size: var(--font-small);
    transition: var(--hover-duration);
}

.auth_form .check:hover {
    color: #000000;
}

.auth_form .check input {
    width: auto;
    font-size: var(--font-large);
    margin-right: 10px;
    display: inline-block;
}

.auth_form_btn {
    display: block;
    width: 100%;
    border: none;
    padding: 15px;
    font-size: var(--font-medium);
    color: #ffffff;
    font-weight: var(--weight-black);
    cursor: pointer;
    -webkit-border-radius: var(--radius-medium);
    -moz-border-radius: var(--radius-medium);
    border-radius: var(--radius-medium);
    margin-top: 30px;
}

/*TERMS PAGE*/
.terms_page_header {
    text-align: center;
    padding: 50px 40px;
    background: var(--gradient-green);
    background-size: 200%;
    color: #ffffff;
}

.terms_page_header h1 {
    font-size: 2em;
    font-weight: var(--weight-bold);
    text-shadow: 1px 1px 0 rgba(0, 0, 0, 0.4);
}

.terms_page_header p {
    margin-top: 10px;
    font-weight: var(--weight-black);
    color: rgba(0, 0, 0, 0.4);
}

.terms_page_content {
    width: 800px;
    margin: 0 auto;
    padding: 60px 0 0 0;
}

/*OPTIN PAGES*/
.optin_page {

}

.optin_page_content {
    width: 800px;
    max-width: 100%;
    margin: 0 auto;
    color: var(--color-default);
    text-align: center;
}

.optin_page_content img {
    width: 400px;
    max-width: 100%;
}

.optin_page_content h1 {
    font-size: 2.3em;
    font-weight: var(--weight-bold);
}

.optin_page_content p {
    margin: 20px 0;
    font-size: 1.1em;
}

.optin_page_btn {
    display: inline-block;
    padding: 20px 40px;
    margin-top: 20px;
    color: #ffffff;
    font-weight: var(--weight-bold);
    text-decoration: none;
    font-size: 1.4em;
}

@media (max-width: 62em) {
    .main_header_logo {
        font-size: 0.8em;
    }

    .main_header_nav {
        text-align: center;

        
    }
	
.main_header_nav li,.sub{
    display:block;
	width:100%;
	color:#fff;
	
	
}

.main_header_nav li:hover .sub,
.main_header_nav li a:hover .sub{
    display: block;
	width:100%;
	margin:0!important;
	padding:0!important;
	margin-top:100px;
	 background: var(--gradient-blue);
	 border:1px solid #1584f7;
}

    .main_header_nav_mobile {
        display: block;
        font-size: var(--font-medium);
        cursor: pointer;
        padding: 4px 8px;
        background-image: var(--gradient-green);
		color:#ffff!important;
		border:2px solid #fff;
    }

    .main_header_nav_mobile:hover {
       background-image: var(--gradient-blue);
		color:#ffff!important;
    }

    .main_header_nav_mobile_close {
        cursor: pointer;
        display: block;
        padding: 10px;
        color: var(--color-red);
        font-size: 2em;
    }

    .main_header_nav_mobile_close:hover {
        color: var(--hover-color-red);
    }

    .main_header_nav_links {
        display: none;
        position: fixed;
        z-index: var(--index-menu);
        left: 100%;
        top: 0;
        	 background:#000;
        width: 300px;
        height: 100%;
        max-width: 80%;
        padding: 20px;
        border-left: 1px solid #E9E9E9;
    }

    .main_header_nav_links .login,
    .main_header_nav_links .link {
   
        display: block;
        color: #555555;
        padding: 10px;
        transition-duration: 0s;
        
    }
.main_header_nav_links .login{background-image: var(--gradient-green);}
    .main_header_nav_links .link:hover {
        color: #ffffff;
        background-image: var(--gradient-green);
    }

    .main_footer_content {
        flex-wrap: wrap;
        text-align: center;
    }

    .main_footer_content article {
        flex-basis: 50%;
    }

    .blog_article {
        flex-basis: calc(50% - 40px);
    }

    .faq_ask {
        flex-basis: 100%;
        margin: 20px 0 0 0;
    }
	.about_page_media:after {
		max-width:400px;

   
}
.wc_form{
    margin:20px 0;
}
}

@media (max-width: 52em) {
    .htmlchars{
        width:100%;
    }
    .home_featured_header {
        font-size: 0.8em;
    }

    .home_features_content {
        flex-wrap: wrap;
    }

    .home_features_content article {
        flex-basis: 100%;
    }

    .home_optin_content {
        flex-wrap: wrap;
        text-align: center;
    }

    .home_optin_content_flex {
        flex-basis: 100%;
    }

    .about_page_steps article {
        flex-basis: 100%;
        margin: 20px 0 0 0;
    }

    .post_page_meta {
        display: none;
    }

    .social_share {
        flex-wrap: wrap;
        justify-content: center;
    }

    .social_share_title {
        flex-basis: 100%;
        text-align: center;
        margin-bottom: 20px;
    }

    .post_page_header h1 {
        font-size: 1.8em;
    }

    .post_page_hero {
        padding: 10px 0 0 0;
    }
	.about_page_media:after {
		max-width:300px;

   
}
.wc_form{
    margin:20px 0;
}
}

@media (max-width: 32em) {
    .main_footer_content article {
        flex-basis: 100%;
    }

    .blog_article {
        text-align: center;
        flex-basis: calc(100% - 40px);
    }

    .optin_page_content h1 {
        font-size: 1.8em;
    }
	.about_page_media:after {
		max-width:300px;

   
}
.wc_form{
    margin:20px 0;
}

.btnmob{width:100%!important;float:left;min-width:400px;margin:5px!important}
}
.btnmob{min-width:100%;}
    
    
        .wc_ead_course_module{
    padding-top: 30px;
}

.wc_ead_course_module .module_header{
    margin: 0 0 20px 0;
    border-bottom: 1px solid #ccc;
    line-height: 0;
}

.wc_ead_course_module .module_header h1{
    font-size: 1.6em;
    font-weight: 500;
    color: #555;
    line-height: 1;
    margin-bottom: 5px;
}

.wc_ead_course_module .module_header p{
    font-size: 0.8em;
    color: #888;
    line-height: 1.2;
}

.wc_ead_course_module .module_header span{
    font-size: 0.4em;
}

.wc_ead_course_module_bar{
    display: inline-block;
    width: 40%;
    background: #fff;
    height: 5px;
    margin-top: 15px;
}


/*TOOLTIP*/

.wc_tooltip{

    display: inline-block;

    vertical-align: top;

    position: relative;

}



.wc_tooltip:hover .wc_tooltip_balloon{

    display: inline;

}



.wc_tooltip_balloon{

    display: none;

    position: absolute;

    left: 50%;

    margin-left: -100px;

    bottom: 100%;

    margin-bottom: 10px;

    font-weight: 500;

    width: 200px;

    padding: 15px;

    background: #000;

    opacity: 0.9;

    z-index: 99;

    color: #fff;

    font-size: 0.75rem;

    text-align: center;

    border-radius: 4px;

    -moz-border-radius: 4px;

    -webkit-border-radius: 4px;

    text-shadow: none !important;

}



.wc_tooltip_balloon::after {

    content: '';

    position: absolute;

    top: 100%;

    left: 50%;

    margin-left: -8px;

    width: 0;

    height: 0;

    border-top: 8px solid #000000;

    border-right: 8px solid transparent;

    border-left: 8px solid transparent;

}

  .wc_ead_course_module_class{
    display: block;
    width: 100%;
    padding: 5px 15px 10px 15px;
    line-height: 1;

}

.wc_ead_course_module_class h1.row{
    display: inline-block;
    width:55%;
    font-size: 0.875em;
    vertical-align: middle;
    text-align: left;
    font-weight: 300;
    color: #000;
    border: none;
    margin-top:10px;
}

.wc_ead_course_module_class .row{
    display: inline-block;
    width: 12%;
    font-size: 0.8em;
    vertical-align: middle;
    text-align: center;
    border-left: 1px dotted #ccc;
    font-weight: 300;
    color: #555;
}

.wc_ead_course_module_class a{
    color: #000;
    text-decoration: none;
    font-weight: 500;
}

.wc_ead_course_module_class a:hover{
    text-decoration: underline;
}
.rounded{
    border-radius: 50% !important;
    -moz-border-radius: 50% 50% !important;
    -webkit-border-radius: 50% 50% !important;

}
.black{background:#f5f5f5!important;color:#fff;}
.branco{background:#fff!important;}
</style>
</style>