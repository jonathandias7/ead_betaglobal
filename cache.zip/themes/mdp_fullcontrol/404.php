<!--404-->
<article class="not_found">
    <div class="container content">
        <header class="not_found_header">
            <p class="error">404</p>
            <h1>Ooops. Essa página não existe :/</h1>
            <p>Sentimos muito, mas o conteúdo que você tentou acessar não existe, está indisponível ou foi removido
                :/</p>
            <a class="not_found_btn gradient gradient-green gradient-hover transition radius" title="home" href="./">Continue
                navegando</a>
        </header>
    </div>
</article>

<!--OPT OUT-->
<?php require __DIR__ . "/optout.php"; ?>