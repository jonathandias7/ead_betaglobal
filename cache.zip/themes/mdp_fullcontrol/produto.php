
<style>

/*PRODUCT STORE*/
.produtct_basics_cover{
    float: left;
    width: 35%;
    position: relative;
}

.produtct_basics_cover_offer{
    position: absolute;
    top: 50px;
    left: 0;
    text-align: right;
    color: #fff;
    width: 50%;
    padding: 10px 20px;
    background: #769977;
    font-size: 0.8em;
}

.produtct_basics_cover_stock{
    position: absolute;
    top: 50px;
    left: 0;
    text-align: right;
    color: #fff;
    width: 45%;
    padding: 10px 20px;
    background: #d6a6a6;
    font-size: 0.8em;
}

.produtct_basics_cover_ident{
    top: 88px;
}

.produtct_basics_cover ul{
    display: block;
    width: 100%;
    padding-top: 10px;
    background: #fff;
}

.produtct_basics_cover li{
    display: inline-block;
    width: 20%;
    margin-bottom: 15px;
}

.produtct_basics_infor{
    float: right;
    width: 65%;
    padding-left: 5%;
}

.produtct_basics_infor .info{
    padding: 25px 0;
    margin-bottom: 30px;
    border-bottom: 1px solid #eee;
    font-size: 0.875em;
    color: #555;
}

.produtct_basics_infor .info p{
    margin-bottom: 3px;
}

.produtct_basics_infor .info .reviews{
    margin: 10px 0 20px 0;
    font-size: 0.9em;
    text-transform: uppercase;
    color: #888;
}

.produtct_basics_infor header h1{
    font-size: 1.8em;
    font-weight: 500;
    margin-bottom: 10px;
}

.produtct_basics_infor header p{
    font-size: 0.8em;
}

.produtct_basics_infor .info .price{
    font-size: 1.7em;
}

.produtct_basics_infor .info .price strike{
    font-weight: 300;
    color: #d6a6a6;
    font-size: 0.8em;
    margin-left: 10px;
}

.produtct_basics_infor .price_split{
    font-size: 0.5em;
    color: #888;
}

.produtct_basics_infor form{
    display: block;
    width: 100%;
    vertical-align: bottom;
}

.produtct_basics_infor a{
    text-decoration: none;
    color: #769977;
}

.produtct_basics_infor a:hover{
    color: #5fa961;
    text-decoration: underline;
}

.produtct_infor{
    background: #f2f2f2;
}

.produtct_infor .htmlchars{
    padding: 30px;
    background: #fff;
}

.produtct_more{
    background: #769977;
    text-align: center;
    color: #fff;
}

.produtct_more .content > header{
    margin-bottom: 30px;
}

.produtct_more .content > header h1{
    font-size: 2em;
    font-weight: 300;
}

.produtct_more .content > header p{
    font-size: 0.8em;
    text-transform: uppercase;
    font-weight: 500;
}

.produtct_more .single_pdt{
    background: #fff;
    border: none;
    box-shadow: none;
    color: #ccc;
}

.produtct_reviews .comments{
    font-size: 0.875em;
    background: #fff;
}
</style><?php
$Read->ExeRead(DB_PDT, "WHERE pdt_name = :nm AND pdt_status = 1", "nm={$URL[1]}");
if (!$Read->getResult()):
    header('Location: ' . BASE . "/404.php");
    exit;
else:
    extract($Read->getResult()[0]);
    $CommentKey = $pdt_id;
    $CommentType = 'product';

    $PdtViewUpdate = ['pdt_views' => $pdt_views + 1, 'pdt_lastview' => date('Y-m-d H:i:s')];
    $Update = new Update;
    $Update->ExeUpdate(DB_PDT, $PdtViewUpdate, "WHERE pdt_id = :id", "id={$pdt_id}");

    $Read->FullRead("SELECT brand_name, brand_title FROM " . DB_PDT_BRANDS . " WHERE brand_id = :id", "id={$pdt_brand}");
    $Brand = ($Read->getResult() ? $Read->getResult()[0] : '');

    $Read->FullRead("SELECT cat_name, cat_title FROM " . DB_PDT_CATS . " WHERE cat_id = :id", "id={$pdt_subcategory}");
    $Category = ($Read->getResult() ? $Read->getResult()[0] : '');

    $CommentModerate = (COMMENT_MODERATE ? " AND (status = 1 OR status = 3)" : '');
    $Read->FullRead("SELECT id FROM " . DB_COMMENTS . " WHERE pdt_id = :pid{$CommentModerate}", "pid={$pdt_id}");
    $Aval = $Read->getRowCount();

    $Read->FullRead("SELECT SUM(rank) as total FROM " . DB_COMMENTS . " WHERE pdt_id = :pid{$CommentModerate}", "pid={$pdt_id}");
    $TotalAval = $Read->getResult()[0]['total'];
    $TotalRank = $Aval * 5;
    $getRank = ($TotalAval ? (($TotalAval / $TotalRank) * 50) / 10 : 0);
    $Rank = str_repeat("&starf;", intval($getRank)) . str_repeat("&star;", 5 - intval($getRank));

    if ($pdt_hotlink):
        header("Location: {$pdt_hotlink}");
        exit;
    endif;
endif;
?>
   <?php 
    $imgnone = 'display:block';
     $imgn = '';
   if (!empty($pdt_urlvideo)): 
     $imgn = 'width:100%;text-align:center';
   $imgnone = 'display:none';?>
    <aside style='padding-top:100px;padding-bottom:100px;' class="about_page_cta">
	<header style='color:#fff;'class="blog_header"><meta charset="euc-jp">
            <h2><b>ASSISTA AO VIDEO SOBRE  <?= $pdt_title;?></b></h2>
            <p style=''><b>Assistir ao video demonstrativo sobre <?= $pdt_title;?> para entender os detalhes.</b></p>
        </header>
	<div class="about_page_media">
        <div class="about_media_video">
            <div class="embed">
               <iframe width="560" height="315" 
			
				
				 src="https://www.youtube-nocookie.com/embed/<?= $pdt_urlvideo?>?rel=0&amp;showinfo=0"  frameborder="0" allow="autoplay; encrypted-media" 
				allowfullscreen></iframe>	
            </div>
            <div class='m_top'>
                 <?php
                    $PdtPrice = null;
                    if ($pdt_offer_price && $pdt_offer_start <= date('Y-m-d H:i:s') && $pdt_offer_end >= date('Y-m-d H:i:s')):
                        $PdtPrice = $pdt_offer_price;
                        echo "R$ " . number_format($pdt_offer_price, '2', ',', '.') . " <strike>R$ " . number_format($pdt_price, '2', ',', '.') . "</strike>";
                    else:
                         
                        $PdtPrice = $pdt_price;
                      
                        echo "<h2 style='padding:2px 5px;max-width:100px;background:#fff;text-shadow:0.5px 0.5px 0.5px #00b594;text-align:right;float:right;font-size:1.1em;color:#00b594;'>R$  " . number_format($pdt_price, '2', ',', '.')."</h2>";
                     
                         
                      
                    endif;?>
             <?php require '_cdn/widgets/ecommerce/cart.add.php'; ?>
             </div>
        </div>
    </div>
        
    </aside>
<?php endif; ?>
<div style='background: #fbfbfb;' class="container produtct_basics" id="mais">
    
    <div class="content">
        <div style="<?=   $imgnone;?>" class="produtct_basics_cover">
            <?php
            $PdtStockeOut = ($pdt_inventory && $pdt_inventory <= 5 ? true : false);

            if ($pdt_offer_price && $pdt_offer_start <= date('Y-m-d H:i:s') && $pdt_offer_end >= date('Y-m-d H:i:s')):
                $PdtDiscount = number_format(100 - ((100 / $pdt_price) * $pdt_offer_price), '0', '', '');
                $PdtIdentBox = (!empty($PdtStockeOut) ? ' produtct_basics_cover_ident' : null);
                echo "<span class='produtct_basics_cover_offer{$PdtIdentBox}'>{$PdtDiscount}% OFF</span>";
            endif;

        
            echo "<img  title='{$pdt_title}' alt='{$pdt_title}' src='" . BASE . "/uploads/{$pdt_cover}'/>";

            $Read->ExeRead(DB_PDT_GALLERY, "WHERE product_id = :id", "id={$pdt_id}");
            if ($Read->getResult()):
                $i = 0;
                echo "<ul>";
                foreach ($Read->getResult() as $PDTIMG):
                    $i++;
                    echo "<li><a rel='shadowbox[img{$pdt_id}]' title='{$pdt_title} - Foto {$i}' href='" . BASE . "/uploads/{$PDTIMG['image']}'><img title='{$pdt_title} - Foto {$i}' alt='{$pdt_title} - Foto {$i}' src='" . BASE . "/tim.php?src=uploads/{$PDTIMG['image']}&w=" . THUMB_W / 3 . "&h=" . THUMB_H / 3 . "'/></a></li>";
                endforeach;
                echo "</ul>";
            endif;
            ?>
            
        </div>
        <div style='<?= $imgn;?>' class="produtct_basics_infor">
            <header>
                <h1><?= $pdt_title; ?></h1>
                <p><?= $pdt_subtitle; ?></p>
            </header>
            <div class="info">
               <div class="price">
                    <?php
                    $PdtPrice = null;
                    if ($pdt_offer_price && $pdt_offer_start <= date('Y-m-d H:i:s') && $pdt_offer_end >= date('Y-m-d H:i:s')):
                        $PdtPrice = $pdt_offer_price;
                        echo "R$ " . number_format($pdt_offer_price, '2', ',', '.') . " <strike>R$ " . number_format($pdt_price, '2', ',', '.') . "</strike>";
                    else:
                         
                        $PdtPrice = $pdt_price;
                        if($PdtPrice < 1):
                        echo "<b style='color:red;'>Download Gratuito </b><br><smal style='font-size:0.7em'> disponivel para data.<b style='color:red;'> ". date('d/m/Y') ."</b></smal><br/>";
                        
                        endif;
                         // echo "R$ " . number_format($pdt_price, '2', ',', '.');
                      
                    endif;
                    
                    if($PdtPrice > 1):

                    //By Wallyson Alemão
                    if (ECOMMERCE_PAY_SPLIT):
                        $MakeSplit = intval($PdtPrice / ECOMMERCE_PAY_SPLIT_MIN);
                        $NumSplit = (!$MakeSplit ? 1 : ($MakeSplit && $MakeSplit <= ECOMMERCE_PAY_SPLIT_NUM ? $MakeSplit : ECOMMERCE_PAY_SPLIT_NUM));
                        if ($NumSplit <= ECOMMERCE_PAY_SPLIT_ACN):
                            $SplitPrice = number_format(($PdtPrice / $NumSplit), '2', ',', '.');
                        elseif ($NumSplit - ECOMMERCE_PAY_SPLIT_ACN == 1):
                            $SplitPrice = number_format(($PdtPrice * (pow(1 + (ECOMMERCE_PAY_SPLIT_ACM / 100), $NumSplit - ECOMMERCE_PAY_SPLIT_ACN)) / $NumSplit), '2', ',', '.');
                        else:
                            $ParcSj = round($PdtPrice / $NumSplit, 2); // Valor das parcelas sem juros
                            $ParcRest = (ECOMMERCE_PAY_SPLIT_ACN > 1 ? $NumSplit - ECOMMERCE_PAY_SPLIT_ACN : $NumSplit);
                            $DiffParc = round(($PdtPrice * getFactor($ParcRest) * $ParcRest) - $PdtPrice, 2);
                            $SplitPrice = number_format($ParcSj + ($DiffParc / $NumSplit), '2', ',', '.');
                        endif;
                       
                    endif;
                    endif;
                    ?>
                   
                </div>
                <?php  if($PdtPrice > 1):?>
                 <style>
		/** TAB **/
			.mdplabel{padding:10px;border:solid 1px #ccc;}	
			.mdplabels{padding:10px;border:solid 1px #ccc}	
			.mdpbtnparcelas{cursor:pointer}
		
		/** Icone mercado Pago **/
		  .mdplogomp{max-width:130px;max-height:70px;}
		
		/** CONTENT PAYMENT **/
	  .mdpcontentparcelas{padding:15px;font-size:1.1em;}
	  
		/** Cards **/
			span.mdpspan {display: inline;width: 150px;height: 100px; padding: 5px;}
       
	   /** Bandeiras **/
		.mdpcard{max-width:70px;max-height:50px;}
		.mdpboleto{max-width:50px;max-height:50px;}
		
		.mdpon{color:#00b594}
		
	  
.mdpparcela{font-size:1em}
	  
	</style>
			<div class='m_top'>
			<div class='al_left label_50 mdplabels'>
				<label>
					<img class='mdplogomp' src='<?= INCLUDE_PATH;?>/images/cards/mp.png'>
				</label>
				<label class='al_right'>
					<p class='mdpbtnparcelas'>Ver Parcelas</p> 
				</label></div>
			<div style='display:none;' class='mdplabel' >
			<div class='mdpcontentparcelas'>
			
			 <?php
				
					for($i=1;$i <= ECOMMERCE_PAY_SPLIT_ACN;$i++):
					
					 $jurostxt = ($i <= ECOMMERCE_PAY_SPLIT_MIN ? " Sem juros " : " Com Juros");
					
					 if($i <= ECOMMERCE_PAY_SPLIT_MIN):
					 $pdtprices = $PdtPrice /$i;
					 else:
					  $jc = ECOMMERCE_PAY_SPLIT_ACM /100;
					 $pdtprices = $PdtPrice *  pow((1 + $jc), $i) / $i;
					 endif;
					$pdtprice = ($pdtprices < 10 ? '0':'');
					$s = ($i < 10 ? '0'.$i : $i);
						 ?>
					
                    <p class="mdpparcela"><b><?= $s; ?></b> x de R$ <b> <?= $pdtprice.  number_format($pdtprices,'2', ',', '.') ;?> </b></p>
			
                    <?php
			
					endfor;
				?>
				</div>
				
			</div>
		
		<div class='al_left mdplabels'>
		<span class='mdpspan'>
		<img class='mdpboleto' src='<?= INCLUDE_PATH;?>/images/boleto/boleto.png'>
		</span>
        <span class='mdpspan'>
					<img class='mdpcard' src='<?= INCLUDE_PATH;?>/images/cards/visa.png'>
				</span>
				<span class='mdpspan'>
					<img class='mdpcard' src='<?= INCLUDE_PATH;?>/images/cards/mastercard.png'>
				</span>
				<span class='mdpspan'>
					<img class='mdpcard' src='<?= INCLUDE_PATH;?>/images/cards/elo.png'>
				</span>
				
				<span class='mdpspan'>
					<img class='mdpcard' src='<?= INCLUDE_PATH;?>/images/cards/hipercard.png'>
				</span>
				
				<span class='mdpspan'>
					<img class='mdpcard' src='<?= INCLUDE_PATH;?>/images/cards/amex.png'>
				</span>
		<span class='mdpspan fl_right'>
		R$ <b> <?= number_format($PdtPrice,'2', ',', '.') ;?> </b> </span></div>
        </div>

		<script>
		
		$('html').on('click','.mdpbtnparcelas',function(){
			if ($(".mdpbtnparcelas").hasClass("mdpon")) {
				$('.mdplabel').css({'display':'none'});
					$('.mdpbtnparcelas').removeClass('mdpon');
				}else{
			$('.mdpbtnparcelas').addClass('mdpon');
			$('.mdplabel').css({'display':'block'});
			
		}
		});
		</script>
		<?php endif;?>
            </div>
            <div  style='<?= $imgn;?>' class="cart">
                
                <?php 
                if($PdtPrice > 1):?>
                
                 <div class='label_50'>
                 <label class='label fl_left'>
              <?php require '_cdn/widgets/ecommerce/cart.add.php'; ?>
              
              </label>
               <label style='' class='label fl_left '> <form class='mdp_form' name="account_form" action="" method="post" enctype="multipart/form-data">
         <input name="pdt_id" type='hidden' value='<?= $pdt_id;?>' />
         <input name="callback" type='hidden' value='Forms' />
         <input name="callback_action" type='hidden' value='pdt_demo' />
         <?php
               echo"<button  type='submit' class='btnmob btn btn_medium btn_blue'>Visualizar Demo";?>
                <img class="wc_load" style='display:none;' alt="Aguarde" title="Aguarde" src="<?= BASE; ?>/_cdn/widgets/comments/load.gif"></button>
                </form></label></div>
               <?php else:
                ?>
                <div class='label_50'>
                 <label class='label'>
                      <form class='mdp_form' name="account_form" action="" method="post" enctype="multipart/form-data">
         <input name="pdt_id" type='hidden' value='<?= $pdt_id;?>' />
         <input name="callback" type='hidden' value='Forms' />
         <input name="callback_action" type='hidden' value='pdt_download' />
         <?php
               echo"<button  type='submit'    class='btnmob btn btn_medium btn_green'>Fazer Download</button>";?>
                <img class="wc_load" style='display:none;' alt="Aguarde" title="Aguarde" src="<?= BASE; ?>/_cdn/widgets/comments/load.gif"></button>
                </form></label>
               <label class='label'> <form class='mdp_form' name="account_form" action="" method="post" enctype="multipart/form-data">
         <input name="pdt_id" type='hidden' value='<?= $pdt_id;?>' />
         <input name="callback" type='hidden' value='Forms' />
         <input name="callback_action" type='hidden' value='pdt_demo' />
         <?php
               echo"<button  type='submit'   class='btnmob btn btn_medium btn_blue'>Visualizar Demo";?>
                <img class="wc_load" style='display:none;' alt="Aguarde" title="Aguarde" src="<?= BASE; ?>/_cdn/widgets/comments/load.gif"></button>
                </form></label></div>
                
                <?php
                endif;?>
            

</div>

        </div>
        
        <div class="clear"></div>
         <?php if (!empty($pdt_content)): ?>
  
         <div style='background:#fff;' class="content m_top">
            <div class="htmlchars">
                <?= $pdt_content; ?>
            </div>
                <?php  if($PdtPrice > 1):?>
             <?php require '_cdn/widgets/ecommerce/cart.add.php'; ?>
            <div class="clear"></div>
            <?php endif;?>
     
    </div>
<?php endif; ?>
       
    </div>
    

</div>

  <script src="<?= BASE;?>/_cdn/js/scriptsmdp.js"></script>

	<header style='margin-top:50px;'class="blog_header">
            <h2>Relacionados a <b> <?= $pdt_title?></b> </h2>
          
     
        </header>
<div class="home_features">
    <section class="container">
	<?php
						
                            $Read->ExeRead(DB_PDT, "WHERE pdt_subcategory = '{$pdt_subcategory}' AND pdt_id != '{$pdt_id}' AND  pdt_status = 1 ORDER BY pdt_title ASC LIMIT 3");
								
								if($Read->getResult()):?>
        
        <div style='margin-top:4%'  class="home_features_content">
		 <?PHP
									foreach($Read->getResult() as $pdt_all):
							
								if(isset($pdt_all['pdt_cover'])):
								?>
            <article class="radius">
                <header>
                    <a href='<?= BASE ."/produto/". $pdt_all['pdt_name']?>' title='clique para acessar a pagina <?= $pdt_all['pdt_title']?>'><img style='' alt="<?= $pdt_all['pdt_name'];?>" title="<?= $pdt_all['pdt_title'];?>" style='min-height:300px;max-height:301px;' src="<?= BASE;?>/tim.php?src=uploads/<?= $pdt_all['pdt_cover'];?>&w=<?= THUMB_W / 3?>&h=<?= THUMB_H / 1.7?>"/></a>
                    <h3   style='color:var(--color-blue);'  id='tit'><?= $pdt_all['pdt_title'];?></h3>
                   <!-- <p><?= $desc;?></p>-->
                </header>
               
            </article>
			<?php
					
					endif;
					
					endforeach; 
			
				?>
        </div>
		<?php
		else:
		    
						
                            $Read->ExeRead(DB_PDT, "WHERE pdt_category = '{$pdt_category}' AND pdt_id != '{$pdt_id}' AND  pdt_status = 1 ORDER BY pdt_title ASC LIMIT 3");
								
								if($Read->getResult()):?>
        
        <div style='margin-top:4%'  class="home_features_content">
		 <?PHP
									foreach($Read->getResult() as $pdt_all):
							
								if(isset($pdt_all['pdt_cover'])):
								?>
            <article class="radius">
                <header>
                    <a href='<?= BASE ."/produto/". $pdt_all['pdt_name']?>' title='clique para acessar a pagina <?= $pdt_all['pdt_title']?>'><img style='' alt="<?= $pdt_all['pdt_name'];?>" title="<?= $pdt_all['pdt_title'];?>" style='min-height:300px;max-height:301px;' src="<?= BASE;?>/tim.php?src=uploads/<?= $pdt_all['pdt_cover'];?>&w=<?= THUMB_W / 3?>&h=<?= THUMB_H / 1.7?>"/></a>
                    <h3   style='color:var(--color-blue);'  id='tit'><?= $pdt_all['pdt_title'];?></h3>
                   <!-- <p><?= $desc;?></p>-->
                </header>
               
            </article>
			<?php
					
					endif;
					
					endforeach; 
			
				?>
        </div>
		<?php
			endif;
			
		endif;
				?>
    </section>
</div>
<?php if (APP_COMMENTS && COMMENT_ON_PRODUCTS): ?>
    <div class="container produtct_reviews">
        <div class="content">
            <?php
            require '_cdn/widgets/comments/comments.php';
            ?>
            <div class="clear"></div>
        </div>
    </div>
<?php endif; ?>
      