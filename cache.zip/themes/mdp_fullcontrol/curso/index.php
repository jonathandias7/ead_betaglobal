<?php

 if($URL[1] == 'detalhes'):
 require REQUIRE_PATH . '/curso/detalhes.php';
 else:
 require REQUIRE_PATH . '/404.php';
 endif;



?>