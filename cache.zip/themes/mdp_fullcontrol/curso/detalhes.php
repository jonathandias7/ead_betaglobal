<!DOCTYPE html>
<?php

/*****************************
SUPORTE MDP SOFTWARES LTDA
APP: MDP NOTIFICATION WHATSAPP
SOBRE: Envia os pedidos pelo whats app.
Pietro Napoleão | atendimento@mdpape.net
WhatsApp - Grupo/Suporte: (32) 9 9992-0439
Copyright (c) 2015 - 2020 MDP SOFTWARES LTDA

******************************
IMPORTANTE: É expressamente proibido compartilhar estes arquivos por
qualquer meio ou com terceiros. Seu uso é exclusivo e intransferível
para o profissional.Podendo ser comercializado apenas a clientes sobre seus serviços.

A violação dos direitos exclusivos do produtor MDP SOFTWARES LTDA sobre a obra
é crime, ART. 184 DO CÓDIGO PENAL.
******************************/


//GET COURSE
$CourseName = (!empty($URL[2]) ? strip_tags($URL[2]) : null);
    if ($CourseName):
        $Read->ExeRead(DB_EAD_COURSES, "WHERE course_name = :name", "name={$CourseName}");
        extract($Read->getResult()[0]);
    endif;
    
    //GET PENDING CLASS
    $Table1 = DB_EAD_MODULES;
    $Table2 = DB_EAD_CLASSES;
    $Read->FullRead("SELECT COUNT(class_id) AS ClassCount, SUM(class_time) AS ClassTime FROM " . DB_EAD_CLASSES . " WHERE module_id IN(SELECT module_id FROM " . DB_EAD_MODULES . " WHERE course_id = :cs)", "cs={$course_id}");
    $ClassCount = $Read->getResult()[0]['ClassCount'];
    $ClassTime = floor($Read->getResult()[0]['ClassTime'] / 60) . ":" . str_pad($Read->getResult()[0]['ClassTime'] % 60, 2, 0, 0);
    $Read->FullRead("SELECT COUNT(student_class_id) as ClassStudentCount FROM " . DB_EAD_STUDENT_CLASSES . " WHERE course_id = :course AND student_class_check IS NOT NULL", "course={$course_id}");
    $ClassStudenCount = $Read->getResult()[0]['ClassStudentCount'];
    $Read->LinkResult(DB_EAD_COURSES_SEGMENTS, "segment_id", $course_segment);
    if ($Read->getResult()):
    	$CourseSegment = $Read->getResult()[0];
    endif;
?>


 
<section class="about_page">
	<?PHP if($course_apresenta_status): ?>
    <aside style='padding-top:100px;padding-bottom:100px;' class="about_page_cta">
	<header style='color:#fff;'class="blog_header">
            <h2 style='margin:20px'><b>ASSISTA AO VIDEO SOBRE  <?= $course_title;?></b></h2>
            <p style=''><b>Assistir ao video demonstrativo sobre <?= $course_title;?> para entender os detalhes.</b></p>
    </header>
	<div class="about_page_media">
        <div class="about_media_video">
            <div class="embed">
               <iframe width="560" height="315" 
				<?php if($course_apresenta_status == 1 ):?>
				
				 src="https://www.youtube-nocookie.com/embed/<?= $course_ead_apresenta; ?>?rel=0&amp;showinfo=0"  frameborder="0" allow="autoplay; encrypted-media" 
				
				<?php elseif($course_apresenta_status == 2 ):?>
			<?php endif;?>
				allowfullscreen></iframe>	
            </div>
        </div>
    </div>
        
    </aside>
	<?php else: ?>	
	<div class="about_page_content content">
        <header style='width:100%;' class="about_header">
            <h1><?= $course_title;?></h1>
        </header>
<div style="background-size:100%;padding:26%;background-image: url('<?= BASE?>/uploads/<?= $course_cover;?>');" class="">
			<div>
				<div class="row">
					<div class="col-md-12">
						<div class="banner-page text-center text-white text-uppercase">
						
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endif;?>	

        <!--FEATURES-->
        <div class="about_page_steps">

        </div>
    </div>
		</section>
	
<?php
 
$Read->ExeRead(DB_EAD_MODULES, "WHERE course_id = :course ORDER BY module_order ASC", "course={$course_id}");
    $Modules = $Read->getResult();

    if ($Modules):
        
        ?>  
        	<?PHP if($course_apresenta_status): ?>
        <article style='margin-top:50px;'class="optin_page">
    <div class="container content">
        <div class="optin_page_content">
            
                <a  href='<?= BASE?>/campus' class="optin_page_btn gradient gradient-green gradient-hover radius"
                       style='color:#fff!important;cursor:pointer' title="Comprar o curso">FAZER MATRICULA</a>
        
        </div>
    </div>
</article>
<?PHP endif;?>
         <section style='margin-bottom:-50px;' class="faq">
            
            <div class="faq_content content container">
        <header class="faq_header">
            <!--<img style='max-width:150px; margin-top:10px' class="title_image" title="Perguntas frequentes" alt="Perguntas frequentes"
                 src="<?= INCLUDE_PATH;?>/images/logo.png"/>-->
            <h2>MODULOS DO CURSO <?= $course_title;?></h2>
            <p></p>
        </header>
          <div class="faq_asks">
        <?php
        $mc = 17;
         $ic = 10;
        foreach ($Modules as $MOD):
        
        
        extract($MOD);
             $Read->FullRead("SELECT * FROM ws_ead_classes WHERE module_id = {$module_id} AND course_id = {$course_id}");
                    if($Read->getResult()):
            ?>
           
           
         
                    <article style='text-align:left;'  class="faq_ask j_collapse gradient-blue">
                    <h4 style='text-align:left;color:#fff;font-size:1em' class="j_collapse_icon icon-plus"><?= strtoupper($module_title); ?></h4>
                     <div style='padding-top:10px;' class="faq_ask_coll j_collapse_box">
                  
            
            <?php
            $c = 1;
                   foreach ($Read->getResult() as $CLASS):
                      
                      if($c%2!=0):
                         
                          $bgs = 'black';
                      else:
                       
                          $bgs = 'branco';
                      endif;
                      
                       $i = $mc*$ic;
                   extract($CLASS);
                   
                    $Read->ExeRead(DB_EAD_STUDENT_CLASSES, "WHERE class_id = :class", "class={$class_id}");
                        if ($Read->getResult()):
                            extract($Read->getResult()[0]);
                            $ClassViews = str_pad($student_class_views, 4, 0, 0);
                        endif;
                         //SUPPORT
                        $Read->FullRead("SELECT support_status FROM " . DB_EAD_SUPPORT . " WHERE class_id = :class", "class={$class_id}");
                        $TaskSupport = (!$Read->getResult() ? 'Não Abriu' : ($Read->getResult()[0]['support_status'] == 1 ? 'Em Aberto' : ($Read->getResult()[0]['support_status'] == 2 ? '<b>Respondida</b>' : 'Concluída')));
                        
                   ?>
                   <style>
   


</style>
                   <article style='margin-top:4px;' class="wc_ead_course_module_class <?= $bgs;?>">
                            <p style='width:10%;margin-top:10px;' class="row">
                                  <img  src='<?= INCLUDE_PATH.'/curso/pngegg.png';?>' style='width:20px; height:20px;'>
                        
                            </p><h1 class="row"><span style='margin-top:50px;'class="icon-play2"><?= $class_title; ?><span class="wc_tooltip_balloon">É o t desta aula!</span></span>
                            </h1><p style='width:10%;' class="row">
                                <span class="icon-hour-glass wc_tooltip"><?= $class_time; ?>min.<span class="wc_tooltip_balloon">É o tempo desta aula!</span></span>
                            </p><p style='width:15%;'  class="row views">
                                <span class="icon-stats-dots wc_tooltip"><?= ($class_time > 1 ? (!empty($ClassViews) ? $ClassViews *$ClassCount*($class_time+$i):0) :0); ?><span class="wc_tooltip_balloon">Quantas vezes assistidas!</span></span>
                            </p><p style='width:10%;' class="row">
                                <span class="icon-bubbles3 wc_tooltip"><?= ($class_time > 1 ? (!empty($ClassViews) ? $ClassViews+$ClassCount+$class_time*$ic:0) :0); ?><span class="wc_tooltip_balloon">Quantos tickets respondidos para essa aula</span></span>
                            </p>
                        </article>
                        <?php
                           $mc++;
                            $ic++;
                            $c++;
                   endforeach;
                    endif;
                    echo"</div> </article>";
     
        endforeach;
         echo"</div></div></section>";
    endif;
    ?>
        <section style='margin:4% 0' class="home_features gradient-blue">
        <div style='padding: 0' class="container content ">
     <div style='margin:-8px 0;background:#fff'>
        <div style='paddin:0; margin:0;width:100%'>
<div   style='text-align:center;width:100%' class="about_page_cta_content container content">
    
              
           <h2 style='text-align:center'> DESCRIÇÃO</h2>
           <div class='content'><?= $course_desc?></div>
           
            <article class="optin_page">
    <div class="container content">
        <div class="optin_page_content">
            
                <a href='<?= BASE?>/campus' class="optin_page_btn gradient gradient-green gradient-hover radius"
                       style='color:#fff!important;cursor:pointer' title="Comprar o curso">FAZER MATRICULA</a>
        </div>
    </div>
</article>
     </div>
        </div>
</section>
<section style='margin-top:-100px;' class="faq">
    
    <div class="faq_content content container">
        <header class="faq_header">
            <!--<img style='max-width:150px; margin-top:10px' class="title_image" title="Perguntas frequentes" alt="Perguntas frequentes"
                 src="<?= INCLUDE_PATH;?>/images/logo.png"/>-->
            <h3>Perguntas frequentes:</h3>
            <p>Confira as principais dúvidas e repostas sobre o curso <?= $course_title?>.</p>
        </header>
        <div class="faq_asks">
                <!-- AULAS -->
                <article class="faq_ask j_collapse">
                    <h4 class="j_collapse_icon icon-plus">Quantas aulas assistirei no curso?</h4>
                    <div class="faq_ask_coll j_collapse_box">
                        <p>O curso é composto por <b><?= $ClassCount; ?> aulas</b></p>
                       
                    </div>
                </article>
                <!-- DURAÇÃO -->
                  <article class="faq_ask j_collapse">
                    <h4 class="j_collapse_icon icon-plus">Qual a duração(horas) para conclusão do curos?</h4>
                    <div class="faq_ask_coll j_collapse_box">
                        <?php $time =  (!empty($ClassTime) && $ClassTime < 5 ? 5 : $ClassTime); ?>
                        <p>Somando o tempo de todas as video aulas, o curso tem aproxiamdamente <b> <?= ($time < 1 ? 10 : str_pad(5, 2, 0, 0) + $time); ?> horas</b> de duração.</p>
                       
                    </div>
                </article>
                
        
                
                  <!-- TUTOR -->
                  <article class="faq_ask j_collapse">
                    <h4 class="j_collapse_icon icon-plus">Qual é o tutor do curso?</h4>
                    <div class="faq_ask_coll j_collapse_box">
                        <p>O curso está sendo gerido pelo tutor: <b>Pietro Napoleão</b>.</p>
                       
                    </div>
                </article>
                
                 <!-- DURAÇÃO -->
                  <article class="faq_ask j_collapse">
                    <h4 class="j_collapse_icon icon-plus">Qual o segmento do curso?</h4>
                    <div class="faq_ask_coll j_collapse_box">
                        <p>O curso é voltado para o segmento: <b><?= $CourseSegment['segment_title'];?></b>.</p>
                       
                    </div>
                   </article> 
                   
                    <!-- CERTIFICADO -->
                  <article class="faq_ask j_collapse">
                    <h4 class="j_collapse_icon icon-plus">O curso é fornecer o certificado?</h4>
                    <div class="faq_ask_coll j_collapse_box">
                        <p>Sim, todos os cursos da <b>MDP</b> são certificados. Você poderá geralo diretamente na plataforma do aluno quando concluir o curso.</p>
                       
                    </div>
                   </article> 
                    <!-- DURAÇÃO -->
                  <article class="faq_ask j_collapse">
                    <h4 class="j_collapse_icon icon-plus">Quantos alunos já se matricularam no curso?</h4>
                    <div class="faq_ask_coll j_collapse_box">
                        <?php
                        $alunos = 0;
                        if($course_id == 1):
                       $alunos =  $ClassStudenCount + 397;
                       elseif($course_id == 7):
                       $alunos =  $ClassStudenCount + 211;
                        elseif($course_id == 8):
                       $alunos =  $ClassStudenCount + 332;
                        elseif($course_id == 9):
                       $alunos =  $ClassStudenCount + 1414;
                        elseif($course_id == 10):
                       $alunos =  $ClassStudenCount + 190;
                        elseif($course_id == 11):
                       $alunos =  $ClassStudenCount + 2151;
                        endif;
                         ?>
                        <p>O curso <?= $course_title?> já recebeu : <b><?= $alunos;?> Matriculas</b> até o momento.</p>
                    </article>   
                    </div>
                    
                     <article class="optin_page">
    <div class="container content">
        <div class="optin_page_content">
            
                <a href='<?= BASE?>/campus' class="optin_page_btn gradient gradient-green gradient-hover radius"
                       style='color:#fff!important;cursor:pointer' title="Comprar o curso">FAZER MATRICULA</a>
        </div>
    </div>
</article>
                  
                
        </div>
    </div>
    </section>
</section>
<script>
   $('html').on('click', '.mmodal', function(){
  $('.mproducts_modal').fadeIn();
  });
  
  /* close modal product */
    $('html').on('click', '.j_close_modal_pdp', function () {
        $('.mproducts_modal_content').fadeOut('fast', function () {
            $('.mproducts_modal').fadeOut('fast', function () {
                $(this).remove();
                $('body').css('overflow', 'visible');
                window.location.reload(true);
            });
        });
    });
</script>
        <script src="<?= BASE;?>/_cdn/js/scriptsmdp.js"></script>