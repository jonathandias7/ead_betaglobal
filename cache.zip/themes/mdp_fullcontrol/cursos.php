<?php
if (!$Read):
    $Read = new Read;
endif;
$cid = '';


$Read->FullRead("SELECT  segment_id FROM ws_ead_courses_segments WHERE segment_name = :id","id={$URL[1]}");
if ($Read->getResult()):
$cid = " course_segment = '" . $Read->getResult()[0]['segment_id'] . "'  AND ";
endif;

$Read->ExeRead(DB_EAD_COURSES, "WHERE {$cid} course_status = 1 AND course_created <= NOW()");
if (!$Read->getResult()):
    require REQUIRE_PATH . '/404.php';
    return;
endif;

?>


<section class="blog_page">
    <header class="blog_page_header">
        <h1 style='margin:20px 0;color:#fff'>NOSSOS CURSOS</h1>
          <!-- formulario Inscrição que sera enviado pro ajax-->
            <form class="wc_form" action="" method="post" enctype="multipart/form-data">
                <?php
                $Read = new Read();
                   $Read->FullRead("SELECT segment_name, segment_title FROM ws_ead_courses_segments ORDER BY segment_title ASC");
                if ($Read->getResult()):
                   
                    echo "<label style='width:99%;padding:3%' ><select style='width:95%!important;border:none;font-size:0.9em'  id='categoria'>";
                    echo "<option value=''>Filtrar cursos cursos por categoria</option>";
                    foreach ($Read->getResult() as $cat):
                         
                        if($cat['segment_title']):
                            echo "<option";
                            if($URL[1] == $cat['segment_name']):
                                
                            echo" selected='selected'";
                            endif;
                        echo " value='{$cat['segment_name']}'>{$cat['segment_title']}</option>";
                       endif;
                    endforeach;
                     echo "<option value=''>Todos os cursos</option>";
                    echo "</select></label>";
                endif;
                ?>
                <script>
                $('html').on('change','#categoria', function(){
                var cats =  $(this).val();
                if(cats){
                    window.location.href="<?= BASE?>/cursos/"+ cats;
                }else{
                     window.location.href="<?= BASE?>/cursos/";
                }
                
                });
                </script>
    </form> 
        <form name="searchc" action="" method="post" enctype="multipart/form-data">
            <label>
                <input type="text" name="sc" placeholder="pesquisar curso ex: PHP, Marketing, etc..."/>
                <button class="icon-search icon-notext"></button>
            </label>
        </form>
    </header>
	<header style='margin-top:50px;'class="blog_header">
            <h2>NOSSOS CURSOS</h2>
            <p>A MDP engloba todo ramo web.Somos especializados em <b>Desenvolvimento Web</b>.Veja abaixo o que podemos fazer por você ou sua empresa.:</p>
     
        </header>

        <div class="home_features">
    <section class="container">
	<?php
	
						
                            $Read->ExeRead(DB_EAD_COURSES, "WHERE {$cid} course_status = 1 AND course_none < 1 AND course_created <= NOW()");
								
								if($Read->getResult()):
?>
        
        <div style='margin-top:4%'  class="home_features_content">
		 <?PHP
									foreach($Read->getResult() as $course_all):
							
								if(isset($course_all['course_cover'])):
								?>
             <article  style='background:#fff;margin:0;padding:0;width:100%;'  class="radius">
                <header>
                  <a  style='width:100%;'  title="Ler mais sobre <?= $course_all['course_title']; ?>" href="<?= BASE; ?>/curso/detalhes/<?= $course_all['course_name']; ?>">
								
									<?php if(!empty($course_all['course_cover'])): ?>
										<img style='min-height:270px;min-width:380px;' title="<?= $course_all['course_title']; ?>" alt="<?= $course_all['course_title'];; ?>" src="<?= BASE; ?>/tim.php?src=uploads/<?= $course_all['course_cover']; ?>&w=<?= THUMB_W / 2?>&h=<?= THUMB_H / 4?>"/>
									<?php endif; ?>
						</a>
		<h3 style='color:#1584f7'><?= Check::Words($course_all['course_title'],4); ?></h3>
        <a id='gradient-green' href="<?= BASE; ?>/curso/detalhes/<?= $course_all['course_name']; ?>" class=" optin_page_btn gradient gradient-blue gradient-hover radius"
                       style='color:#fff!important;cursor:pointer' title="Comprar o curso">Conhecer o Curso</a>

                <header style='margin-top:20px'></header>
            </article>
          
          
            
			<?php
					
					endif;
					
					endforeach; 
			
				?>
        </div>
		<?php
		endif;
				?>
    </section>
</div>
		 