<!DOCTYPE html>
<?php
$Read->ExeRead(DB_PAGES, "WHERE page_name = :nm ", "nm={$URL[2]}");
if (!$Read->getResult()):
    require REQUIRE_PATH . '/404.php';
    return;
else:
    extract($Read->getResult()[0]);
endif;
?>

 <!-- End Nav Section -->
    <!-- Hero Section -->
	<script>
	
	</script>
    <div class="page-header" style="background-image: url('<?= BASE?>/uploads/<?= $page_cover;?>');" id="home">
	
        <div class="header-caption">
            <div class="header-caption-contant">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div style="z-index:999" class="header-caption-inner">
                                <h1><?= $page_title; ?></h1>
                                <p><a href="<?= BASE ?>">Home </a> >> <?php echo "<a href='".BASE."/{$URL[0]}/{$URL[1]}'>{$URL[1]}</a> >> <a href='".BASE."/{$URL[0]}/{$URL[1]}/{$URL[2]}'> {$URL[2]}</a>"; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Hero Section -->
    <!-- Feature Section -->
  <!-- Feature Section -->
    <div class="feature-area inner-padding">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-4">
                    <div class="feature-img foo" data-sr='enter'>
					<img style="" src="<?= BASE?>/tim.php?src=uploads/<?= $page_cover;?>&w=<?= THUMB_W / 1; ?>&h=<?= THUMB_H / 1; ?>" alt="">
                    </div>
                </div>
                <div class="col-sm-12 col-md-8 foo" data-sr='enter'>
                    <div class="section-title-area-2">
                        <h2 class="section-title">INFORMAÇÕES SOBRE <?= $page_title?>:</h2>
                    </div>
                </div>
                <div class="col-sm-12 col-md-4">
                    <div class="feature-item">
                        <div class="single-feature foo" data-sr='enter'>
                            <div class="feature-icon"><i class="fa fa-arrow-circle-right "></i></div>
                            <div class="feature-content">
                                <h4 class="feature-title"><?= $wc_pro; ?></h4>
                                <p><?= $wc_pro_descricao; ?></p>
                            </div>
                        </div>
                        <div class="single-feature foo" data-sr='enter'>
                            <div class="feature-icon"><i class="fa fa-arrow-circle-right "></i></div>
                            <div class="feature-content">
                                <h4 class="feature-title"><?= $wc_tela; ?></h4>
                                <p><?= $wc_tela_desc; ?></p>
                            </div>
                        </div>
                        <div class="single-feature foo" data-sr='enter'>
                            <div class="feature-icon"><i class="fa fa-arrow-circle-right "></i></div>
                            <div class="feature-content">
                                <h4 class="feature-title"><?= $wc_pixel; ?></h4>
                                <p><?= $wc_pixel_desc; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-md-4">
                    <div class="feature-item">
                        <div class="single-feature foo" data-sr='enter'>
                            <div class="feature-icon"><i class="fa fa-arrow-circle-right "></i></div>
                            <div class="feature-content">
                                <h4 class="feature-title"><?= $wc_site; ?></h4>
                                <p><?= $wc_site_desc; ?></p>
                            </div>
                        </div>
                        <div class="single-feature foo" data-sr='enter'>
                              <div class="feature-icon"><i class="fa fa-arrow-circle-right "></i></div>
                            <div class="feature-content">
                                <h4 class="feature-title"><?= $wc_responsivo; ?></h4>
                                <p><?= $wc_responsivo_desc; ?></p>
                            </div>
                        </div>
                        <div class="single-feature foo" data-sr='enter'>
                            <div class="feature-icon"><i class="fa fa-arrow-circle-right "></i></div>
                            <div class="feature-content">
                                <h4 class="feature-title"><?= $wc_desenvolvido; ?></h4>
                                <p><?= $wc_desenvolvido_desc; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Feature Section -->
	<div class="skills-area inner-padding4">
        <div class="skills-area-inner">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="section-title-area-4 foo" data-sr='enter'>
                            <h2 class="section-title"><?= $page_title; ?></h2>
                           <p><?= $page_subtitle; ?> </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="my-skills">
                            <div class="row">
							 
                      
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <div class="skills-progress foo" data-sr='enter'>
                                        <p class="progressbar-title"><?= $wc_barra_title?></p>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:<?= $wc_barra_1?>%">
                                                <span><?= $wc_barra_1?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                 <div class="col-xs-12 col-sm-6 col-md-4">
                                    <div class="skills-progress foo" data-sr='enter'>
                                        <p class="progressbar-title"><?= $wc_barra_title_2?></p>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:<?= $wc_barra_2?>%">
                                                <span><?= $wc_barra_2?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-4">
                                    <div class="skills-progress foo" data-sr='enter'>
                                        <p class="progressbar-title"><?= $wc_barra_title_3?></p>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:<?= $wc_barra_3?>%">
                                                <span><?= $wc_barra_3?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div> <div class="col-xs-12 col-sm-6 col-md-4">
                                    <div class="skills-progress foo" data-sr='enter'>
                                        <p class="progressbar-title"><?= $wc_barra_title_4?></p>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:<?= $wc_barra_4?>%">
                                                <span><?= $wc_barra_4?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
								<div class="col-xs-12 col-sm-6 col-md-4">
                                    <div class="skills-progress foo" data-sr='enter'>
                                        <p class="progressbar-title"><?= $wc_barra_title_5?></p>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:<?= $wc_barra_5?>%">
                                                <span><?= $wc_barra_5?></span>
                                            </div>
                                        </div>
                                    </div>
								</div> 
									 <div class="col-xs-12 col-sm-6 col-md-4">
                                    <div class="skills-progress foo" data-sr='enter'>
                                        <p class="progressbar-title"><?= $wc_barra_title_6?></p>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width:<?= $wc_barra_6?>%">
                                                <span><?= $wc_barra_6?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


