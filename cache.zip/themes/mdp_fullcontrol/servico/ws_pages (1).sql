-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 04/04/2018 às 09:20
-- Versão do servidor: 10.1.31-MariaDB
-- Versão do PHP: 7.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `u913715729_mdp`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `ws_pages`
--

CREATE TABLE `ws_pages` (
  `page_id` int(11) UNSIGNED NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `page_subtitle` varchar(255) DEFAULT NULL,
  `page_name` varchar(255) DEFAULT NULL,
  `page_content` text,
  `page_date` timestamp NULL DEFAULT NULL,
  `page_revision` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `page_order` int(11) DEFAULT NULL,
  `page_status` int(11) NOT NULL DEFAULT '0',
  `page_cover` varchar(255) DEFAULT NULL,
  `wc_pro` varchar(255) NOT NULL,
  `wc_pro_descricao` varchar(255) NOT NULL,
  `wc_site` varchar(255) NOT NULL,
  `wc_site_desc` varchar(255) NOT NULL,
  `wc_tela` varchar(255) NOT NULL,
  `wc_tela_desc` varchar(255) NOT NULL,
  `wc_responsivo` varchar(255) NOT NULL,
  `wc_responsivo_desc` varchar(255) NOT NULL,
  `wc_pixel` varchar(255) NOT NULL,
  `wc_pixel_desc` varchar(255) NOT NULL,
  `wc_desenvolvido` varchar(255) NOT NULL,
  `wc_desenvolvido_desc` varchar(255) NOT NULL,
  `wc_barra_title` varchar(255) NOT NULL,
  `wc_barra_1` int(11) NOT NULL,
  `wc_barra_title_2` varchar(255) NOT NULL,
  `wc_barra_2` int(11) NOT NULL,
  `wc_barra_title_3` varchar(255) NOT NULL,
  `wc_barra_3` int(11) NOT NULL,
  `wc_barra_title_4` varchar(255) NOT NULL,
  `wc_barra_4` int(11) NOT NULL,
  `wc_barra_title_5` varchar(255) NOT NULL,
  `wc_barra_5` int(11) NOT NULL,
  `wc_barra_title_6` varchar(255) NOT NULL,
  `wc_barra_6` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `ws_pages`
--
ALTER TABLE `ws_pages`
  ADD PRIMARY KEY (`page_id`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `ws_pages`
--
ALTER TABLE `ws_pages`
  MODIFY `page_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
