<?php

 if($URL[1] == 'detalhes'):
 require REQUIRE_PATH . '/site-oficial/detalhes.php';
 elseif($URL[1] == 'informacao'):
 require REQUIRE_PATH . '/site-oficial/informa.php';
 
 
 endif;



?>