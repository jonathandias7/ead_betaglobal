<!DOCTYPE html>
<?php
$Read->ExeRead(DB_PAGES, "WHERE page_name = :nm", "nm={$URL[2]}");
if (!$Read->getResult()):
    require REQUIRE_PATH . '/404.php';
    return;
else:
    extract($Read->getResult()[0]);
endif;
?>

<section class="about_page">
    <div class="about_page_content content">
        <header style='width:100%;' class="about_header">
            <h1><?= $page_title;?></h1>
        </header>
		
<div style="background-size:100%;padding:26%;background-image: url('<?= BASE?>/uploads/<?= $page_cover;?>');" class="">
			<div>
				<div class="row">
					<div class="col-md-12">
						<div class="banner-page text-center text-white text-uppercase">
						
						</div>
					</div>
				</div>
			</div>
		</div>
		

        <!--FEATURES-->
        <div class="about_page_steps">

        </div>
    </div>
		</section>
   <div style='background:#fbfbfb;paddin:0; margin:0;width:100%'>
<div   style='text-align:center;width:100%' class="about_page_cta_content container content">
           <h2 style='text-align:center'> DESCRIÇÃO</h2>
           <div class='content'><?= $page_content?></div>
           
            
        </div></div>
	<?PHP if($page_play): ?>
    <aside style='padding-top:100px;padding-bottom:100px;' class="about_page_cta">
	<header style='color:#fff;'class="blog_header">
            <h2><b>ASSISTA AO VIDEO SOBRE  <?= $page_title;?></b></h2>
            <p style=''><b>Assistir ao video demonstrativo sobre <?= $page_title;?> para entender os detalhes.</b></p>
        </header>
	<div class="about_page_media">
        <div class="about_media_video">
            <div class="embed">
               <iframe width="560" height="315" 
				<?php if(isset($page_tplay) && $page_tplay == 1 ):?>
				
				 src="https://www.youtube-nocookie.com/embed/<?= $page_play?>?rel=0&amp;showinfo=0"  frameborder="0" allow="autoplay; encrypted-media" 
				
				<?php elseif(isset($page_play) && $page_tplay == 2 ):?>
				src="https://player.vimeo.com/video/<?=$page_play?>?autoplay=1"  frameborder="0"
			
	
				
			<?php endif;?>
				allowfullscreen></iframe>	
            </div>
        </div>
    </div>
        
    </aside>
	<?php endif;?>

 <?php
                $Read->FullRead("SELECT * FROM mdp_faq WHERE faq_status = 1 AND page_id = $page_id");

                if ($Read->getResult()):?>
<section class="faq">
    <div class="faq_content content container">
        <header class="faq_header">
            <img class="title_image" title="Perguntas frequentes" alt="Perguntas frequentes"
                 src="<?= INCLUDE_PATH;?>/images/faq-title.jpg"/>
            <h3>Perguntas frequentes:</h3>
            <p>Confira as principais dúvidas e repostas sobre <?= $page_title?>.</p>
        </header>
        <div class="faq_asks">
          <?php
                   
                    foreach ($Read->getResult() as $attr):
                      
                         $Read->FullRead("SELECT * FROM mdp_faq_resp WHERE faq_id = :id", "id={$attr['faq_id']}");
                        if($Read->getResult()):
                            extract($Read->getResult()[0]);
                        endif;
                       extract($attr);
                      
                       ?>
                <article class="faq_ask j_collapse">
                    <h4 class="j_collapse_icon icon-plus"><?= $faq_title?></h4>
                    <div class="faq_ask_coll j_collapse_box">
                        <p><?= $faq_resp_title?></p>
                       
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>
  <?php endif; ?>