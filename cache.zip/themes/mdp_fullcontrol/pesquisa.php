<?php
$Search = urldecode($URL[1]);
$SearchPage = urlencode($Search);

if (empty($_SESSION['search']) || !in_array($Search, $_SESSION['search'])):
    $Read->FullRead("SELECT search_id, search_count FROM " . DB_SEARCH . " WHERE search_key = :key", "key={$Search}");
    if ($Read->getResult()):
        $Update = new Update;
        $DataSearch = ['search_count' => $Read->getResult()[0]['search_count'] + 1];
        $Update->ExeUpdate(DB_SEARCH, $DataSearch, "WHERE search_id = :id", "id={$Read->getResult()[0]['search_id']}");
    else:
        $Create = new Create;
        $DataSearch = ['search_key' => $Search, 'search_count' => 1, 'search_date' => date('Y-m-d H:i:s'), 'search_commit' => date('Y-m-d H:i:s')];
        $Create->ExeCreate(DB_SEARCH, $DataSearch);
    endif;
    $_SESSION['search'][] = $Search;
endif;
?>
<section class="blog_page">
    <header class="blog_page_header">
	<h2 style='color:#fff;'>Você pesquisou por:</h2>
							<h1 style='color:#fff;'><b style='color:#fcfcfc'><?= $Search?></b></h1>
			  <!-- formulario Inscrição que sera enviado pro ajax-->
            <form class="wc_form" action="" method="post" enctype="multipart/form-data">
                <?php
                $Read = new Read();
                   $Read->FullRead("SELECT category_name, category_title FROM ". DB_CATEGORIES ." WHERE category_parent IS NULL ORDER BY category_name ASC");
                if ($Read->getResult()):
                   
                    echo "<label style='width:99%;padding:3%' ><select style='width:95%!important;border:none;font-size:0.9em'  id='categoria'>";
                    echo "<option value=''>Filtrar Publicações por categoria</option>";
                    foreach ($Read->getResult() as $cat):
                         
                        if($cat['category_title']):
                            echo "<option";
                            if($URL[1] == $cat['category_name']):
                                
                            echo" selected='selected'";
                            endif;
                        echo " value='{$cat['category_name']}'>{$cat['category_title']}</option>";
                       endif;
                    endforeach;
                     echo "<option value=''>Todas as Publicações</option>";
                    echo "</select></label>";
                endif;
                ?>
                <script>
                $('html').on('change','#categoria', function(){
                var cats =  $(this).val();
                if(cats){
                    window.location.href="<?= BASE?>/artigos/"+ cats;
                }else{
                     window.location.href="<?= BASE?>/artigos/blog";
                }
                
                });
                </script>
    </form> 
						<form style='padding-top:50px;'name="search" action="" method="post" enctype="multipart/form-data">
            <label>
                <input type="text" name="s" placeholder="Encontre um artigo:"/>
                <button class="icon-search icon-notext"></button>
            </label>
        </form>
    </header>
    </section>
    <div class="home_features">
    <section class="container">
   
      
            <?php
             $count = 0;
            $Page = (!empty($URL[2]) ? $URL[2] : 1);
            $Pager = new Pager(BASE . "/pesquisa/{$SearchPage}/", "<<", ">>", 5);
            $Pager->ExePager($Page, 5);
            $Read->ExeRead(DB_POSTS, "WHERE post_status = 1 AND  (post_title LIKE '%' :s '%' OR post_subtitle LIKE '%' :s '%') ORDER BY post_name ASC  LIMIT :limit OFFSET :offset", "limit={$Pager->getLimit()}&offset={$Pager->getOffset()}&s={$Search}");
            $count = $Read->getRowCount();
            if (!$Read->getResult()):
                ?> <div style='margin-top:4%'  class="home_features_content">
        <?php
                $Pager->ReturnPage();
                echo Erro("Desculpe, mas sua pesquisa para <b>{$Search}</b> não retornou resultados. Talvez você queira utilizar outros termos! Você ainda pode usar nosso menu de navegação para encontrar o que procura!", E_USER_NOTICE);
            else:
               ?>
               
                <header style='margin-top:50px;'class="blog_header">
            <h2>Resultados da pesquisa <b><?= strtoupper($Search)?></b></h2>
             <p style='font-size:1.2em'>Foram encontrados <b><?= ($count < 10 ? '(0'. ($count > 2 ? $count.') Artigos' : $count.') Artigo') :'('. ($count > 2 ? $count.') Artigos' : $count.') Artigo'))?></b>  para essa pesquisa.</p>   
        </header>   <div style='margin-top:4%'  class="home_features_content">
        
               <?php
				
   foreach($Read->getResult() as $post_all):
									$countServ = $Read->getRowCount($post_all);
									$desc = Check::Words($post_all['post_content'], 6);
								if(isset($post_all['post_cover'])):
								?>
             <article  style='background:#fff;margin:0;padding:0;width:100%;'  class="radius">
                <header>
                  <a  style='width:100%;'  title="Ler mais sobre <?= $post_all['post_title']; ?>" href="<?= BASE; ?>/artigo/<?= $post_all['post_name']; ?>">
								
									<?php if(!empty($post_all['post_cover'])): ?>
										<img style='min-height:270px;min-width:380px;' title="<?= $post_all['post_title']; ?>" alt="<?= $post_all['post_title'];; ?>" src="<?= BASE; ?>/tim.php?src=uploads/<?= $post_all['post_cover']; ?>&w=<?= THUMB_W / 2?>&h=<?= THUMB_H / 4?>"/>
									<?php endif; ?>
						</a>
		<h3  style='color:var(--color-blue);' ><?= Check::Words($post_all['post_title'],4); ?></h3>
        <a id='gradient-green' href="<?= BASE; ?>/artigo/<?= $post_all['post_name']; ?>" class=" optin_page_btn gradient gradient-hover radius"
                       style='color:#fff!important;cursor:pointer' title="Comprar o curso">Conhecer o Curso</a>
<style> #gradient-green{background: linear-gradient(to right, #00b594 0%, #13aab4 50%, #00b594 100%)!important;}
             #gradient-green:hover{background: linear-gradient(to right, #13aab4 0%, #00b594 50%, #13aab4 100%)!important;}
             </style>
                <header style='margin-top:20px'></header>
            </article>
		 <?php
		            endif;
                endforeach;
            endif;

            $Pager->ExePaginator(DB_PAGES, "WHERE page_status = 1 AND page_type_serv >= 1");
            echo $Pager->getPaginator();
            
            ?>
        </div>
    </div>
</section>
       </div>    
                  