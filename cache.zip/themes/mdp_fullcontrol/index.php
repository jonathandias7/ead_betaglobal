
 <?php 
 $Read->ExeRead("mdp_play", "WHERE mdp_play_status > 0 ORDER BY mdp_play_id DESC LIMIT 1");
if ($Read->getResult() && empty($_SESSION['playon']) || !empty($Read->getResult()[0]['mdp_play_type']) && $Read->getResult()[0]['mdp_play_type'] > 1):
extract($Read->getResult()[0]);
	
?>
 <div style='background:rgba(0,0,0,0.8)' class=" animate-slider three">
			<div class="slider-warper">
				<div class="slider-img">
				
				<?php if(!empty($mdp_play_host) && $mdp_play_host == 1):?>
					<iframe width="100%" style='height:500px;' src="https://www.youtube-nocookie.com/embed/<?= $mdp_play_url?>?controls=0&autoplay=1" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
				<?php elseif(!empty($mdp_play_host) && $mdp_play_host == 2):?>
					
					<iframe width="100%" style='height:500px;'  src="https://player.vimeo.com/video/<?= $mdp_play_url?>?autoplay=1"  frameborder="0"allowfullscreen></iframe>
					<?php endif;?>
				</div>
				<!-- direction 1 -->
				
			</div>
  </div>

  <?php
	 $_SESSION['playon'] = 1;
 
	else:
			$page_id = Check::PageByName('about');
			$page_all = Check::PageId($page_id);
			$desc = Check::Words($page_all['page_content'],45 );
			if(isset($page_id) && isset($page_all['page_status']) &&  $page_all['page_status'] >= 1):
			
		?>
		<style>
		.home_video {
    position: relative;
    background: rgba(0, 0, 0, 0.7);
    color: #ffffff;
}

.home_video:after {
    content: "";
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    position: absolute;
    z-index: var(--index-back);
	 background: url("<?= BASE ?>/uploads/<?= $page_all['page_cover']?>")top center no-repeat!important;
    background-size: cover;
    background-attachment: fixed;
}
.home_featured {
    position: relative;
    background: rgba(0, 0, 0, 0.7);
    color: #ffffff;
   
}

.home_featured:after {
    content: "";
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    position: absolute;
    z-index: var(--index-back);
	 background: url("<?= BASE ?>/uploads/<?= $page_all['page_cover']?>")top center no-repeat!important;
    background-size: cover;
    background-attachment: fixed;
}
 

</style>
		<main class="main_content">
<!--FEATURED-->
<article   style='height:600px'  class="home_featured">
    <div  class="home_featured_content container content">
        <header  class="home_featured_header"><meta charset="euc-jp">
            <h1><?= $page_all['page_title']?></h1>
			<h2><?= $page_all['page_subtitle']?></h2>
            <p><?= $desc?></p>
            <p><span style='color:#fff!important;' data-go=".home_features"
                     class="home_featured_btn gradient gradient-blue gradient-hover radius transition icon-check-square-o"><?= DESC_FRONT;?></span></p>
            
        </header>
    </div>
	<?PHP
$Read->ExeRead("mdp_setup_img","WHERE setup_img_status = 1");
if($Read->getResult()):
extract($Read->getResult()[0]);
?>
    <div style='width:100%!important; margin:0px;' class="home_featured_app">
        <img width="100%" src="<?= BASE;?>/uploads/<?= $setup_img_cover ?>" alt="<?= $setup_img_name ?>" title="<?= $setup_img_title ?>"/>
    </div>
<?php
else:
echo "<br/>";
endif;
?>
</article>
	<?php
endif;
endif;?>
<?php if(!empty(MDP_HOME_SERVICOS) && empty(MDP_HEADER_SERVICOS_MANUTENCAO)):?>
<!--FEATURES-->
<div class="home_features">
    <section class="container">

	<?php
								$Read->ExeRead(DB_PAGES, "WHERE page_status = 1 AND page_type_serv = 1 ORDER BY page_order ASC,page_name ASC");
								
								if($Read->getResult()):?>
        <header style='margin-left:7%' class="content home_features_header">
            <h2><b>NOSSO PORTFOLIO DE SERVICOS</b></h2>
            <p style='font-size:1.2em'>A MDP engloba todo ramo web.Somos especializados em <b>Desenvolvimento Web</b>.Veja nosso portfolio abaixa:</p>
        </header>
        <div style='margin-top:-4%'  class="home_features_content">
		 <?PHP
									foreach($Read->getResult() as $page_all):
									$countServ = $Read->getRowCount($page_all);
									$desc = Check::Words($page_all['page_content'], 6);
								if(isset($page_all['page_cover'])):
								?>
            <article style='padding:1%;' class="radius">
                <header>
                    <a href='<?= BASE ."/servico/detalhes/". $page_all['page_name']?>' title='clique para acessar a pagina <?= $page_all['page_title']?>'><img style='min-width:300px;height:220px;width:100%;margin:0;padding:0' alt="<?= $page_all['page_name'];?>" title="<?= $page_all['page_title'];?>" src="<?= BASE;?>/uploads/<?= $page_all['page_cover'];?>"/></a>
                    <h3 style='color:var(--color-blue);'><?= $page_all['page_title'];?></h3>
                   <!-- <p><?= $desc;?></p>-->
                </header>
            </article>
			<?php
					
					endif;
					
					endforeach; 
			
				?>
        </div>
		<?php
		endif;
				?>
    </section>
</div>

<?php endif;?>
<?php if(!empty(MDP_HOME_CURSOS_FREE) && empty(MDP_HEADER_CURSOS_MANUTENCAO)):?>
 

<?php
 if(APP_EAD):?>
<!--BLOG-->

<section style='margin:4% 0' class="home_features">
    <div style='padding:4% 0' class="container content ">
        <header style='<?= $fontmenu;?>'class="blog_header">
            <h2><b>NOSSOS CURSOS GRATUITOS</b></h2>
            <p><b>Conheca os cursos que a  <?= SITE_NAME;?> preparou para voce.</b></p>
        </header>

         <div style='margin-top:2%;'  class="home_features_content">
	
		<?php
					 $Read->ExeRead(DB_EAD_COURSES, "WHERE course_status = 1 AND course_none < 1 AND course_vendor_price < 1 ORDER BY course_order ASC, course_name ASC LIMIT :limit OFFSET :offset", "limit=3&offset=0");
            if (!$Read->getResult()):
               
                echo Erro("Ainda N«ªo existe posts cadastrados. Favor volte mais tarde :)", E_USER_NOTICE);
            else:
                foreach ($Read->getResult() as $Post):
                    extract($Post);
		
			
					?>
          <article  style='background:#fff;margin:0;padding:0;width:100%;'  class="radius">
                <header>
                  <a  style='width:100%;'  title="Ler mais sobre <?= $course_title; ?>" href="<?= BASE; ?>/curso/detalhes/<?= $course_name; ?>">
								
									<?php if(!empty($course_cover)): ?>
										<img style='min-height:220px;min-width:300px;width:100%;' title="<?= $course_title; ?>" alt="<?= $course_title; ?>" src="<?= BASE; ?>/tim.php?src=uploads/<?= $course_cover; ?>&w=<?= THUMB_W / 2?>&h=<?= THUMB_H / 4?>"/>
									<?php endif; ?>
						</a>
		<h3 style='color:var(--color-blue);'><?= Check::Words($course_title,4); ?></h3>
        <a href="<?= BASE; ?>/curso/detalhes/<?= $course_name; ?>" class=" optin_page_btn gradient gradient-blue gradient-hover radius"
                       style='color:#fff!important;cursor:pointer' title="Comprar o curso">Conhecer o Curso</a>

                <header style='margin-top:20px'></header>
            </article>
          
							
									
   

		 <?php
           
                endforeach;
            endif;

            
            
            ?>
        </div>
    </div>
</section>


<?php endif; ?>
<?php endif;?>

<?php if(!empty(MDP_HOME_CURSOS) && empty(MDP_HEADER_CURSOS_MANUTENCAO)):?>
 

<?php
 if(APP_EAD):?>
<!--BLOG-->

<section style='margin:4% 0' class="home_features gradient-blue">
    <div style='padding:4% 0' class="container content ">
        <header style='color:#fff;'class="blog_header">
            <h2><b>NOSSOS CURSOS</b></h2>
            <p><b>A <?= SITE_NAME;?> disponibiliza um campus para os alunos totalmente online.<br> Assista todos os nossos conteudos de qualquer lugar, em qualquer dispositivo.</b></p>
        </header>

         <div style='margin-top:2%;'  class="home_features_content">
	
		<?php
					 $Read->ExeRead(DB_EAD_COURSES, "WHERE course_status = 1 AND course_none < 1 AND course_vendor_price > 1 ORDER BY course_order ASC, course_name ASC LIMIT :limit OFFSET :offset", "limit=3&offset=0");
            if (!$Read->getResult()):
               
                echo Erro("Ainda N«ªo existe posts cadastrados. Favor volte mais tarde :)", E_USER_NOTICE);
            else:
                foreach ($Read->getResult() as $Post):
                    extract($Post);
		
			
					?>
          <article  style='background:#fff;margin:0;padding:0;width:100%;'  class="radius">
                <header>
                  <a  style='width:100%;'  title="Ler mais sobre <?= $course_title; ?>" href="<?= BASE; ?>/curso/detalhes/<?= $course_name; ?>">
								
									<?php if(!empty($course_cover)): ?>
										<img style='min-height:220px;min-width:300px;width:100%;' title="<?= $course_title; ?>" alt="<?= $course_title; ?>" src="<?= BASE; ?>/tim.php?src=uploads/<?= $course_cover; ?>&w=<?= THUMB_W / 2?>&h=<?= THUMB_H / 4?>"/>
									<?php endif; ?>
						</a>
		<h3 style='color:var(--color-blue);'><?= Check::Words($course_title,4); ?></h3>
        <a  href="<?= BASE; ?>/curso/detalhes/<?= $course_name; ?>" class=" optin_page_btn gradient gradient-blue gradient-hover radius"
                       style='color:#fff!important;cursor:pointer' title="Comprar o curso">Conhecer o Curso</a>

                <header style='margin-top:20px'></header>
            </article>
          
							
									
   

		 <?php
           
                endforeach;
            endif;

            
            
            ?>
        </div>
    </div>
</section>


<?php endif; ?>
<?php endif;?>

<?php if(!empty(MDP_HOME_LOJA) && empty(MDP_HEADER_LOJA_MANUTENCAO)):?>

 <div  class="home_features">
    <section  class="container">

	 <header style='margin-left:7%;' class="content home_features_header">
            <h2><b>NOSSA LOJA</b></h2>
            <p style='font-size:1.2em'>Produtos em destaque: Os 3 produtos mais vendidos em nossa Loja!</p>
        </header>
			<?php			
                            $Read->ExeRead(DB_PDT, "WHERE pdt_status = 1 AND pdt_price > 0 ORDER BY pdt_price DESC, pdt_id DESC LIMIT 12");
								
								if($Read->getResult()):?>
        
        <div style='margin-top:-4%'  class="home_features_content">
		 <?PHP
									foreach($Read->getResult() as $pdt_all):
							
								if(isset($pdt_all['pdt_cover'])):
								?>
            <article style='background:#fbfbfb' class="radius">
                <header>
                    <a href='<?= BASE ."/produto/". $pdt_all['pdt_name']?>' title='clique para acessar a pagina <?= $pdt_all['pdt_title']?>'><img style='' alt="<?= $pdt_all['pdt_name'];?>" title="<?= $pdt_all['pdt_title'];?>" style='min-height:300px;max-height:301px;' src="<?= BASE;?>/tim.php?src=uploads/<?= $pdt_all['pdt_cover'];?>&w=<?= THUMB_W / 3?>&h=<?= THUMB_H / 1.7?>"/></a>
                    <h3  style='color:var(--color-blue);' id='tit'><?= $pdt_all['pdt_title'];?></h3>
                   <!-- <p><?= $desc;?></p>-->
                </header>
               
            </article>
			<?php
					
					endif;
					
					endforeach; 
			
				?>
        </div>
		<?php
		else:
		      echo "<p style='background: #0d6b71;color:#fff; padding:15px; text-align:center;font-size:1.2em'>N«ªo existem <b>" .  $catt ." em " . urldecode($URL[1]) ."</b> at«± o momento.Entre em contato consco pelo chat ao lado ou Tente novamente mais tarde! </p>";
		endif;
				?>
    </section></div>
    <?php endif;
?>
<?php if(!empty(MDP_HOME_VIDEO_DESTAQUE)):?>
<?php
$page_id = Check::PageByName('demo');
$page_all = Check::PageId($page_id);
if(isset($page_all['page_status']) && $page_all['page_status'] >= 1):
?>
<article style='margin:4% 0 2% 0;' class="home_video">
    <div class="home_video_content container content">
        <header>
            <h2>ASSISTA NOSSO ULTIMO TUTORIAL POSTADO</h2>
            <span data-modal=".home_video_modal" class="icon-play-circle-o icon-notext transition"></span>
        </header>
    </div>

    <div class="home_video_modal j_modal_close">
        <div class="home_video_modal_box">
            <div class="embed">
                <iframe width="560" height="315" 
				<?php if(isset($page_all['page_play']) && $page_all['page_tplay'] == 1 ):?>
				
				 src="https://www.youtube-nocookie.com/embed/<?= $page_all['page_play']?>?rel=0&amp;showinfo=0""  frameborder="0" allow="autoplay; encrypted-media" 
				
				<?php elseif(isset($page_all['page_play']) && $page_all['page_tplay'] == 2 ):?>
				src="https://player.vimeo.com/video/<?=$page_all['page_play']?>?autoplay=1"  frameborder="0"
			
	
				
			<?php endif;?>
				allowfullscreen></iframe>			
            </div>
        </div>
    </div>
</article>
<?php endif;?>
<?php endif;?>


<?php if(!empty(MDP_HOME_BLOG) && empty(MDP_HEADER_BLOG_MANUTENCAO)):?>
<?php if(APP_POSTS):?>
<!--BLOG-->
<div class="home_features">
    <section class="container">
        <header style='margin-left:7%;' class="content home_features_header">
            <h2>Nossos artigos</h2>
            <p>Confira nossas dicas para controlar melhor suas contas</p>
        </header>

  <div style='margin-top:-4%'  class="home_features_content">
		<?php
						$Page = (!empty($URL[1]) ? $URL[1] : 1);
						$Pager = new Pager(BASE . "/index/", "<<", ">>", 5);
						$Pager->ExePager($Page, 3);
						$Read->ExeRead(DB_POSTS, "WHERE post_status = 1 AND post_date <= NOW() ORDER BY post_date ASC LIMIT :limit OFFSET :offset", "limit={$Pager->getLimit()}&offset={$Pager->getOffset()}");
						if (!$Read->getResult()):
							$Pager->ReturnPage();
							echo Erro("Ainda NÃ£o existe posts cadastrados. Favor volte mais tarde :)", E_USER_NOTICE);
						else:
							foreach ($Read->getResult() as $Post):
								extract($Post);
					?>
          
           <article class="radius">
    <a title="Ler mais sobre <?= $post_title; ?>" href="<?= BASE; ?>/artigo/<?= $post_name; ?>">
								
									<?php if(!empty($post_cover)): ?>
										<img title="<?= $post_title; ?>" alt="<?= $post_title; ?>" src="<?= BASE; ?>/tim.php?src=uploads/<?= $post_cover; ?>&w=<?= THUMB_W / 2?>&h=<?= THUMB_H / 4?>"/>
									<?php elseif(!empty($post_video)): ?>
										<img title="<?= $post_title; ?>" alt="<?= $post_title; ?>" src="https://i1.ytimg.com/vi/<?= $post_video; ?>/maxresdefault.jpg"/>
									<?php else: ?>
										<img title="<?= $post_title; ?>" alt="<?= $post_title; ?>" src="<?= BASE; ?>/tim.php?src=uploads/<?= $post_cover; ?>&w=<?= THUMB_W / 3?>&h=<?= THUMB_H / 4?>"/>"/>
									<?php endif; ?>
								</a>
								<?php
								$Read->FullRead("SELECT user_id, user_name, user_lastname, user_thumb FROM " . DB_USERS . " WHERE user_id = :id", "id={$post_author}");
									$UserId = $Read->getResult()[0]['user_id'];
									$User = "{$Read->getResult()[0]['user_name']} {$Read->getResult()[0]['user_lastname']}";
									?>
									
        <p style='color:gray;' class="meta">Blog/Novidades &bull; <?= $User?> &bull; <?= date("d-m-Y", strtotime($post_date))?></p>
        <h3 style='color:var(--color-blue);'><?= Check::Words($post_subtitle,7);?></h3>
   
     
                <a  href="<?= BASE; ?>/artigo/<?= $post_name; ?>" class=" optin_page_btn gradient gradient-blue gradient-hover radius"
                       style='color:#fff!important;cursor:pointer' title="Comprar o curso">Saiba Mais</a>
</article>
		 <?php
                endforeach;
            endif;

            $Pager->ExePaginator(DB_POSTS, "WHERE post_status = 1 AND post_date <= NOW()");
            echo $Pager->getPaginator();
            ?>
        </div>
    </div>
</section>
</div>

<?php
endif;
require __DIR__ . "/optout.php"; ?>
</main>
<?php endif;?>