<?php
$Search = urldecode($URL[1]);
$SearchPage = urlencode($Search);

if (empty($_SESSION['search']) || !in_array($Search, $_SESSION['search'])):
    $Read->FullRead("SELECT search_id, search_count FROM " . DB_SEARCH . " WHERE search_key = :key", "key={$Search}");
    if ($Read->getResult()):
        $Update = new Update;
        $DataSearch = ['search_count' => $Read->getResult()[0]['search_count'] + 1];
        $Update->ExeUpdate(DB_SEARCH, $DataSearch, "WHERE search_id = :id", "id={$Read->getResult()[0]['search_id']}");
    else:
        $Create = new Create;
        $DataSearch = ['search_key' => $Search, 'search_count' => 1, 'search_date' => date('Y-m-d H:i:s'), 'search_commit' => date('Y-m-d H:i:s')];
        $Create->ExeCreate(DB_SEARCH, $DataSearch);
    endif;
    $_SESSION['search'][] = $Search;
endif;
?>
<section class="blog_page">
    <header class="blog_page_header">
	<h2 style='color:#fff;'>Você pesquisou por:</h2>
							<h1 style='color:#fff;'><b style='color:#fcfcfc'><?= $Search?></b></h1>
							
						<form name="searchs" action="" method="post" enctype="multipart/form-data">
            <label>
                <input type="text" name="ss" placeholder="pesquisar serviço ex: Marketing"/>
                <button class="icon-search icon-notext"></button>
            </label>
        </form>
    </header>
</section>
        <div class="home_features">
    <section class="container">
   <header style='margin-top:50px;'class="blog_header">
            <h2>Resultados da pesquisa <b><?= $Search?></b></h2>      
        </header>  
         <div style='margin-top:4%'  class="home_features_content">
            <?php
            $Page = (!empty($URL[2]) ? $URL[2] : 1);
            $Pager = new Pager(BASE . "/pesquisar/{$SearchPage}/", "<<", ">>", 5);
            $Pager->ExePager($Page, 32);
            $Read->ExeRead(DB_PAGES, "WHERE page_status = 1 AND page_type_serv >= 1 AND (page_title LIKE '%' :s '%' OR page_subtitle LIKE '%' :s '%') ORDER BY page_order ASC, page_name ASC  LIMIT :limit OFFSET :offset", "limit={$Pager->getLimit()}&offset={$Pager->getOffset()}&s={$Search}");
            if (!$Read->getResult()):
                $Pager->ReturnPage();
                echo Erro("Desculpe, mas sua pesquisa para <b>{$Search}</b> não retornou resultados. Talvez você queira utilizar outros termos! Você ainda pode usar nosso menu de navegação para encontrar o que procura!", E_USER_NOTICE);
            else:
               
									
   foreach($Read->getResult() as $page_all):
									$countServ = $Read->getRowCount($page_all);
									$desc = Check::Words($page_all['page_content'], 6);
								if(isset($page_all['page_cover'])):
								?>
            <article class="radius">
                <header>
                    <a href='<?= BASE ."/servico/detalhes/". $page_all['page_name']?>' title='clique para acessar a pagina <?= $page_all['page_title']?>'><img style='height:220px;' alt="<?= $page_all['page_name'];?>" title="<?= $page_all['page_title'];?>" style='min-height:300px;' src="<?= BASE;?>/uploads/<?= $page_all['page_cover'];?>"/></a>
                    <h3  style='color:var(--color-blue);' ><?= $page_all['page_title'];?></h3>
                   <!-- <p><?= $desc;?></p>-->
                </header>
            </article>
		 <?php
		            endif;
                endforeach;
            endif;

            $Pager->ExePaginator(DB_PAGES, "WHERE page_status = 1 AND page_type_serv >= 1");
            echo $Pager->getPaginator();
            
            ?>
        </div>
    </div>
</section>
       </div>              