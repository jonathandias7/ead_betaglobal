
<?php
/*****************************
SUPORTE MDP SOFTWARES LTDA
APP: MDP EAD V5 
SOBRE: CSS dinamico da plataforma mdp ead v5
Pietro Napoleão | contato@mdpape.net
WhatsApp - Grupo/Suporte: (32) 9 9992-0439
Copyright (c) 2015 - 2020 MDP SOFTWARES LTDA

******************************
IMPORTANTE: É expressamente proibido compartilhar estes arquivos por
qualquer meio ou com terceiros. Seu uso é exclusivo e intransferível
para o profissional.Podendo ser comercializado apenas a clientes sobre seus serviços.

A violação dos direitos exclusivos do produtor MDP SOFTWARES LTDA sobre a obra
é crime, ART. 184 DO CÓDIGO PENAL.
******************************/
?>
<style>
    /* Header Area*/
    .header-area{background:<?= $background;?>!important;}

    /* Botoes Menu*/
    .main-menu ul li{background:<?= $btncolor;?>!important;}
    .main-menu ul li:hover{background:<?= $btnhover;?>!important;}

    /* Fontes menu */
    .main-menu ul li a{color:<?= $fonte;?>!important;}
    .main-menu ul li a:hover{color:<?= $fontehover;?>!important;}
   
</style>
