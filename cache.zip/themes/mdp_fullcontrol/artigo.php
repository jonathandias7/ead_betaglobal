<?php
if (!$Read):
    $Read = new Read;
endif;

$Read->ExeRead(DB_POSTS, "WHERE post_name = :nm AND post_date <= NOW() AND post_status = 1", "nm={$URL[1]}");
if (!$Read->getResult()):
    require REQUIRE_PATH . '/404.php';
    return;
else:
    extract($Read->getResult()[0]);
    $Update = new Update;
    $UpdateView = ['post_views' => $post_views + 1, 'post_lastview' => date('Y-m-d H:i:s')];
    $Update->ExeUpdate(DB_POSTS, $UpdateView, "WHERE post_id = :id", "id={$post_id}");

    $Read->ExeRead(DB_CATEGORIES, "WHERE category_id = :cat", "cat={$post_category}");
    if ($Read->getResult()):
        $Category = $Read->getResult()[0];
    endif;
endif;

$Read->FullRead("SELECT user_id, user_name, user_lastname, user_thumb FROM " . DB_USERS . " WHERE user_id = :id", "id={$post_author}");
	$photo =  $Read->getResult()[0]['user_thumb'];
	$UserId = $Read->getResult()[0]['user_id'];
	$User = "{$Read->getResult()[0]['user_name']} {$Read->getResult()[0]['user_lastname']}";
	?>
									
    <header>
       
<article class="post_page">
    <header class="post_page_header">
        <div class="post_page_hero">
            <h1><?= $post_title; ?></h1>
          <?php
		  if ($post_video):
                    echo "<div class='embed-container'>";
                    echo "<iframe style='height:460px;' id='mediaview' width='740' height='360' src='https://www.youtube.com/embed/{$post_video}?rel=0&amp;showinfo=0&autoplay=0&origin=" . BASE . "' frameborder='0' allowfullscreen></iframe>";
                    echo "</div>";
                else:
                    echo "<img style='width:100%;'class='post_page_cover' title='{$post_title}' alt='{$post_title}' src='" . BASE . "/uploads/{$post_cover}'/>";
                endif;
			  ?>
            <div class="post_page_meta">
                <div class="author">
                    <div><img src="<?= BASE;?>/uploads/<?= $photo?>"/></div>
                    <div class="name">Por:  <?= $User?></div>
                </div>
                <div class="date">Data <?= date("d-m-Y", strtotime($post_date))?></div>
            </div>
        </div>
    </header>

<div class="container post_single">
    <div class="content">
        <div class="left_content">
            <div class="post_page_content">
               
			
                <?php
                $WC_TITLE_LINK = $post_title;
                $WC_SHARE_HASH = "BoraEmpreender";
                $WC_SHARE_LINK = BASE . "/artigo/{$post_name}";
                require './_cdn/widgets/share/share.wc.php';
                ?>
               
                <div class="htmlchars">
				<h2 sclass="tagline"><?= $post_subtitle; ?></h2>
                    <?= $post_content; ?>
                </div>
               
			
             
                <div class="clear"></div>
            </div>
        </div>
		
		<div style='background:#fcfcfc' class="post_page_related content">
        <section>
            <header class="post_page_related_header">
                <h4>Veja também:</h4>
                <p>Confira mais artigos relacionados e obtenha ainda mais dicas de controle para suas contas.</p>
            </header>

            <div class="blog_articles">
               <?php 
			    $Read->ExeRead(DB_POSTS, "WHERE post_status = 1 AND post_id != :id ORDER BY post_date DESC LIMIT 4", "id={$post_id}");
                if ($Read->getResult()):
				 foreach ($Read->getResult() as $More):
				 extract($More);?>
				 <article class="blog_article">
    <a title="Ler mais sobre <?= $post_title; ?>" href="<?= BASE; ?>/artigo/<?= $post_name; ?>">
								
									<?php if(!empty($post_cover)): ?>
										<img title="<?= $post_title; ?>" alt="<?= $post_title; ?>" src="<?= BASE; ?>/uploads/<?= $post_cover; ?>"/>
									<?php elseif(!empty($post_video)): ?>
										<img title="<?= $post_title; ?>" alt="<?= $post_title; ?>" src="https://i1.ytimg.com/vi/<?= $post_video; ?>/maxresdefault.jpg"/>
									<?php else: ?>
										<img title="<?= $post_title; ?>" alt="<?= $post_title; ?>" src="<?= BASE; ?>/uploads/<?= $post_cover; ?>"/>
									<?php endif; ?>
								</a>
								<?php
								$Read->FullRead("SELECT user_id, user_name, user_lastname, user_thumb FROM " . DB_USERS . " WHERE user_id = :id", "id={$post_author}");
									$UserId = $Read->getResult()[0]['user_id'];
									$User = "{$Read->getResult()[0]['user_name']} {$Read->getResult()[0]['user_lastname']}";
									?>
									
    <header>
        <p class="meta">Blog &bull; <?= $User?> &bull; <?= date("d-m-Y", strtotime($post_date))?></p>
        <h2><a title="Post" href="<?= BASE; ?>/artigo/<?= $post_name; ?>"><?= $post_title; ?></a></h2>
    </header>
</article>
		 <?php
                endforeach;
            endif;
		?>
				 </div>
        </section>
    </div>
	
    </div>
</div>

<?php if (APP_COMMENTS && COMMENT_ON_POSTS): ?>
    <div class="container">
        <div class="content">
            <?php
            $CommentKey = $post_id;
            $CommentType = 'post';
            require '_cdn/widgets/comments/comments.php';
            ?>
            <div class="clear"></div>
        </div>
    </div>
<?php endif;  ?>