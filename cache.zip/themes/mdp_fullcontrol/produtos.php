<?php

$cid = '';
$catt = '';
$cats ='';
if($URL[1]):
$Read->ExeRead(DB_PDT_CATS, "WHERE cat_name = :cat", "cat={$URL[1]}");
if ($Read->getResult()):
$cid = " (pdt_category = '". $Read->getResult()[0]['cat_id'] ."' OR pdt_subcategory = '". $Read->getResult()[0]['cat_id'] ."') AND ";
$Read->ExeRead(DB_PDT_CATS, "WHERE cat_id = :cat", "cat=" . $Read->getResult()[0]['cat_parent']);
    if ($Read->getResult()):
    $catt = $Read->getResult()[0]['cat_title'];
    $cats = $Read->getResult()[0]['cat_id'];
    endif;
endif;
endif;

?>


		<section class="blog_page">
    <header class="blog_page_header">
        <h1 style='color:#fff'><?=  strtoupper(urldecode($URL[1]));?></h1>
          <!-- formulario Inscrição que sera enviado pro ajax-->
            <form class="wc_form" action="" method="post" enctype="multipart/form-data">
                <?php
                $Read = new Read();
                
                   $Read->FullRead("SELECT cat_id,cat_parent, cat_title, cat_name FROM " . DB_PDT_CATS . " WHERE cat_parent IN(SELECT pdt_category FROM " . DB_PDT . " WHERE pdt_status = 1) ORDER BY cat_title ASC");
                     echo "<label style='width:99%;padding:1%' ><select style='width:95%!important;border:none;font-size:0.9em'  id='categoria'>";
                         echo "<option value=''>Filtrar por segmento</option>";
                if ($Read->getResult()):
                
                    foreach ($Read->getResult() as $cat):
                         $Read->ExeRead(DB_PDT_CATS, "WHERE cat_id = :cat", "cat=" . $cat['cat_id']);
                     if ($Read->getResult()):
                        if($cat['cat_title']):
                            echo "<option";
                            if($URL[1] == $cat['cat_name']):
                                
                            echo" selected='selected'";
                            endif;
                        echo " value='{$cat['cat_name']}'>{$cat['cat_title']}</option>";
                       endif;
                       endif;
                    endforeach;
                endif;
                 echo "<option value=''>Voltar para categorias</option>";
                 echo "</select></label>";
                ?>
                <script>
                $('html').on('change','#categoria', function(){
                var cats =  $(this).val();
                if(cats){
                    window.location.href="<?= BASE?>/produtos/"+ cats;
                }else{
                     window.location.href="<?= BASE?>/nossaloja/";
                }
                
                });
                </script>
    </form> 
        <form name="searchp" action="" method="post" enctype="multipart/form-data">
            <label>
                <input type="text" name="sp" placeholder="pesquisar produto ex: template,apps, scripts,etc..."/>
                <button class="icon-search icon-notext"></button>
            </label>
        </form>
    </header>

	<header style='margin-top:50px;'class="blog_header">
            <h2>Você filtrou por: <b> <?=  $catt .' em ' . urldecode($URL[1]);?></b> </h2>
          
     
        </header>

        <div class="home_features">
    <section class="container">
	<?php
						
                            $Read->ExeRead(DB_PDT, "WHERE {$cid} pdt_status = 1 ORDER BY pdt_title ASC");
								
								if($Read->getResult()):?>
        
        <div style='margin-top:4%'  class="home_features_content">
		 <?PHP
									foreach($Read->getResult() as $pdt_all):
							
								if(isset($pdt_all['pdt_cover'])):
								?>
            <article class="radius">
                <header>
                    <a href='<?= BASE ."/produto/". $pdt_all['pdt_name']?>' title='clique para acessar a pagina <?= $pdt_all['pdt_title']?>'><img style='' alt="<?= $pdt_all['pdt_name'];?>" title="<?= $pdt_all['pdt_title'];?>" style='min-height:300px;max-height:301px;' src="<?= BASE;?>/tim.php?src=uploads/<?= $pdt_all['pdt_cover'];?>&w=<?= THUMB_W / 3?>&h=<?= THUMB_H / 1.7?>"/></a>
                    <h3   style='color:var(--color-blue);'  id='tit'><?= $pdt_all['pdt_title'];?></h3>
                   <!-- <p><?= $desc;?></p>-->
                </header>
               
            </article>
			<?php
					
					endif;
					
					endforeach; 
			
				?>
        </div>
		<?php
		else:
		      echo "<p style='background: #0d6b71;color:#fff; padding:15px; text-align:center;font-size:1.2em'>Não existem <b>" .  $catt ." em " . urldecode($URL[1]) ."</b> até o momento.Entre em contato consco pelo chat ao lado ou Tente novamente mais tarde! </p>";
		endif;
				?>
    </section>
</div>
	