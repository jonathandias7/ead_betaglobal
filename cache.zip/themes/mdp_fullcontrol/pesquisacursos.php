<?php
$Search = urldecode($URL[1]);
$SearchPage = urlencode($Search);

if (empty($_SESSION['search']) || !in_array($Search, $_SESSION['search'])):
    $Read->FullRead("SELECT search_id, search_count FROM " . DB_SEARCH . " WHERE search_key = :key", "key={$Search}");
    if ($Read->getResult()):
        $Update = new Update;
        $DataSearch = ['search_count' => $Read->getResult()[0]['search_count'] + 1];
        $Update->ExeUpdate(DB_SEARCH, $DataSearch, "WHERE search_id = :id", "id={$Read->getResult()[0]['search_id']}");
    else:
        $Create = new Create;
        $DataSearch = ['search_key' => $Search, 'search_count' => 1, 'search_date' => date('Y-m-d H:i:s'), 'search_commit' => date('Y-m-d H:i:s')];
        $Create->ExeCreate(DB_SEARCH, $DataSearch);
    endif;
    $_SESSION['search'][] = $Search;
endif;
?>
<section class="blog_page">
    <header class="blog_page_header">
	<h2 style='color:#fff;'>Você pesquisou por:</h2>
							<h1 style='color:#fff;'><b style='color:#fcfcfc'><?= $Search?></b></h1>
    
						<form name="searchc" action="" method="post" enctype="multipart/form-data">
            <label>
                <input type="text" name="sc" placeholder="pesquisar serviço ex: Marketing"/>
                <button class="icon-search icon-notext"></button>
            </label>
        </form>
    </header>
</section>
        <div class="home_features">
    <section class="container">
   
      
            <?php
             $count = 0;
            $Page = (!empty($URL[2]) ? $URL[2] : 1);
            $Pager = new Pager(BASE . "/pesquisacursos/{$SearchPage}/", "<<", ">>", 5);
            $Pager->ExePager($Page, 35);
            $Read->ExeRead(DB_EAD_COURSES, "WHERE course_status = 1 AND  (course_title LIKE '%' :s '%' OR course_headline LIKE '%' :s '%') ORDER BY course_order ASC, course_name ASC  LIMIT :limit OFFSET :offset", "limit={$Pager->getLimit()}&offset={$Pager->getOffset()}&s={$Search}");
            $count = $Read->getRowCount();
            if (!$Read->getResult()):
                ?> <div style='margin-top:4%'  class="home_features_content">
        <?php
                $Pager->ReturnPage();
                echo Erro("Desculpe, mas sua pesquisa para <b>{$Search}</b> não retornou resultados. Talvez você queira utilizar outros termos! Você ainda pode usar nosso menu de navegação para encontrar o que procura!", E_USER_NOTICE);
            else:
               ?>
               
                <header style='margin-top:50px;'class="blog_header">
            <h2>Resultados da pesquisa <b><?= strtoupper($Search)?></b></h2>
             <p style='font-size:1.2em'>Foram encontrados <b><?= ($count < 10 ? '(0'. ($count > 2 ? $count.') Cursos' : $count.') Curso') :'('. ($count > 2 ? $count.') Cursos' : $count.') Curso'))?></b>  para essa pesquisa.</p>   
        </header>   <div style='margin-top:4%'  class="home_features_content">
        
               <?php
				
   foreach($Read->getResult() as $course_all):
									$countServ = $Read->getRowCount($course_all);
									$desc = Check::Words($course_all['course_desc'], 6);
								if(isset($course_all['course_cover'])):
								?>
             <article  style='background:#fff;margin:0;padding:0;width:100%;'  class="radius">
                <header>
                  <a  style='width:100%;'  title="Ler mais sobre <?= $course_all['course_title']; ?>" href="<?= BASE; ?>/curso/detalhes/<?= $course_all['course_name']; ?>">
								
									<?php if(!empty($course_all['course_cover'])): ?>
										<img style='min-height:270px;min-width:380px;' title="<?= $course_all['course_title']; ?>" alt="<?= $course_all['course_title'];; ?>" src="<?= BASE; ?>/tim.php?src=uploads/<?= $course_all['course_cover']; ?>&w=<?= THUMB_W / 3?>&h=<?= THUMB_H / 4?>"/>
									<?php endif; ?>
						</a>
		<h3  style='color:var(--color-blue);' ><?= Check::Words($course_all['course_title'],4); ?></h3>
        <a id='gradient-green' href="<?= BASE; ?>/curso/detalhes/<?= $course_all['course_name']; ?>" class=" optin_page_btn gradient gradient-hover radius"
                       style='color:#fff!important;cursor:pointer' title="Comprar o curso">Conhecer o Curso</a>
<style> #gradient-green{background: linear-gradient(to right, #00b594 0%, #13aab4 50%, #00b594 100%)!important;}
             #gradient-green:hover{background: linear-gradient(to right, #13aab4 0%, #00b594 50%, #13aab4 100%)!important;}
             </style>
                <header style='margin-top:20px'></header>
            </article>
		 <?php
		            endif;
                endforeach;
            endif;

            $Pager->ExePaginator(DB_PAGES, "WHERE page_status = 1 AND page_type_serv >= 1");
            echo $Pager->getPaginator();
            
            ?>
        </div>
    </div>
</section>
       </div>              