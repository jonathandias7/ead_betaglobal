
			<!--FOOTER-->
<footer style='background:linear-gradient(to right, #000 0%, <?= $custom_background;?> 50%, #000 100%)!important;margin-top:50px;' class="main_footer">
    <div  class="container content">
        <section class="main_footer_content">
            <article class="main_footer_content_item">
                <h2>BETA LTDA</h2>
                <p><?= SITE_DESC;?></p>
                <img style='margin-top:10px;max-height:60px;'src="<?= INCLUDE_PATH?>/images/logo.png" alt="" />
                
                <a title="Termos de uso" href="?file=terms">Termos de uso</a>
            </article>

            <article class="main_footer_content_item">
                <h2>Mais:</h2>
                <a style='color:#ffffff;'class="link" title="Home" href="<?= BASE; ?>">Home</a>
                <a style='color:#ffffff;' class="link" title="Sobre" href="<?= BASE; ?>/sobre">Sobre</a>
                 <a style='color:#ffffff;' class="link" title="Sobre" href="<?= BASE; ?>/sobre">Serviços</a></a>
                  <a style='color:#ffffff;' class="link" title="Nossos Serviços" href="<?= BASE; ?>/sobre">Cursos</a>
                  <a style='color:#ffffff;' class="link" title="Nossos Cursos" href="<?= BASE; ?>/sobre">Nossa Loja</a>
                  <a style='color:#ffffff;' class="link" title="Nosso Blog" href="<?= BASE; ?>/sobre">Nosso Blog</a>
                  <a style='color:#ffffff;' class="link" title="Minhas compras" href="<?= BASE; ?>/sobre">Minhas Compras</a>
                    <a style='color:#ffffff;' class="link" title="Campus do aluno" href="<?= BASE; ?>/sobre">Campus</a>
            </article>
						
            <article class="main_footer_content_item">
                <h2>Contato:</h2>
                <p class="icon-phone"><b>Telefone:</b><br> <?= SITE_ADDR_PHONE_A; ?></p>
                <p class="icon-envelope"><b>Email:</b><br> <?= SITE_ADDR_EMAIL; ?></p>
               
            </article>

            <article class="main_footer_content_item social">
                <h2>Social:</h2>
                <a class="icon-facebook" href="http://facebook.com.br/<?= SITE_SOCIAL_FB_PAGE; ?>" title="Facebook">/<?= SITE_SOCIAL_FB_PAGE; ?></a>
                <a class="icon-instagram" href="http://instagram.com.br/<?= SITE_SOCIAL_INSTAGRAM; ?>" title="Instagram"><?= SITE_SOCIAL_INSTAGRAM; ?></a>
                
            </article>
        </section>
    </div>
</footer>
<footer style='background:linear-gradient(to right, #000 0%, #000 50%, #000 100%)!important;color:#fff;padding:10px;font-size:1em;text-align:center'>
      <p style='margin-top:-5px;'> &#169; Todos os direitos reservados <b><?= SITE_NAME;?></b> </p>
  <!--<p style='margin-top:-5px;'> Developed By: <b>Pietro Napoleão</b></p>-->
 

</footer>
			<script type="text/javascript">
    (function () {
        var options = {
            facebook: "<?= SITE_SOCIAL_FB_PAGE; ?>", // Facebook page ID
            whatsapp: "+55<?= SITE_ADDR_PHONE_B; ?>", // WhatsApp number
            company_logo_url: "<?= BASE; ?>/themes/images/logo.png", // URL of company logo (png, jpg, gif)
            greeting_message: "Olá, como podemos ajudá-lo? Basta enviar-nos uma mensagem agora para obter assistência.", // Text of greeting message
            call_to_action: "Precisa de ajuda?", // Call to action
            button_color: "#9A0E0E", // Color of button
            position: "left", // Position may be 'right' or 'left'
            order: "facebook,whatsapp" // Order of buttons
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script');
        s.type = 'text/javascript';
        s.async = true;
        s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () {
            WhWidgetSendButton.init(host, proto, options);
        };
        var x = document.getElementsByTagName('script')[0];
        x.parentNode.insertBefore(s, x);
    })();
</script>
		</footer>
        <!-- End footer area -->  
    </div>
<!-- <script>
   $('html').on('click', '.pmodal', function(){
  $('.products_modal').fadeIn();
  });
  
  /* close modal product */
    $('html').on('click', '.j_close_modal_pdp', function () {
        $('.products_modal_content').fadeOut('fast', function () {
            $('.products_modal').fadeOut('fast', function () {
                $(this).remove();
                $('body').css('overflow', 'visible');
                window.location.reload(true);
            });
        });
    });
</script>-->
<script>(function(d, s, id) {
		  var js, fjs = d.getElementsByTagName(s)[0];
		  if (d.getElementById(id)) return;
		  js = d.createElement(s); js.id = id;
		  js.src = "//connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v2.7&appId=1566786350223509";
		  fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));</script>