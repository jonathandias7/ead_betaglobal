<?php
if (empty($WcContactRequired)):
    $WcContactRequired = true;
    echo "<link rel='stylesheet' href='" . BASE . "/_cdn/widgets/contact/contact.wc.css'/>";
    echo "<script src='" . BASE . "/_cdn/widgets/contact/contact.wc.js'></script>";
endif;
$Read->ExeRead(DB_PAGES, "WHERE page_id = 11");
if (!$Read->getResult()):
    require REQUIRE_PATH . '/404.php';
    return;
else:
    extract($Read->getResult()[0]);
endif;

?>
<!--Contact us pages start-->
     <div class="page-header" style="background-image: url('<?= BASE?>/uploads/<?= $page_cover;?>');" id="home">
	
        <div class="header-caption">
            <div class="header-caption-contant">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div style="z-index:999" class="header-caption-inner">
                                <h1>FALE CONOSCO</h1>
                               </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Hero Section -->
    <!-- Contact Section -->
    <div class="contact-area inner-padding6">
        <!-- Map area Section -->
        <div style="height:500px;" class="col-xs-12 col-sm-12">
            <iframe style="height:500px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3711.5212570625067!2d-42.469273250846236!3d-21.526464185660807!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xbd31f35da187e1%3A0x4679fcb2cc204743!2sR.+S%C3%A3o+Joaquim%2C+451%2C+Recreio+-+MG%2C+36740-000!5e0!3m2!1spt-BR!2sbr!4v1522867687831" width="100%"  frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
        <!-- End Map area Section -->
        <!-- Contact Form Section -->
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-4">
                    <div class="address-widget foo" data-sr='enter'>
                        <div class="contact-icon"><i class="fa fa-map-marker"></i></div>
                        <h5>Endereço:</h5>
                         <p><?= SITE_ADDR_ADDR .', '. SITE_ADDR_DISTRICT .'<br/>'.SITE_ADDR_CITY.','.SITE_ADDR_UF.' - '.SITE_ADDR_ZIP?></p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="address-widget foo" data-sr='enter'>
                        <div class="contact-icon"><i class="fa fa-phone"></i></div>
                        <h5>Telefones</h5>
                        <p>Telephone :<?= SITE_ADDR_PHONE_B?></p>
                        <p>WhatsApp :<?= SITE_ADDR_PHONE_A?></p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-4">
                    <div class="address-widget foo" data-sr='enter'>
                        <div class="contact-icon"><i class="fa fa-globe"></i></div>
                        <h5>Emai & Web</h5>
                        <p><?= SITE_ADDR_EMAIL?></p>
                        <p><?= SITE_ADDR_SITE?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 col-md-8 col-md-offset-2">
                    <div class="form-area-row foo" data-sr='enter'>
                        <div class="form-area-title">
                            <h2>Como podemos ajuda-lo ?</h2>
                        </div>
                        <div class="form-area">
                            <div class="cf-msg"></div>
							 <div class="wc_contact_error jwc_contact_error"></div>
							<form action="" id="contact-form" class="form-inline jwc_contact_form" id="cf" name="wc_send_contact" method="post" enctype="multipart/form-data">  
                            
                                <div class="row">
                                    <ul class="contact-form">
                                        <li class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="fname">Nome</label>
                                                <div class="input-group">
                                                    <input name="nome" value="" placeholder="Informe seu Nome:" id="fname" class="form-control2" >
                                                </div>
                                            </div>
                                        </li>
                                        <li class="col-xs-12 col-sm-6">
                                            <div class="form-group">
                                                <label for="fname">Email:</label>
                                                <div class="input-group">
                                                    <input type="email" class="form-control2" id="email"  name="email" value="" placeholder="Informe seu E-mail:">
                                                </div>
                                            </div>
                                        </li>
                                        <li class="col-xs-12">
                                            <div class="form-group">
                                                <label for="subject">Tel</label>
                                                <div class="input-group">
                                                    <input  name="phone" value="" placeholder="Informe seu Telefone:"  id="subject" class="form-control2">
                                                </div>
                                            </div>
                                        </li>
                                        <li class="col-xs-12">
                                            <div class="form-group">
                                                <label for="fname">Mensagem</label>
                                                <div class="input-group">
                                                   <textarea name="message"  placeholder="Deixe uma mensagem:"  class="form-control2 form-message" id="msg" required/></textarea>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                    <div class="col-xs-12 text-center">
                                        <button class="btn btn-default btn-form">ENVIAR</button>
										
										<img style="display: none;" src="<?= BASE; ?>/_cdn/widgets/contact/images/load.gif" alt="Aguarde, enviando contato!" title="Aguarde, enviando contato!"/>
										
									</div>
                                </div>
                           </form>
						<div style="display: none;" class="wc_contant_sended jwc_contant_sended">
							<p class="h2"><span>&#10003;</span><br>Mensagem enviada com sucesso!</p>
							<p><b>Prezado(a) <span class="jwc_contant_sended_name">NOME</span>. Obrigado por entrar em contato,</b></p>
							<p>Informamos que recebemos sua mensagem, e que vamos responder o mais breve possível.</p>
							<p><em>Atenciosamente <?= SITE_NAME; ?>.</em></p>
							<span class="btn btn_red jwc_contact_close" style="margin-top: 20px;">FECHAR</span>
						</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Contact Form Section -->
    </div>


 
				
               