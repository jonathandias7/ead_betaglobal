  <?php
   require '_cdn/widgets/ecommerce/cart.inc.php';
  require '_cdn/widgets/contact/contact.wc.php';
        require '_cdn/widgets/modal.php';
        require '_cdn/widgets/mdpmodais/campusmodal.php';
        require '_cdn/widgets/mdpmodais/loginmodal.php';
       
?>


<?
///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////*HEADER(LOGO,SEARCH,MENU DESKTOP E MENU MOBILE)*/////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
?>

<style>
    /* Header Area*/
   .header-area{
      background:<?= $background;?>!important;
       
   }
    
    /* Botoes Menu*/
   .main-menu ul li{
      background:<?= $btncolor;?>!important;
       
   }
   .main-menu ul li:hover{
      background:<?= $btnhover;?>!important;
       
   }
   
   /*Fontes menu */
    .main-menu ul li a{
      color:<?= $fonte;?>!important;
       
   }
   .main-menu ul li a:hover{
      color:<?= $fontehover;?>!important;
       
   }
   
    
</style>
<!--HEADER-->
<header style='<?= $cor;?>' class="main_header <?= $classcolor;?> ">
    <div class="container">
        <div class="main_header_logo">
            <h1><a class="transition" title="Home" href="<?= BASE?>"><img style='background-size:3%;  margin-top:10px;max-width:200px;max-height:100px;'src="<?= INCLUDE_PATH?>/images/logo.png" alt="" /></a></h1>
        </div>

       <nav class="main_header_nav">
            <span class="main_header_nav_mobile j_menu_mobile_open icon-menu icon-notext radius transition"></span>
            <div style='background:transparent' class="main_header main_header_nav_links j_menu_mobile_tab">
                <span class="main_header_nav_mobile_close j_menu_mobile_close icon-error icon-notext transition"></span>
                <a  class="<?= $classmenu;?> active" title="Home" href="<?= BASE?>">Home</a>
				 <?php $Read->FullRead("SELECT page_type_serv,page_title, page_name FROM " . DB_PAGES . " WHERE page_status = 1 AND page_type_serv = 0 ORDER BY page_order ASC, page_name ASC");
								if ($Read->getResult()):?>
                                    <a style='display:none' class="<?= $classmenu;?> active" title="Sobre" href="<?= BASE?>/about">Sobre</a>
        				    <?php
        				        endif; 
				                    if(empty(MDP_HEADER_SERVICOS_MANUTENCAO)):?>
								     <li><a  class="<?= $classmenu;?>" href="<?= BASE;?>/servicos">Serviços</a></li>
							        <?php
							        endif;
							        if(APP_EAD && empty(MDP_HEADER_CURSOS_MANUTENCAO)):?>
									 <li><a title="Conheça os cursos da MDP" class="<?= $classmenu;?>" href="<?= BASE?>/cursos">Cursos</a></li>
									 <?php endif;
									 if(APP_ORDERS && !empty(APP_PRODUCTS) && empty(MDP_HEADER_LOJA_MANUTENCAO)):?>
									 <li><a title="Conheça a Loja MDP " class="<?= $classmenu;?>" href="<?= BASE?>/nossaloja" >Loja</a></li>
                            <?php
                            endif;
						    if(APP_POSTS && empty(MDP_HEADER_BLOG_MANUTENCAO)):
										//BLOG
										$Read->ExeRead(DB_CATEGORIES, "WHERE category_parent IS NULL AND category_id IN(SELECT post_category FROM " . DB_POSTS . " WHERE post_status = 1 AND post_date <= NOW()) ORDER BY category_title ASC");
										if ($Read->getResult()):
											foreach ($Read->getResult() as $Cat):
												echo "<li><a class='<?= $classmenu;?> active' title='{$Cat['category_title']}' href='" . BASE . "/artigos/{$Cat['category_name']}'>{$Cat['category_title']}</a>";
												$Read->ExeRead(DB_CATEGORIES, "WHERE category_parent = :ct ORDER BY category_name ASC", "ct={$Cat['category_id']}");
												if ($Read->getResult()):
													echo "<ul class='sub'>";
													foreach ($Read->getResult() as $SubCat):
														echo "<li><a title='{$SubCat['category_title']}' href='" . BASE . "/artigos/{$SubCat['category_name']}'>{$SubCat['category_title']}</a></li>";
													endforeach;
													echo "</ul>";
												endif;
												echo "</li>";
											endforeach;
										endif;
										ENDIF;?>
									
						
               <?php /* $Read->FullRead("SELECT cat_id, cat_title, cat_name FROM " . DB_PDT_CATS . " WHERE cat_parent IS NULL AND cat_id IN(SELECT pdt_category FROM " . DB_PDT . " WHERE pdt_status = 1) ORDER BY cat_title ASC");
                if ($Read->getResult()):
                    echo "<li class='link transition radius'><span>Nossa Loja</span><ul class='sub'>";
                    foreach ($Read->getResult() as $NavSectors):
                        echo "<li><a title='{$NavSectors['cat_title']}' href='" . BASE . "/produtos/{$NavSectors['cat_name']}'>{$NavSectors['cat_title']}</a>";
                        $Read->FullRead("SELECT cat_title, cat_name FROM " . DB_PDT_CATS . " WHERE cat_parent = :cat_id ORDER BY cat_title ASC", "cat_id={$NavSectors['cat_id']}");
                        if ($Read->getResult()):
                            echo "<ul class='subsub'>";
                            foreach ($Read->getResult() as $NavProductsCat):
                                echo "<li><a title='{$NavProductsCat['cat_title']}' href='" . BASE . "/produtos/{$NavProductsCat['cat_name']}'>{$NavProductsCat['cat_title']}</a></li>";
                            endforeach;
                            echo "</ul>";
                        endif;
                        echo "</li>";
                    endforeach;
                    echo "</ul></li>";
                endif;	*/?>
									   	<?PHP if(isset($_SESSION['userLogin'])):?>
                                    <li><a title="Você está logado" class="link login transition radius icon-sign-in">Logado como: <?= $_SESSION['userLogin']['user_name'];?></a>
									<ul class='sub'>
									   <li><a title="Acessr minha conta" class="link transition radius icon-sign-in" href="<?= BASE?>/conta">Acessar Minha Conta</a></li>
									 	        <?php if(APP_EAD && empty(MDP_HEADER_CURSOS_MANUTENCAO)):?>
									  <li><a title="Acessar meu campus" class="link transition radius icon-sign-in" href="<?= BASE?>/campus">Acessar Meu Campus</a></li>
									 	        <?php endif;?>
									  </ul>
									</li>
									<?php else: ?>
									<li><a title="Fale Conosco" class="link login transition radius icon-sign-in">Fazer Login</a>
									<ul class='sub'>
									    <li><a title="Acessar meu campus" class="link transition radius icon-sign-in" href="<?= BASE?>/conta">Minhas Conta</a></li>
									    <li style='display:none'>  <form class='mdp_form' name="account_form" action="" method="post" enctype="multipart/form-data">
         <input name="callback" type='hidden' value='Forms' />
         <input name="callback_action" type='hidden' value='login' />
         <?php
               echo"<button  type='submit'    class='link transition radius icon-sign-in'>Acessar</button>";?>
                <img class="wc_load" style='display:none;' alt="Aguarde" title="Aguarde" src="<?= BASE; ?>/_cdn/widgets/comments/load.gif"></button>
                </form></li>
									     <?php if(APP_EAD && empty(MDP_HEADER_CURSOS_MANUTENCAO)):?>
									  <li><a title="Acessar meu campus" class="link transition radius icon-sign-in" href="<?= BASE?>/campus">Meu Campus</a></li>
									    <?php endif;?>
									  </ul>
									</li>
									<?php
									endif;	?>
									  
                
            </div>
        </nav>
    </div>
</header>

      <?php /*  <!-- Start of header area -->
        <header class="header-area header-wrapper">
			<!-- Header Top Area Start -->
			<div style="background:linear-gradient(to left,rgb(0,0,0),rgb(20,177,187))" class="header-top-area">
			   <div class="container">
					<div class="row">
						<!-- Header Top Left Start -->
						<div class="col-md-6 col-sm-7 col-xs-12">
							<div class="header-left ptb-15">
								<ul>
									<li style="color:#fff"><span style="color:#fff"><i style="color:#fff" class="zmdi zmdi-phone"></i></span><a style="color:#fff" href="#"><?= SITE_ADDR_PHONE_A?></a></li>
									<li><span><i  style="color:#fff"class="zmdi zmdi-email"></i></span><a style="color:#fff" href="#"><?= SITE_ADDR_EMAIL?></a></li>
								</ul>
							</div>
						</div>
						<!-- Header Top Left End -->
						<!-- Header Top Right Start -->
						<div class="col-md-6 col-sm-5 col-xs-12">
							<div class="header-right social-icon pull-right">
								<ul>
								
								
										<?php
										if(SITE_SOCIAL_FB_PAGE):
										?>
										<li>
											<a href="https://www.facebook.com/<?= SITE_SOCIAL_FB_PAGE; ?>" target="_blank" title="<?= SITE_NAME; ?> no Facebook">
											<i class="zmdi zmdi-facebook"aria-hidden="true"></i>
											</a>
										</li>
										 <?php
										 endif;
										 if(SITE_SOCIAL_TWITTER):
										 ?>
											<li>
												<a href="https://www.twitter.com/<?= SITE_SOCIAL_TWITTER; ?>" target="_blank" title="<?= SITE_NAME; ?> no Twitter">
													<i class="zmdi zmdi-twitter" aria-hidden="true"></i>
												</a>
											</li>
										<?php
										 endif;
										 if(SITE_SOCIAL_INSTAGRAM):
										 ?>
											<li>
												<a href="https://www.instagram.com/<?= SITE_SOCIAL_INSTAGRAM; ?>" target="_blank" title="<?= SITE_NAME; ?> no Instagram">
													<i class="zmdi zmdi-instagram" aria-hidden="true"></i>
												</a>
											</li>
										 <?php
										 endif;
										 if(SITE_SOCIAL_GOOGLE_PAGE):
										 ?>
											<li>
												<a href="https://plus.google.com/<?= SITE_SOCIAL_GOOGLE_PAGE; ?>" target="_blank" title="<?= SITE_NAME; ?> no Google+">
													<i class="zmdi zmdi-google-plus" aria-hidden="true"></i>
												</a>
											</li>
										 <?php
										 endif;
										 ?>
           		
									<li class="search-active">
									   <a href="#"><i class="zmdi zmdi-search"></i></a>
										<div class="search-form">
											 <form class="search_form" name="search" action="" method="post" enctype="multipart/form-data">
												<input name="s" id="search"  autocomplete="off" placeholder="Search" type="text">
											</form>
										</div>
									</li>
								</ul>
							</div>
						</div>
						<!-- Header Top Right End -->
					</div>
			   </div>
			</div>
			<!-- Header Top Area End -->
			<!-- Header Menu Area Start -->
			<div class="main-menu-area broder-top ptb-25" id="sticky-header">
				<div class="container">
					<div class="row">
						<!-- Logo Area -->
						<div class="col-md-2 col-sm-12 col-xs-12">
							<div class="logo-area">
								<a href="<?= BASE?>"><img src="<?= INCLUDE_PATH?>/images/logo/logo-gapol.png" alt="" /></a>
							</div>
						</div>
						<!-- Logo Area -->
						<!-- Menu Area -->
						<div class="col-md-10 col-sm-12 hidden-xs">
							<div class="main-menu">
								<nav>
									<ul id="nav">
											
													<li><a href="<?= BASE;?>">Home</a></li>
								<li><a href="<?= BASE;?>/sobre-a-empresa">Sobre</a></li>
								<li><a title="Fale Conosco" href="#" id='cplans'>Planos</a></li>
							<!--	<li><a href="<?= BASE;?>/informacao/detalhes/informacoes">Informações</a></li>-->
                               <li><a href="<?= BASE;?>">Serviços</a>
									<ul class="dropdown_menu">
									  <?  $Read->FullRead("SELECT page_type_serv,page_title, page_name FROM " . DB_PAGES . " WHERE page_status = 1 ORDER BY page_order ASC, page_name ASC");
										if ($Read->getResult()):
											foreach ($Read->getResult() as $Page):
											if($Page['page_type_serv'] >= '1'):
												echo "<li><a title='{$Page['page_title']}' href='" . BASE . "/servico/detalhes/{$Page['page_name']}'>{$Page['page_title']}</a></li>";
											endif;
											endforeach;
										endif;
										?>
									</ul>
								</li>
								
                                <?php
										//BLOG
										$Read->ExeRead(DB_CATEGORIES, "WHERE category_parent IS NULL AND category_id IN(SELECT post_category FROM " . DB_POSTS . " WHERE post_status = 1 AND post_date <= NOW()) ORDER BY category_title ASC");
										if ($Read->getResult()):
											foreach ($Read->getResult() as $Cat):
												echo "<li><a title='{$Cat['category_title']}' href='" . BASE . "/artigos/{$Cat['category_name']}'>{$Cat['category_title']}</a>";
												$Read->ExeRead(DB_CATEGORIES, "WHERE category_parent = :ct ORDER BY category_name ASC", "ct={$Cat['category_id']}");
												if ($Read->getResult()):
													echo "<ul>";
													foreach ($Read->getResult() as $SubCat):
														echo "<li><a title='{$SubCat['category_title']}' href='" . BASE . "/artigos/{$SubCat['category_name']}'>{$SubCat['category_title']}</a></li>";
													endforeach;
													echo "</ul>";
												endif;
												echo "</li>";
											endforeach;
										endif;
										?>
									   <li><a title="Fale Conosco" class="jwc_contact" href="#">Contato</a></li>
									   
												</ul>
											</div>	
										</li>
									</ul>
								</nav>
							</div>
						</div>
						<!-- Menu Area -->
					
				

				<!-- MOBILE-MENU-AREA START --> 
				<div  class="mobile-menu-area" class="col-md-12 col-sm-12">
					<div class="container">
						<div class="row">
							<div  class="col-md-12 col-sm-12">
								<div class="mobile-area">
									<div class="mobile-menu">
										<nav id="mobile-nav">
											<ul >
												<li style='background:#fff!importante;padding-bottom:20px;'style='' ><a href="<?= BASE?>">Home </a>
													<ul>
														<li><a href="<?= BASE;?>">Home</a></li>
								<li><a href="<?= BASE;?>/sobre-a-empresa">Sobre</a></li>
								<li><a title="Fale Conosco" href="#" id="cplans">Planos</a></li>
							<!--	<li><a href="<?= BASE;?>/informacao/detalhes/informacoes">Informações</a></li>-->
                               <li><a href="<?= BASE;?>">Serviços</a>
									<ul class="dropdown_menu">
									  <?  $Read->FullRead("SELECT page_type_serv,page_title, page_name FROM " . DB_PAGES . " WHERE page_status = 1 ORDER BY page_order ASC, page_name ASC");
										if ($Read->getResult()):
											foreach ($Read->getResult() as $Page):
											if($Page['page_type_serv'] >= '1'):
												echo "<li><a title='{$Page['page_title']}' href='" . BASE . "/servico/detalhes/{$Page['page_name']}'>{$Page['page_title']}</a></li>";
											endif;
											endforeach;
										endif;
										?>
									</ul>
								</li>
								
                                <?php
										//BLOG
										$Read->ExeRead(DB_CATEGORIES, "WHERE category_parent IS NULL AND category_id IN(SELECT post_category FROM " . DB_POSTS . " WHERE post_status = 1 AND post_date <= NOW()) ORDER BY category_title ASC");
										if ($Read->getResult()):
											foreach ($Read->getResult() as $Cat):
												echo "<li><a title='{$Cat['category_title']}' href='" . BASE . "/artigos/{$Cat['category_name']}'>{$Cat['category_title']}</a>";
												$Read->ExeRead(DB_CATEGORIES, "WHERE category_parent = :ct ORDER BY category_name ASC", "ct={$Cat['category_id']}");
												if ($Read->getResult()):
													echo "<ul>";
													foreach ($Read->getResult() as $SubCat):
														echo "<li><a title='{$SubCat['category_title']}' href='" . BASE . "/artigos/{$SubCat['category_name']}'>{$SubCat['category_title']}</a></li>";
													endforeach;
													echo "</ul>";
												endif;
												echo "</li>";
											endforeach;
										endif;
										?>
									   <li><a title="Fale Conosco" class="jwc_contact" href="#">Contato</a></li>
									   
											</ul>
										</nav>
									</div>	
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- MOBILE-MENU-AREA END  -->
			</div>
			<!-- Header Menu Area End -->
        </header> */ ?>