<?php

$cid = '';
if($URL[1]):
$Read->ExeRead(DB_PDT_CATS, "WHERE cat_name = :cat", "cat={$URL[1]}");
if ($Read->getResult()):
$cid = " (pdt_category = '". $Read->getResult()[0]['cat_id'] ."' OR pdt_subcategory = '". $Read->getResult()[0]['cat_parent'] ."') AND ";
endif;

endif;

?>


		<section class="blog_page">
    <header class="blog_page_header">
        <h1 style='color:#fff'>NOSSA LOJA</h1>
          <!-- formulario Inscrição que sera enviado pro ajax-->
            <form class="wc_form" action="" method="post" enctype="multipart/form-data">
                <?php
                $Read = new Read();
                   $Read->FullRead("SELECT cat_id,cat_title, cat_name FROM " . DB_PDT_CATS . " WHERE cat_id IN(SELECT pdt_category FROM " . DB_PDT . " WHERE pdt_status = 1) ORDER BY cat_title ASC");
                if ($Read->getResult()):
                   
                    echo "<label style='width:99%;padding:3%' ><select style='width:95%!important;border:none;font-size:0.9em'  id='categoria'>";
                    echo "<option value=''>Filtrar por categoria</option>";
                    foreach ($Read->getResult() as $cat):
                         
                        if($cat['cat_title']):
                            echo "<option ";
                            if($URL[1] == $cat['cat_name']):
                                
                            echo" selected='selected'";
                            endif;
                        echo " value='{$cat['cat_name']}'>{$cat['cat_title']}</option>";
                       endif;
                    endforeach;
                     echo "<option value=''>Todos itens da loja</option>";
                    echo "</select></label>";
                endif;
                ?>
                <script>
                $('html').on('change','#categoria', function(){
                var cats =  $(this).val();
                if(cats){
                    window.location.href="<?= BASE?>/produtos/"+ cats;
                }else{
                     window.location.href="<?= BASE?>/produtos/";
                }
                
                });
                </script>
    </form> 
         <form name="searchp" action="" method="post" enctype="multipart/form-data">
            <label>
                <input type="text" name="sp" placeholder="pesquisar produto ex: template,apps, scripts,etc..."/>
                <button class="icon-search icon-notext"></button>
            </label>
        </form>
    </header>
	<header style='margin-top:50px;'class="blog_header">
            <h2>LOJA DO DESENVOLVEDOR</h2>
     
        </header>

        <div class="home_features">
    <section class="container">
	<?php
						
                            $Read->ExeRead(DB_PDT, "WHERE {$cid} pdt_status = 1 ORDER BY pdt_title ASC");
								
								if($Read->getResult()):?>
        
        <div style='margin-top:4%'  class="home_features_content">
		 <?PHP
									foreach($Read->getResult() as $pdt_all):
							
								if(isset($pdt_all['pdt_cover'])):
								?>
            <article class="radius">
                <header>
                    <a href='<?= BASE ."/produto/". $pdt_all['pdt_name']?>' title='clique para acessar a pagina <?= $pdt_all['pdt_title']?>'><img style='' alt="<?= $pdt_all['pdt_name'];?>" title="<?= $pdt_all['pdt_title'];?>" style='min-height:300px;' src="<?= BASE;?>/tim.php?src=uploads/<?= $pdt_all['pdt_cover'];?>&w=<?= THUMB_W / 3?>&h=<?= THUMB_H / 2?>"/></a>
                    <h3  style='color:var(--color-blue);' id='tit'><?= $pdt_all['pdt_title'];?></h3>
                   <!-- <p><?= $desc;?></p>-->
                </header>
               
            </article>
			<?php
					
					endif;
					
					endforeach; 
			
				?>
        </div>
		<?php
		endif;
				?>
    </section>
</div>
	