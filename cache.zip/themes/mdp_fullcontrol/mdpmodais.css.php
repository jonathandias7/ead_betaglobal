<style>
    
.wc_boxs{
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 3999999;
    display: flex;
}

.mdp_newsletter{
    display: flex;
}
.wc_box_modal{
    margin: auto;
    width: 700px;
    position: relative;
}

.wc_box_modal_title{
    padding: 20px;
    font-size: 1.2em;
    text-transform: uppercase;
    font-weight: bold;
    text-align: center;
    color: #fff;
    background: #0A537D;
}

.wc_box_modal_content{
    padding: 30px;
    background: #fff;
}

.wc_box_modal_close{
    position: absolute;
    right: -15px;
    top: -20px;
    font-size: 1.2em;
    color: #fff;
     padding: 7px 12px;
    border-radius: 50%;
    -moz-border-radius: 50%;
    -webkit-border-radius: 50%;
    background:#F45563;
    text-shadow: 1px 1px #000;
    cursor: pointer;
}

.wc_box_modal_close:hover{
    color: #F45563;
     background:#Fbfbfb;
}

.wc_box_modal_content form input,
.wc_box_modal_content form select{
    margin-bottom: 20px;
    padding: 15px;
    font-size: 0.875rem;
}

.wc_actions img{
    display: inline-block;
    vertical-align: middle;
    margin-top: -5px;
    margin-left: 10px;
}

.wc_content{
    display: block;
    width: 80%;
    margin: 30px auto;
	border: solid 3px #ccc;
}

.wc_content h1{
    text-align: center;
    font-size: 1.6em;
    color: #ccc;
	padding-top:30px;
    margin-bottom: 30px;
}
</style>