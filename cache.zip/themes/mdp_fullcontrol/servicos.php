<?php
if (!$Read):
    $Read = new Read;
endif;

$Read->ExeRead(DB_PAGES, "WHERE page_status = 1 AND page_type_serv >= 1");
if (!$Read->getResult()):
    require REQUIRE_PATH . '/404.php';
    return;
endif;

?>
		<section class="blog_page">
    <header class="blog_page_header">
        <h1 style='color:#fff'>PORTFÓLIO</h1>
       
        <form name="searchs" action="" method="post" enctype="multipart/form-data">
            <label>
                <input type="text" name="ss" placeholder="pesquisar serviço ex: Marketing"/>
                <button class="icon-search icon-notext"></button>
            </label>
        </form>
    </header>
	<header style='margin-top:50px;'class="blog_header">
            <h2>NOSSOS SERVICOS</h2>
            <p>A MDP engloba todo ramo web.Somos especializados em <b>Desenvolvimento Web</b>.Veja abaixo o que podemos fazer por você ou sua empresa.:</p>
     
        </header>

        <div class="home_features">
    <section class="container">
	<?php
								$Read->ExeRead(DB_PAGES, "WHERE page_status = 1 AND page_type_serv = 1 ORDER BY page_order ASC, page_name ASC");
								
								if($Read->getResult()):?>
        
        <div style='margin-top:4%'  class="home_features_content">
		 <?PHP
									foreach($Read->getResult() as $page_all):
									$countServ = $Read->getRowCount($page_all);
									$desc = Check::Words($page_all['page_content'], 6);
								if(isset($page_all['page_cover'])):
								?>
            <article style='padding:1%;' class="radius">
                <header>
                    <a href='<?= BASE ."/servico/detalhes/". $page_all['page_name']?>' title='clique para acessar a pagina <?= $page_all['page_title']?>'><img style='min-width:300px;height:220px;width:100%;margin:0;padding:0' alt="<?= $page_all['page_name'];?>" title="<?= $page_all['page_title'];?>" src="<?= BASE;?>/uploads/<?= $page_all['page_cover'];?>"/></a>
                     <h3 style='color:var(--color-blue);'><?= $page_all['page_title'];?></h3>
                   <!-- <p><?= $desc;?></p>-->
                </header>
            </article>
			<?php
					
					endif;
					
					endforeach; 
			
				?>
        </div>
		<?php
		endif;
				?>
    </section>
</div>
		 