$(function () {
    //HELLOBAR CONTROL
   
       
	   
      // chamando os scripts 
	  $.getScript(BASE + "/_cdn/widgets/hellobar/hellobar.wc.js", function(){ 
	  $("head").append("<link rel='stylesheet' href='"+BASE+"/_cdn/widgets/hellobar/hellobar.wc.css'/>");
		  
		  
		  
	  }) ;
	  
	   // chamando os scripts 
	  $.getScript(BASE + "/_cdn/widgets/event/event.wc.js", function(){ 
	  $("head").append("<link rel='stylesheet' href='"+BASE+"/_cdn/widgets/event/event.wc.css'/>");
		  
		  
		  
	  }) ;
	
	  	 
   
	
	
    $('.main_nav_mobile_menu').click(function () {
        $('.main_nav ul').slideToggle();
    });
});