<?php

class BasicCheckoutMP extends MP 
{
    use MercadoPagoDataTrait;
    use TraitsWC;
    
    private $mp_instance;
    private $client_id;
    private $client_secret;
    private $errors = [];
    
    /**
     * Informe o seu token que pode ser 
     * para SANDBOX ou PRODUÇÃO.
     * 
     * Você pode obter essas informações através da URI https://www.mercadopago.com/mlb/account/credentials
     * Para isso basta fazer login na sua conta do Mercado Pago
     * 
     * @param string $token
     */
    public function __construct()
    {
        $this->client_id = MP_CLIENT_ID;
        $this->client_secret = MP_CLIENT_SECRET;
        $this->mp_instance = new MP($this->client_id, $this->client_secret);
        ((int)MP_BASIC_MODE === 0 ? $this->mp_instance->sandbox_mode(true) : $this->mp_instance->sandbox_mode(false));
    }
    
        
    /**
     * Mercado Pago basic checkout
     */
    public function preferenceData($data = [])
    {
        return [
            "items" => [
                $data['items']
//                "title" => '',
//                "desciption" => '',
//                "picture_url" => '',
//                "quantity" => '',
//                "unit_price" => '',
            ],
            "payer" => [
                "name" => $data['name'],
                "surname" => $data['surname'],
                "email" => $data['email'],
                "phone" => [
                    "area_code" => $data['phone_area_code'],
                    "number" => $data['phone_number']
                ],
                "identification" => [
                    "type" => $data['document_type'],
                    "number" => $data['document_number']
                ],
                "address" => [
                    "zip_code" => $data['zip_code'],
                    "street_name" => $data['street_name'],
                    "street_number" => $data['street_number']
                ]
            ],
            "payment_methods" => [
                "excluded_payment_methods" => [],
                "excluded_payment_types" => [],
                "default_payment_method_id" => '',
                "installments" => '',
                "default_installments" => ''
            ],
            "shipments" => [
                "mode" => $data['mode'],
                "local_pickup" => $data['local_pickup'],
                "dimensions" => $data['dimensions'],
                "default_shipping_method" => $data['default_shipping_method'],
                "free_methods" => [],
                "cost" => $data['cost'],
                "free_shipping" => $data['street_number'],
                "receiver_address" => [
                    "zip_code" => $data['receive_zip_code'],
                    "street_name" => $data['receive_street_name'],
                    "street_number" => $data['receive_street_number'],
                    "floor" => $data['receive_floor'],
                    "apartment" => $data['receive_apartment']
                ]
            ],
            "back_urls" => [
                "success" => $data['success'],
                "pending" => $data['pending'],
                "failure" => $data['failure']
            ],
            "notification_url" => $data['notification_url'],
            "auto_return" => $data['auto_return'],
            "differential_pricing" => []
        ];
    }
}
