<?php

trait MPResourcesTrait 
{
    /**
     * Get an resource
     * 
     * @param string $uri
     * @param array $filters
     * @param array $headers
     * @param boolean $authenticate
     * @return array
     */
    public function resourceGet($uri, $filters = [], $headers = [], $authenticate = false)
    {
        return $this->mp_instance->get($uri, $filters, $headers, $authenticate);
    }
    
    /**
     * Post an resource
     * 
     * @param string $uri
     * @param array $filters
     * @param array $headers
     * @param boolean $authenticate
     * @return array
     */
    public function resourcePost($uri, $filters = [], $headers = [], $authenticate = false)
    {
        return $this->mp_instance->post($uri, $filters, $headers, $authenticate);
    }
    
    /**
     * Delete an resource
     * 
     * @param string $uri
     * @param array $filters
     * @param array $headers
     * @param boolean $authenticate
     * @return array
     */
    public function resourceDelete($uri, $filters = [], $headers = [], $authenticate = false)
    {
        return $this->mp_instance->delete($uri, $filters, $headers, $authenticate);
    }
    
    /**
     * Update an resource
     * 
     * @param string $uri
     * @param array $filters
     * @param array $headers
     * @param boolean $authenticate
     * @return array
     */
    public function resourceUpdate($uri, $filters = [], $headers = [], $authenticate = false)
    {
        return $this->mp_instance->put($uri, $filters, $headers, $authenticate);
    }
}