<?php 

class Product
{
    private $mp;
    private $post;
    private $read;
    private $update;
    private $create;
    private $delete;
    private $callback = [];
    private $order_items = [];
    private $status_detail;
    private $total_fee;
    private $coupon_name;
    
    public function __construct($post = [])
    {
        $this->post = $post;
        $this->read = new Read;
        $this->update = new Update;
        $this->create = new Create;
        $this->delete = new Delete;
        $this->mp = new MPCrud;
        unset($this->post['action']);
    }
    
    public function payWithBillet()
    {
        $order = $this->mp->getOrder($_SESSION['wc_payorder']['order_id']);
        $order_value = (float)$order['order_price'];
        $customer = $this->createCustomer();
        $this->setItems();
        $paydata = [
            "transaction_amount" => $order_value,
            "description" => "LOJA MDP Pedido #" . str_pad($order['order_id'], 7, 0, STR_PAD_LEFT),
            "payment_method_id" => "bolbradesco",
            "payer_id" => $customer['response']['id'] ?? null,
            "statement_descriptor" => SITE_NAME,
            "items" => $this->order_items,
        ];
        $pay = $this->mp->billetPay($paydata);

        if(!empty($pay['status'])):
            if($pay['status'] === 200 || $pay['status'] === 201):
                $this->mp->updateOrder($order['order_id'], [
                    'order_provider' => 1,
                    'order_payment' => 102,
                    'order_code' => $pay["response"]["id"],
                    'order_billet' => $pay["response"]["transaction_details"]["external_resource_url"],
                    'order_status' => $pay["response"]['status'],
                    'order_installments' => 1,
                    'order_installment' => $order_value,
                ]);

                return $this->callback = ['success' => true, 'link_billet' => $pay['response']['transaction_details']['external_resource_url']];
            else:
                return $pay;
            endif;  
        else:
            return $pay;
        endif;
    }
    
    public function payWithCreditCard()
    {
        $order = $this->mp->getOrder($_SESSION['wc_payorder']['order_id']);
        $order_value = (float)$order['order_price'];
        $customer = $this->createCustomer();
        $this->setItems();
        $this->setCouponDiscount((!empty($order['order_coupon_id'])  ? $order['order_coupon_id'] : 0));
        $pay = $this->mp->creditCardPay([
            "transaction_amount" => $order_value,
            "description" => "LOJA MDP  Pedido #{$order['order_id']}",
            "payment_method_id" => $this->post['payment_method_id'],
            "statement_descriptor" => SITE_NAME,
            "coupon_amount" => (!empty($order['order_coupon_id']) ? (float)$order_value * ((100 - $order['order_coupon']) / 100) : ""),
            "coupon_code" => $this->coupon_name ?? "",
            "external_reference" => $order['order_id'],
            "payer_id" => $customer['response']['id'] ?? null,
            "card_token_id" => $this->post['card_token_id'],
            "installments" => (int)explode("x", $this->post['cardInstallmentQuantity'])[0],
            "items" => $this->order_items,
        ]);

        if(!empty($pay['response'])):
            $this->getFee($pay['response']['fee_details']);

            if($pay['status'] === 200 || $pay['status'] === 201):
                (!empty($customer['response']) ? $this->mp->creditCardCreate($customer['response']['id'], $this->post['card_token_id']) : null);
                
                $this->getCcStatus($pay['response']);
                $this->mp->updateOrder($order['order_id'], [
                    'order_provider' => 1,
                    'order_payment' => 101,
                    'order_code' => $pay["response"]["id"],
                    'order_status' => $pay["response"]['status'],
                    'order_installments' => (int)explode("x", $this->post['cardInstallmentQuantity'])[0],
                    'order_installment' => (int)explode("x", $this->post['cardInstallmentQuantity'])[1],
                    'order_free' => $this->total_fee,
                    'order_rejected_reason' => $pay['response']['status_detail'],
                    'order_status_details' => $this->status_detail,
                ]);

                return $this->callback = ['success' => true, 'pay_status' => $pay['response']['status'], 'status_detail' => $this->status_detail];
            else:
                return $pay;
            endif;
        else:
            return $pay;
        endif;
    }
    
    private function setCouponDiscount($coupon_id)
    {
        if(!empty($coupon_id)):
            $this->read->ExeRead(DB_PDT_COUPONS, 'WHERE cp_id = :cpi', "cpi={$coupon_id}");
            if($this->read->getRowCount() > 0):
                $this->coupon_name = $this->read->getResult()[0]['cp_coupon'];
            endif;
        endif;
    }
    
    private function userBuyIsEqualUserPay()
    {
        $get_order = $this->mp->getOrder($_SESSION['wc_payorder']['order_id']);
        if($get_order['user_id'] !== $_SESSION['userLogin']['user_id']):
            return ['error' => ['confirm_pay', 'Você está pagando uma ordem que não foi gerada à partir da sua conta. O pagamento será realizado, porém os produtos serão entregues ao usuário que originou este pedido.']];
        endif;
    }
    
    private function setItems()
    {
        $this->read->ExeRead(DB_ORDERS_ITEMS, 'WHERE order_id = :oid', "oid={$_SESSION['wc_payorder']['order_id']}");
        if($this->read->getRowCount() > 0):
            $this->order_items = [];
            foreach($this->read->getResult() as $items):
                $this->read->ExeRead(DB_PDT, 'WHERE pdt_id = :pid', "pid={$items['pdt_id']}");
                if($this->read->getRowCount() > 0):
                    $product = $this->read->getResult()[0];
                    $ItemPrice = ($product['pdt_offer_price'] && $product['pdt_offer_start'] <= date('Y-m-d H:i:s') && $product['pdt_offer_end'] >= date('Y-m-d H:i:s') ? $product['pdt_offer_price'] : $product['pdt_price']);
                
                    $this->order_items[] = [
                        'id' => $product['pdt_id'],
                        'title' => $product['pdt_title'],
                        'description' => $product['pdt_subtitle'],
                        'picture_url' => BASE . '/uploads/' . $product['pdt_cover'],
                        'quantity' => $items['item_amount'],
                        'unit_price' => $ItemPrice,
                    ];
                endif;
            endforeach;
        endif;
        
        return $this->order_items;
    }
    
    private function createCustomer()
    {
        return $this->mp->customerCreate(["email" => $this->mp->getUserAndAddress()['user_email']],$this->mp->customerObject());
    }
    
    private function getFee($fee)
    {
        if($fee):
            foreach($fee as $i => $v):
                if ($v['type'] === 'mercadopago_fee'):
                    $this->total_fee = $v['amount'];
                endif;
            endforeach;
        endif;
        
        return $this->total_fee;
    }
    
    private function getCcStatus($response)
    {
        switch($response['status_detail']):
            case 'cc_rejected_insufficient_amount'      : $this->status_detail = 'Saldo insuficiente'; break;
            case 'pending_contingency'                  : $this->status_detail = 'Seu pagamento está sendo processado pela operadora do seu cartão. Em menos de 1 hora será enviado o resultado por e-mail.'; break;
            case 'pending_review_manual'                : $this->status_detail = 'Seu pagamento está sendo processado pela operadora do seu cartão. Em menos de 2 dias úteis você será avisado por e-mail se o pagamento foi aprovado ou se é preciso mais informações.'; break;
            case 'cc_rejected_call_for_authorize'       : $this->status_detail = 'É necessário solicitar autorização ao Mercado Pago para pagar com esse cartão'; break;
            case 'cc_rejected_bad_filled_security_code' : $this->status_detail = 'Rejeitado pelo código de segurança'; break;
            case 'cc_rejected_bad_filled_date'          : $this->status_detail = 'Rejeitado pela data de vencimento'; break;
            case 'cc_rejected_bad_filled_other'         : $this->status_detail = 'Existem erros nos dados informados. Revise os dados.'; break;
            case 'cc_rejected_bad_filled_card_number'   : $this->status_detail = 'Verifique o número do cartão.'; break;
            case 'cc_rejected_blacklist'                : $this->status_detail = 'Não foi possível processar o pagamento.'; break;
            case 'cc_rejected_card_disabled'            : $this->status_detail = 'Ligue para <b>' . $response['payment_method_id'] . '</b> e ative o seu cartão. O telefone está no verso do seu cartão de crédito.'; break;
            case 'cc_rejected_card_error'               : $this->status_detail = 'Não foi possível processar o pagamento.'; break;
            case 'cc_rejected_duplicated_payment'       : $this->status_detail = 'Você já fez um pagamento desse valor. Se você precisa pagar novamente, use outro cartão ou outro meio de pagamento.'; break;
            case 'cc_rejected_high_risk'                : $this->status_detail = 'O seu pagamento foi recusado. Recomendamos que você pague com outros meios de pagamento oferecidos, preferencialmente à vista.'; break;
            case 'cc_rejected_max_attempts'             : $this->status_detail = 'Você atingiu o limite de tentativas permitidas. Use outro cartão ou outro meio de pagamento.'; break;
            case 'cc_rejected_invalid_installments'     : $this->status_detail = '<b>' . $response['payment_method_id'] . '</b> não processa pagamentos em <b>' . $response['installments'] . '</b> parcelas.'; break;
            default                                     : $this->status_detail = null; break;
        endswitch;
        
        return $this->status_detail;
    }
}