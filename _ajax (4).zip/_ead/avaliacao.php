<?php
 if(!empty($URL[1])):
 require 'avaliacao/index.php';
 endif;


?>
