<?php
$Read = new Read;
$AvId = filter_input(INPUT_GET,'exercicio');
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="mit" content="2018-03-01T13:54:20-03:00+29430">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        
        <link rel="stylesheet" href="<?= BASE;?>/_ead/avaliacao/_cdn/bootcss/reset.css"/>
        <link rel="stylesheet" href="<?= BASE;?>/_ead/avaliacao/_cdn/bootcss/fonticon.css"/>
        <link rel="stylesheet" href="<?= BASE;?>/_ead/avaliacao/style.css"/>
    </head>
    <body>
     
        <div class="wc_box">
	         <!--AVALIÇÃO MODAL(QUESTIONARIO)-->
             <div class="wc_box_modal mdp_av_opp">
                <span class="icon-cross icon-notext wc_box_modal_close"></span>
                <p class="wc_box_modal_title">AVALIAÇÃO:</p>
                <div class="wc_box_modal_content">
                    <div class="jwc_return"></div>
                    <form class="wc_form jwc_form_opp" name="perg_add" action="" method="POST">
                       <input type="hidden" name="callback" value="AvFull"/>
                        <input type="hidden" name="callback_action" value="PergResp"/>
					   <input type="hidden" name="perg_id" value=""/>
					    <input type="hidden" name="user_id" value="<?= $_SESSION['userLogin']['user_id']?>"/>
					     <input type="hidden" name="av_his_ind_date" value=""/>
					   <input type="hidden" name="avaliacao_id" value=""/>
					   <input disabled="disabled" name="perg_title" style="font-size:1.2em;background:#00b594;color:#fff; border:solid 2px gray;" value=""/>
					  <div class="jwc_content_op">
						
						</div>
                        <div style="padding-right:1%;"class="al_right wc_actions">
						
                            <button class="btn btn_blue btn_medium ">RESPONDER</button>
							<a class="btn btn_green btn_medium icon-checkmark" href="<?=BASE?>/campus/avaliacao/aula&exercicio=<?=$AvId?>">CONFIRMAR</a>
                            <img class="wc_load" style="display:none;" src="<?= BASE;?>/_ead/avaliacao/_cdn/bootcss/load.gif" alt="Cadastrando usuário!" title="Cadastrando usuário!"/>
                        </div>
						<br/>
					
                    </form>
                </div>
            </div> 
			
		<!--AVALIÇÃO MODAL(RESULTADO)
             <div class="wc_box_modal mdp_av_result">
                <span class="icon-cross icon-notext wc_box_modal_close"></span>
                <p class="wc_box_modal_title">Resultado:</p>
                <div class="wc_box_modal_content">
                    <div class="jwc_return"></div>
                    <form class='wc_form jwc_form_op' name='op_add' action='' method='POST'>
                        <input type='hidden' name='callback' value='AvFull'/>
                        <input type='hidden' name='callback_action' value='op_resposta'/>
						<input type='hidden' name='perg_id' value='171'  />
						<div class='jwc_content op_con'>
						<input type='hidden' name='op_id' value=''  />
						<? $Read->ExeRead(DB_EAD_AVALIACAO_RESPOSTAS," WHERE perg_id = 171");
						foreach($Read->getResult() as $opt):
						 echo "<label style='padding-left:10%;'><p class='row'>{$opt['op_content']}<input type='checkbox' name='op_id' value='{$opt['op_id']}'></p></label>";
						endforeach;
						?>
						</div>
                        <div style='padding-right:10%;'class='al_right wc_actions'>
                            <button class='btn btn_green btn_medium icon-books'>Ir para o campus</button>
                            <img class='wc_load' style='display: none;' src='_cdn/bootcss/load.gif' alt='Cadastrando usuário!' title='Cadastrando usuário!'/>
                        </div>
						<br/>
					
                    </form>
                </div>
			
            
			 </div> -->
        </div>

        <div class="wc_content">
		
		<?
		$getExe = filter_input(INPUT_GET,'exercicio');
		$Read->ExeRead(DB_EAD_EXE," WHERE exe_id = :exe","exe={$getExe}");
		if($Read->getRowCount()):
		extract($Read->getResult()[0]);
	
		//set
		$nota = $exe_result / 100  ;
		endif;?>
		
            <h1>EXERCÍCIO:</h1>
          <h3 class="al_center"> Modulo:</b><?= $module_id?> | <b>Valor do Exercicio:</b><?=$exe_result?> <span style="display:none;" class="btn btn_green icon-user-plus wc_create">Conferir o Resultado</span></h3>
			<?php
			$Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS," WHERE avaliacao_id = $exe_id ORDER BY perg_title ASC LIMIT $exe_qtd ");
			
            if (!$Read->getResult()):
                echo Erro("<span class='al_center icon-info ds_block'>Desculpe, mas não existem perguntas cadastrados!</span>", E_USER_NOTICE);
            else:
                echo "<div class=''></div>";
				$nQtd = 0;
				
               
				foreach ($Read->getResult() as $U):
				
                    extract($U);
				  $Read->ExeRead(DB_EAD_AVALIACAO_HI," WHERE avaliacao_id = :id AND perg_id = :perg","id={$exe_id}&perg={$perg_id}");
				
					$type = 'NÃO RESPONDIDA';
					$pergtype = " btn_yellow";
					
					$nQtd++;
                    echo "<div class='ead_resposta' id='{$perg_id}'>"
                    . "<p class='row'><a class='title'> {$nQtd}ª - Pergunta:</a> {$perg_title}?</a></p>"
					. "<p class='row al_right'>"
					. "<input type='hidden' name='perg_type' value='{$type}'>";
				
                    if($Read->getResult()):
					extract($Read->getResult()[0]);
					$type = 'RESPONDIDA';
					$pergtype = " btn_green";
					echo "<a class='title'>Situação:</a><a class='btn {$pergtype} wc_tooltip' style='width:100px'><span class='wc_tooltip_balloon' >Marque a opção correta</span>{$type}</a>
					<a style='display:none' class='btn btn_blue wc_tooltip mdp_opp' id='{$perg_id}' data-c='AvFull' data-ca='getPerg'><span class='wc_tooltip_balloon'>Clique aqui para Responder</span>Responder</a>";
					else:
					echo "<a class='title'>Situação:</a><a class='btn {$pergtype} wc_tooltip' style='width:100px'><span class='wc_tooltip_balloon' >Marque a opção correta</span>{$type}</a>
					<a  class='btn btn_blue wc_tooltip mdp_opp' id='{$perg_id}' data-c='AvFull' data-ca='getPerg'><span class='wc_tooltip_balloon'>Clique aqui para Responder</span>Responder</a>";
					endif;
					echo "</div>";
					
                endforeach;
            endif;
            ?>
        </div>

        <script src="<?= BASE;?>/_cdn/jquery.js"></script>
        <script src="<?= BASE;?>/_ead/avaliacao/js/scripts.js"></script>
    </body>
</html>
