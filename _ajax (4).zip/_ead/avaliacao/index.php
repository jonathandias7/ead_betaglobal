<?php

 if($URL[2] == 'modulo'):
 require 'avaliacao.php';
 elseif($URL[2] == 'aula'):
 require  'exercicio.php';
 else:
 
   header('Location:../campus');
 
 endif;



?>