<?php
$Read = new Read;
$Update = new Update;
$Create = new Create;
$getAv = filter_input(INPUT_GET,'prov');
$getUser = filter_input(INPUT_GET,'user');

			$Read->ExeRead(DB_EAD_AVALIACAO_HI," WHERE avaliacao_id = :id AND user_id = :user","id={$getAv}&user={$getUser}");
			
			if(!$Read->getResult()):
			$HiDate = date(DATE_W3C);
			$t = [
			'av_his_ind_date' => $HiDate,
			'user_id' => $getUser,
			'avaliacao_id' => $getAv,
			];
			$Create->ExeCreate(DB_EAD_AVALIACAO_HI, $t);
			
			Header("Location:" . BASE ."/campus/avaliacao/modulo&prov={$getAv}&ta=sdfsodfjsdof,dfshodfsjvklcvncklvz&user={$getUser}&MDP=MDP-SOFTWARES-LTDA");
			
			else:
			$Read->ExeRead(DB_EAD_AVALIACAO_HI," WHERE avaliacao_id = :id AND user_id = :user","id={$getAv}&user={$getUser}");
			if($Read->getResult()):
			extract($Read->getResult()[0]);
			endif;
			
			$HiDate = date(DATE_W3C);
			$ti = [
			'av_his_end_date' => $HiDate
			];
			$i = date("i", strtotime($av_his_ind_date));
			$f = date("i", strtotime($av_his_end_date));
			$a =  date("i", strtotime($HiDate));
			$Read->ExeRead(DB_EAD_AVALIACAO," WHERE avaliacao_id = :id","id={$getAv}");
			 if ($Read->getResult()):
			extract($Read->getResult()[0]);
			$time =   $avaliacao_time - $i;
			$ts =  $i - $a;
			for($tt = $ts; $tt < $avaliacao_time ; $tt++):
			$t = $tt;
			endfor;
			else:
			$t = $ts + $avaliacao_time;
			endif;
			if($t == 0):
			$HiDate = date(DATE_W3C);
			$ti = [
			'av_his_end_date' => $HiDate
			];
			$Update->ExeUpdate(DB_EAD_AVALIACAO_HI, $ti, "WHERE avaliacao_id = :id AND user_id = :user","id={$getAv}&user={$getUser}");
			if($Update->getResult()):
			
			$up = date("d/m/Y h:i:s", strtotime( $Update->getResult()[0]));
			//ho $up;
			//cabou";
			endif;
			endif;
			
			endif;	




		
		$Read->ExeRead(DB_EAD_AVALIACAO," WHERE avaliacao_id = :id ","id={$getAv}");
		if($Read->getResult()):
		
		extract($Read->getResult()[0]);
		
		//set
		$Read->ExeRead(DB_EAD_AVALIACAO_H," WHERE avaliacao_id = :id AND user_id = :user","id={$getAv}&user={$getUser}");
			if($Read->getResult()):
			extract($Read->getResult()[0]);
					$HiDate = date(DATE_W3C);
	
				if($res_refazer_status == 1 && $res_refazer_date >= $HiDate):
					echo "<div class='trigger bg_blue'><h1 style='padding:20px auto;font-size:1.5em;' class=' al_center ds_block'>Você Só poderá Realizar outra Avaliação no dia: <br/>". date("d/m/Y h:i:s", strtotime($res_refazer_date)) ." Horas</h1></div>";
					echo"<script>alert('A sua data de liberação será exibida e após você será redirecionado para a página de cursos em 5 segundos');</script><meta http-equiv='refresh' content='3; url=". BASE."/campus'>";
					
					die;
				endif; 
		
			endif;
		endif;
		?>
		
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="mit" content="2018-03-01T13:54:20-03:00+29430">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <link rel="stylesheet" href="<?= BASE;?>/_ead/avaliacao/_cdn/bootcss/reset.css"/>
        <link rel="stylesheet" href="<?= BASE;?>/_ead/avaliacao/_cdn/bootcss/fonticon.css"/>
        <link rel="stylesheet" href="<?= BASE;?>/_ead/avaliacao/style.css"/>
		
		<script type="text/javascript">
	
		</script>
    </head>
	
    <body onload="start();" >
	
        <div class="wc_box">
	         <!--AVALIÇÃO MODAL(QUESTIONARIO)-->
             <div class="wc_box_modal mdp_av_opp">
                <p class="wc_box_modal_title">AVALIAÇÃO:</p>
                <div class="wc_box_modal_content">
                    <div class="jwc_return"></div>
                    <form class="wc_form jwc_form_opp" name="perg_add" action="" method="POST">
                       <input type="hidden" name="callback" value="AvFull"/>
                        <input type="hidden" name="callback_action" value="PergResp"/>
					   <input type="hidden" name="perg_id" value=""/>
					    <input type="hidden" name="user_id" value="<?= $_SESSION['userLogin']['user_id']?>"/>
					     <input type="hidden" name="av_his_ind_date" value=""/>
					   <input type="hidden" name="avaliacao_id" value=""/>
					   <input disabled="disabled" name="perg_title" style="font-size:1.2em;background:#00b594;color:#fff; border:solid 2px gray;" value=""/>
					
					<div class="jwc_content_op">
					
						</div>
							
                        <div style="padding-right:1%;"class="al_right wc_actions">
						 <a style="display:none;" href="<?= BASE?>/campus/avaliacao/modulo&prov=<?= $getAv?>&ta=NewMdpNomeodmeCD342402+GNDSPFRMC3439201dfshodfsjvklcvncklvz&user=<?= $getUser ?>&MDP=MDP-SOFTWARES-LTDA" id='teet2' class="btn btn_blue btn_medium">Confirmar</a>
                            <button id="teet" class="btn btn_green btn_medium icon-checkmark">Responder</button>
							<img class="wc_load" style="display:none;" src="<?= BASE;?>/_ead/avaliacao/_cdn/bootcss/load.gif" alt="Cadastrando usuário!" title="Cadastrando usuário!"/>
                        </div>
						<br/>
					
                    </form>
                </div>
            </div> 
			
			
		<!--AVALIÇÃO MODAL(RESULTADO)-->
             <div class="wc_box_modal mdp_av_result">
                <span class="icon-cross icon-notext wc_box_modal_close"></span>
                <p class="wc_box_modal_title">Resultado:</p>
                <div class="wc_box_modal_content">
                    <div class="jwc_return"></div>
                    <form class="wc_form jwc_form_result" name="av_result" action="" method='POST'>
                      <input type="hidden" name="callback" value="AvFull"/>
                        <input type="hidden" name="callback_action" value="av_result"/>
						 <input type="hidden" name="user_id" value=""/>
					     <input type="hidden" name="avaliacao_id" value=""/>
							  <label class="label">
							 <input type="hidden" name="avaliacao_title" value=""/>
							 
							  </label>
							  <div class="jwc_content_res">
							  <?php
                
                $Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS," WHERE avaliacao_id = :id AND user_id = :user","id={$getAv}&user={$getUser}");
			  if ($Read->getResult()):
			  extract($Read->getResult()[0]);
                         $Read->FullRead("SELECT op_id, op_content FROM " . DB_EAD_AVALIACAO_RESPOSTAS . "  WHERE perg_id = :perg", "perg={$perg_id}");
                        if ($Read->getResult()):
                 
                            foreach ($Read->getResult() as $op):
											print_r($op);                               
							   echo "<label class='label_check'><p class='row'><input type='checkbox' name='op_id[]' value='{$op['op_id']}'";
                                if (in_array($op['op_id'], explode(',', $op_id))):
                                    echo " checked";
                                endif;
                                echo "> {$op['op_content']}</label></p>";
                            endforeach;
                        endif;
					 endif;	
                  
               
                ?>
						 
						
						 
						 <label class="label">
						  <input type="hidden" name="avaliacao_qtd" value=""/>
						    </label><label class="label">
				           <input type="hidden" name="res_valor_av" value=""/>
						     </label><span class="legend"><label class="label">
						   <input type="hidden" name="res_nota_av" value=""/>
						    </label>
						 
						   
						 
						 
						  
						
						</div>
                        <div style='padding-right:10%;'class='al_right wc_actions'>
                            <button style="display:none" class='btn btn_green btn_medium icon-books'>Concluir avaliação</button>
                            <img class='wc_load' style='display:none;' src='<?= BASE;?>/_ead/avaliacao/_cdn/bootcss/load.gif' alt='Cadastrando usuário!' title='Cadastrando usuário!'/>
                        </div>
						<br/>
					
                    </form>
                </div>
			
            
			 </div> 
        </div>

        <div  class="wc_content">
		

			<input name="time" type="hidden" value="<?= $t;?>">
            <h1 id='ti'>Av: <?=$avaliacao_title ?> | </span><div style="display:block;" class="btn btn_medium bg_blue wc_tooltip" name="tempo" id="tempo" ></div><span style="display:none" class="btn btn_green icon-user-plus mdp_av">Conferir o Resultado</span></h1>
          <h3 id="sobreav" style="display:none" class="al_center"> Modulo:</b><?= $module_id?> | <b>Quantidade:</b> <?=$avaliacao_qtd?> | <b>Valor da Av:</b><?=$avaliacao_result?> | <b> Nota min:</b> <?=$avaliacao_aprovado?></h3>
		
			
			<?php
			$Read->ExeRead(DB_EAD_AVALIACAO_HI," WHERE avaliacao_id = :id AND user_id = :user","id={$getAv}&user={$getUser}");
			 if ($Read->getResult()):
			extract($Read->getResult()[0]);
			endif;
			$Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS," WHERE avaliacao_id = $avaliacao_id ORDER BY perg_title ASC LIMIT $avaliacao_qtd ");
			
            if (!$Read->getResult()):
            Header("Location:". BASE ."/campus");
            else:
                echo "<div class=''></div>";
				$nQtd = 0;
				
               
				foreach ($Read->getResult() as $U):
				
                    extract($U);
				  $Read->ExeRead(DB_EAD_AVALIACAO_HI," WHERE avaliacao_id = :id AND perg_id = :perg","id={$avaliacao_id}&perg={$perg_id}");
				  if($Read->getResult()):
					$type = 'RESPONDIDA';
					$pergtype = " btn_green";
				  else:
					$type = 'NÃO RESPONDIDA';
					$pergtype = " btn_yellow";
					endif;
					$nQtd++;
                    echo "<div style='display:none' class='ead_resposta' id='{$perg_id}'>"
                    . "<p class='row'><a class='title'> {$nQtd}ª - Pergunta:</a> {$perg_title}?</a></p>"
					. "<p class='row al_right'>"
					. "<input type='hidden' name='perg_type' value='{$type}'>";
				
                    if($Read->getResult()):
					extract($Read->getResult()[0]);
					$type = 'RESPONDIDA';
					$pergtype = " btn_green";
					echo "<a class='title'>Situação:</a><a class='btn {$pergtype} wc_tooltip' style='width:100px'><span class='wc_tooltip_balloon' >Marque a opção correta</span>{$type}</a>
					<a style='display:none' class='btn btn_blue wc_tooltip mdp_opp' id='{$perg_id}' data-c='AvFull' data-ca='getPerg'><span class='wc_tooltip_balloon'>Clique aqui para Responder</span>Responder</a>";
					else:
					echo "<a class='title'>Situação:</a><a class='btn {$pergtype} wc_tooltip' style='width:100px'><span class='wc_tooltip_balloon' >Marque a opção correta</span>{$type}</a>
					<a  class='btn btn_blue wc_tooltip mdp_opp' id='{$perg_id}' data-c='AvFull' data-ca='getPerg'><span class='wc_tooltip_balloon'>Clique aqui para Responder</span>Responder</a>";
					endif;
					echo "</div>";
					
                endforeach;
            endif;
			
            ?>
			<form class="wc_forms" name="av_result" action="" method="POST">
                       <input type="hidden" name="callback" value="AvFull"/>
                        <input type="hidden" name="callback_action" value="av_result"/>
					    <input type="hidden" name="user_id" value="<?= $getUser?>"/>
					     <input type="hidden" name="avaliacao_id" value="<?=$avaliacao_id;?>"/>
						   <input type="hidden" name="avaliacao_result" value="<?=$avaliacao_result?>"/>
						   <input type="hidden" name="avaliacao_aprovado" value="<?=$avaliacao_aprovado?>"/>
						      <input type="hidden" name="avaliacao_title" value="<?=$avaliacao_title?>"/>
							  <input type="hidden" name="avaliacao_qtd" value="<?=$avaliacao_qtd?>"/>
							  <input type="hidden" name="avaliacao_refazer_status" value="<?=$avaliacao_refazer_status?>"/>
							  <input type="hidden" name="avaliacao_refazer_date" value="<?=$avaliacao_refazer_date?>"/>
                        <div style="padding-right:1%;padding-top:20px;"class="al_center wc_actions">
                            <button style="display:none;" id='fim' class="btn btn_blue btn_medium">Finalizar Prova</button>
							<img class="wc_load" style="display:none;" src="<?= BASE;?>/_ead/avaliacao/_cdn/bootcss/load.gif" alt="Cadastrando usuário!" title="Cadastrando usuário!"/>
                        </div>
						<br/>
			 </form>
        </div>

     
       
		<script>
		$('.wc_form').submit(function () {
		$('#teet').fadeOut();
		$('#teet2').fadeIn(900);
		
		});
	
			$('#resposta').fadeOut();
		$('.mdp_opt').fadeIn(2000);
		$('.ead_resposta').fadeIn(2000);
		$('#tempo').fadeIn(3000);
		$('#sobreav').fadeIn(900);
		$('#fim').fadeIn(2000);
		 
		 
			 
		
			$('.wc_forms').submit(function () {
			$('.wc_forms').fadeOut(500);
				$('#resposta').fadeOut();
			$('#tempo').fadeOut(700);
			$('.ead_resposta').fadeOut(800);
			$('#sobreav').fadeOut(900);
			$('.mdp_av').fadeIn(1000);
			$('#ti').fadeIn(500);
				
			});
		var count=new Number();
		var count= <?= $t ?>;
		count=count+1;
		
		function start(){
			if((count - 1) >= 0){
			count=count - 1;
			if(count == 0){
				alert("Meu querido, infelizmente o tempo determinado para realizar essa avaliação chegou ao fim. Por favor, finalize a avaliação para visualizar sua nota.");
					$('#sobreav').fadeOut(500);
					$('#ti').fadeOut(500);
					$('.ead_resposta').fadeOut(500);
					$('#tempo').fadeOut(500);
					$('#fim').fadeIn(2000);
		 
				
	
			}
			else if(count < 10){
				count="0"+count+1;
				
			}
				
			tempo.innerText=count;
			setTimeout('start();',60000);
			
		
				
			}
		}
	         $('.close').click(function () {
			// $('.jwc_content_op').remove();
		// $(data.jwc_content_op).addClass('jwc_content_op');		
		
		 
        $('.wc_box').fadeOut(400, function () {
            $(this).find('.wc_box_modal').fadeOut(200, function () {
                $(".trigger_ajax").remove();
					
            });
        });
    });
			
			</script>
			
		 <script src="<?= BASE;?>/_ead/avaliacao/js/scripts.js"></script>
    </body>
</html>
