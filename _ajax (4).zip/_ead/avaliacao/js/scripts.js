$(function () {
    //EVENTOS RESPOSTA
	
  $('.wc_cart_size_select').click(function () {
        var maxInventory = $(this).attr('id');
        $('input[name="op_id"]').val('1').val();

        $('.wc_cart_size_select').removeClass('wc_cart_size_select_true');
        $(this).addClass('wc_cart_size_select_true');
    });

    if ($('.wc_cart_size_select_true').length) {
        $('input[name="op_id"]').attr('id').val();
    }

    //FECHA MODAL
    $('.wc_box_modal_close').click(function () {
			// $('.jwc_content_op').remove();
		// $(data.jwc_content_op).addClass('jwc_content_op');		
		
		 
        $('.wc_box').fadeOut(400, function () {
            $(this).find('.wc_box_modal').fadeOut(200, function () {
                $(".trigger_ajax").remove();
					
            });
        });
    });
	$('.wc_add_close').click(function () {
		
        $('.wc_add').fadeOut(400, function () {
            $(this).find('.wc_add_box').fadeOut(200, function () {
                $(".trigger_ajax").remove();

            });
        });
    });
    //ABRE CADASTRO
   
	  //ABRE CADASTRO
    $('.mdp_av').click(function () {
		 $('.wc_box').fadeIn().css('display', 'flex').find('.mdp_av_opp').fadeOut(10);
        $('.wc_box').fadeIn().css('display', 'flex').find('.mdp_av_result').fadeIn(500);
		
    });
	 
	
 	 //ABRE OP
    $(".ead_resposta").on("click", ".mdp_opp", function () {
        var perg_id = $(this).attr("id");
        var callback = $(this).attr("data-c");
        var callback_action = $(this).attr("data-ca");
        $.post(BASE+"/_ead/avaliacao/_ajax/" + callback + ".ajax.php", {perg_id: perg_id, callback_action: callback_action}, function (data) {
			 $('.wc_box').fadeIn().css('display', 'flex').find('.mdp_av_result').fadeOut();	
			$('.wc_box').fadeIn().css('display', 'flex').find('.mdp_av_opp').fadeIn(function () {
         
			if (data.trigger) {
                    setTimeout(function () {
                        $('.jwc_return').html(data.trigger).fadeIn();
                    }, 500);
                }

                if (data.form) {
                    var Form = $(data.form);
                   $.each(data.result, function (key, value) {
					 Form.find("input[name='" + key + "'],select[name='" + key + "'],checkbox[name='" + key + "']").val(value);
					
					 });
					 
					
				}
	
				 if (data.jwc_content_op) {
                  $('.jwc_content_op').before(data.jwc_content_op);
				  
                }
				
			 
				
					 $('.jwc_content_op').toggleClass('jwc_content_op');
					 
				// $(data.jwc_content_op).removeClass('jwc_content_op');		
				 // $(data).addClass('jwc_content_op');		
            });
			
		//$(data).removeClass('jwc_content_op

			
        }, 'json');
		
  return false;
		 
	
    });
	
		
    //AÇÃO PADRÃO DE FORMULÁRIO
    $('.wc_form').submit(function () {
		
        var Form = $(this);
        var Action = Form.find('input[name="callback"]').val();
        var Data = Form.serialize();
        

      $.ajax({
            url: BASE+"/_ead/avaliacao/_ajax/"+ Action + ".ajax.php",
            data: Data,
            type: 'POST',
            dataType: 'json',
            beforeSend: function (xhr) {
                Form.find(".wc_load").fadeIn();
                $(".jwc_return").fadeOut();
            },
            success: function (data) {
                if (data.trigger) {
                    setTimeout(function () {
                        $('.jwc_return').html(data.trigger).fadeIn();
                    }, 500);
                }
				
					 if (data.jwc_content_op) {
                  $('.jwc_content_op').before(data.jwc_content_op);
				  
                }
				
			 
				
					// $('.jwc_content_op').toggleClass('jwc_content_op');
					 
                if (data.content) {
                    $(data.content[0]).html(data.content[1]);
					
                }

                if (data.clear) {
                    Form.trigger('reset');
                }


                Form.find(".wc_load").fadeOut();
				
            }
			
			
        }); 
		
        return false;
    });

	  $('.wc_forms').submit(function () {
        var Form = $(this);
        var Action = Form.find('input[name="callback"]').val();
        var Data = Form.serialize();


      $.ajax({
            url: BASE+"/_ead/avaliacao/_ajax/"+ Action + ".ajax.php",
            data: Data,
            type: 'POST',
            dataType: 'json',
            beforeSend: function (xhr) {
                Form.find(".wc_load").fadeIn();
                $(".jwc_return").fadeOut();
            },
            success: function (data) {
                if (data.trigger) {
                    setTimeout(function () {
                        $('.jwc_return').html(data.trigger).fadeIn();
                    }, 500);
                }
				 if (data.form) {
                    var Form = $(data.form);
                    $.each(data.result, function (key, value) {
					Form.find("input[name='" + key + "'], select[name='" + key + "']").val(value);
                    });
                }

                if (data.content_res) {
                    $('.jwc_content_res').before(data.content_res);
                }

                if (data.clear) {
                    Form.trigger('reset');
                }


                Form.find(".wc_load").fadeOut();
            }
        }); 
		
        return false;
    });
	
});