<?php

session_start();
require '../../_app/Config.inc.php';
$NivelAcess = 6;
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
if (empty($_SESSION['userLogin']) || empty($_SESSION['userLogin']['user_level']) || $_SESSION['userLogin']['user_level'] < $NivelAcess):
    $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPPSSS:</b> Você não tem permissão para essa ação ou não está logado como administrador!', E_USER_ERROR);
    echo json_encode($jSON);
    die;
endif;

usleep(50000);

//DEFINE O CALLBACK E RECUPERA O POST
$jSON = null;
$CallBack = 'AvFullead';
$PostData = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//VALIDA AÇÃO
if ($PostData && $PostData['callback_action'] && $PostData['callback'] == $CallBack):
    //PREPARA OS DADOS
    $Case = $PostData['callback_action'];
    unset($PostData['callback'], $PostData['callback_action']);
	/*****************************/
	/**** AÇÕES INSTANCIADAS *****/
	/*****************************/
    $Read = new Read;
    $Create = new Create;
    $Update = new Update;
    $Delete = new Delete;

 
	
	////////////////////////////////////////////////////////////////////////
	//////////////////////////* CREATE DA AVALIACAO *///////////////////////
	////////////////////////////////////////////////////////////////////////
    
 /*****************************/
 /***** BATERIA DA APP AV *****/
 /*****************************/
	switch ($Case):
	
	case 'avaliacao_create':
	$getTitle = $PostData['avaliacao_title'];
	//Converte o tempo em segundos
	$getTime = $PostData['avaliacao_time'];
	$timeTotal = $getTime * 60 ;
	
	/////////////////////////////////
	
	$Read->FullRead("SELECT avaliacao_title FROM " . DB_EAD_AVALIACAO . " WHERE avaliacao_title = :title", "title={$PostData['avaliacao_title']}");
	 
	 switch($Read->getResult()):
	 case(!empty($getTitle)):

	 
	  $jSON['trigger'] = AjaxErro("<b class='icon-warning'>AVISO:</b>Meu querido, Já existe uma avaliação com esse mesmo nome {$PostData['avaliacao_title']}", E_USER_NOTICE);
		$jSON['redirect'] = "dashboard.php?wc=fullead/home&id=". $PostData['course_id'] ."&module=".$PostData['module_id'];
		
	break;
	default:

		//substitui os campos recebidos do formulario pelos campos tratados com as conversões criadas acima
	
		$PostData['avaliacao_time'] = $timeTotal;
		$Create->ExeCreate(DB_EAD_AVALIACAO, $PostData);
		$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b>Meu querido, sua avaliação foi criada com sucesso!<br/><b class='icon-clock'>Você está sendo redirecionado para pagina de avaliações:</b> Aguarde aguarde só mais um instante.");
		$jSON['redirect'] = "dashboard.php?wc=fullead/home&id={$PostData['course_id']}&module={$PostData['module_id']}";
	break;
	endswitch;
	
	 break;
	 	case 'avaliacao_manage':
            $getProvaId = $PostData['avaliacao_id'];
            unset($PostData['avaliacao_id']);

            $PostData['avaliacao_name'] = $getProvaId . "-" . Check::Name($PostData['avaliacao_title']);
            $Update->ExeUpdate(DB_EAD_AVALIACAO, $PostData, "WHERE avaliacao_id = :id", "id={$getProvaId}");
            $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> A prova <b>{$PostData['avaliacao_title']}</b> foi atualizada com sucesso!");
            break;

	
	
	///////FIM CREATE AVALIAÇÃO(arquivo.create.php/////////

	//EVAL MANAGER
       
		 	 
		////////////////////////////////////////////////////////////////////////
		///////////////////////* PERGUNTAS DA AVALIACAO *///////////////////////
		////////////////////////////////////////////////////////////////////////
		
		 
		   case 'pergunta_create':
			
			
		  
				
		 /*****************************/
		 /********** CREATE ***********/
		 /*****************************/

		
		
				break;		
					
								
				//////////////////////////////////////////////////////////////////////////	
					$Read->FullRead("SELECT * FROM " . DB_EAD_AVALIACAO_PERGUNTAS . " WHERE avaliacao_id = :id", "id={$AvId}");
					$r = $Read->getRowCount();
					
				
					
						switch($r):
							 case ($Read->getResult() != 0):

							$jSON['trigger'] = AjaxErro("<b class='icon-warning'>AVISO:</b>Meu querido, Já existe uma avaliação com esse mesmo nome {$PostData['perg_title']}", E_USER_NOTICE);
							
							$jSON['success'] = true;
													
							break;		
						endswitch;
			
  
			
			//////////////////////////////FIM DO CREATE//////////////////////////////////
			
			
			/*****************************/
		    /********** UPDATE ***********/
		    /*****************************/
			
			
			
			
			//////////////////////////////FIM DO UPDATE//////////////////////////////////
			 
			 /*****************************/
		     /********** DELETE ***********/
		     /*****************************/
			
			
			 case 'pergunta_delete':
				 $delAv =  $PostData['del_id'];
				//pega a questão pelo Id
				 $Read->FullRead("SELECT * FROM " . DB_EAD_AVALIACAO_PERGUNTAS);
				 $Delete->ExeDelete(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE avaliacao_id = :prov AND perg_id = :perg","prov={$delAv}&perg={$Read->getResult()[0]['perg_id']}");
				 $jSON['success'] = true;
		
		 break;
		 
    endswitch;

    //RETORNA O CALLBACK
    if ($jSON):
        echo json_encode($jSON);
    else:
        $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPSS:</b> Desculpe. Mas uma ação do sistema não respondeu corretamente. Ao persistir, contate o desenvolvedor!', E_USER_ERROR);
        echo json_encode($jSON);
    endif;
else:
    //ACESSO DIRETO
    die('<br><br><br><center><h1>Acesso Restrito!</h1></center>');
endif;