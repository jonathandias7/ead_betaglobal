<?php

require '../../../_app/Config.inc.php';
session_start();


$jSON = array();
$getPost = filter_input_array(INPUT_POST, FILTER_DEFAULT);

if (empty($getPost['callback_action'])):
    $jSON['trigger'] = AjaxErro("<span class='icon-cross al_center ds_block'>Uma ação não foi selecionada no formulário!</span>", E_USER_ERROR);
else:
    $Post = array_map("strip_tags", $getPost);
    $Action = $Post['callback_action'];
    unset($Post['callback'], $Post['callback_action']);

    $Create = new Create;
    $Read = new Read;
    $Update = new Update;
    $Delete = new Delete;

    switch ($Action):
      
		case'getPerg':
	$PergId = $Post['perg_id'];
	
	$Read->FullRead("SELECT avaliacao_id,perg_id,perg_title FROM ". DB_EAD_AVALIACAO_PERGUNTAS ." WHERE perg_id = :perg","perg={$PergId}");
		$jSON['form'] = ".jwc_form_opp";
		if($Read->getResult()):
		$perg_title = $Read->getResult()[0];
		$jSON['result'] = $perg_title;
		
		 $jSON['jwc_content_op'] = "";

			$PergId = $Post['perg_id'];
			
			
             $Read->FullRead("SELECT op_id,op_content FROM mdp_avaliacao_op WHERE perg_id = :id ", "id={$PergId}");
			
			//$ratioI = 0;
            foreach ($Read->getResult() as $aaa):
			extract($aaa);
			 $jSON['jwc_content_op'] .="<label style='padding-left:10%;'>{$op_content}<p class='row'><input type='checkbox' name='op_id' value='{$op_id}'></p></label>";
			  //if ($aaa['op_id'] != ''):
					//$ratioI ++;
            		// $jSON['jwc_content_op'] .="<label id='{$aaa['op_id']}' class='wc_cart_size_select " . ($ratioI == 1 ? "wc_cart_size_select_true" : "") . "'><input id='{$aaa['op_id']}' " . ($ratioI == 1 ? "checked='checked" : "") . " type='radio' name='op_id' value='{$aaa['op_id']}'>{$aaa['op_content']}</label>";
				// else:
                //    $jSON['jwc_content_op'] .="<input name='op_id' type='hidden' value='{$aaa['op_id']}'/>";
               // endif;
			  endforeach;
			
	
			endif;

		break;
		
		
		//update
		case'PergResp':
	
		$UserId = $Post['user_id'];
		$PergId = $Post['perg_id'];
		$AvId = $Post['avaliacao_id'];
		$OpId = $Post['op_id'];
		$HiDate = date(DATE_W3C);
		
		
		
			$Read->ExeRead(DB_EAD_AVALIACAO_HI," WHERE avaliacao_id = :id AND perg_id = :perg","id={$AvId}&perg={$PergId}");
			
			if(!$Read->getResult()):
			
			//EDITAR APOS A RESPOSTA DO FORM
			$IndIn = [
                'avaliacao_id' => $AvId,
				'user_id' => $UserId,
                'perg_id' => $PergId,
				'op_id' => $OpId,
				'av_his_ind_date'=> $HiDate
				];
              
		     $Create->ExeCreate(DB_EAD_AVALIACAO_HI, $IndIn); 
			  $Read->FullRead("SELECT op_sit FROM ". DB_EAD_AVALIACAO_RESPOSTAS ." WHERE perg_id = :perg AND op_id =  :op", "perg={$PergId}&op={$OpId}");
							if($Read->getResult()):
					$Update->ExeUpdate(DB_EAD_AVALIACAO_HI, $Read->getResult()[0], " WHERE perg_id = :perg AND op_id =  :op", "perg={$PergId}&op={$OpId}");
					
				$Read->FullRead("SELECT op_id,avaliacao_id, user_id FROM ". DB_EAD_AVALIACAO_HI ." WHERE op_sit < 1 AND op_id =  :op", "op={$OpId}");
							if($Read->getResult()):
						$Create->ExeCreate("av_res_err",$Read->getResult()[0]); 
						else:
						$Read->FullRead("SELECT op_id,avaliacao_id, user_id FROM ". DB_EAD_AVALIACAO_HI ." WHERE op_sit >= 1 AND op_id =  :op", "op={$OpId}");
				
						$Create->ExeCreate("av_res_acc",$Read->getResult()[0]); 
						
						endif;
					endif;
			  $jSON['trigger'] = AjaxErro("<span class=' al_center ds_block'><b>SUCESSO:</b>Sua Resposta foi confirmada com Sucesso!<br/><b>AVISO:</b>Não será mais possível Altera-la! </span>");
			 ELSE:
		    $jSON['content'] ="<p class='row al_right'>";
			 $jSON['content'] .="<a class='title'>Situação:</a><a class='btn btn_green wc_tooltip' style='width:100px'><span class='wc_tooltip_balloon' >Você já respondeu a essa pergunta!</span>Respondida</a>"
			."<a style='display:none;' class='btn btn_blue wc_tooltip mdp_opp' id='{$PergId}' data-c='AvFull' data-ca='getPerg'>";
			
			endif;
			
			$Read->FullRead("SELECT avaliacao_id,perg_id,perg_title FROM ". DB_EAD_AVALIACAO_PERGUNTAS ." WHERE perg_id = :perg","perg={$PergId}");
			extract($Read->getResult()[0]);
			$nQtd =0;
			
			$type = 'RESPONDIDA';
					$pergtype = " btn_green";
			$jSON['content'] =["#{$PergId}.ead_resposta", "<p class='row'><a class='title'> {$nQtd}ª - Pergunta:</a> {$perg_title}?</a></p>"
					. "<p class='row al_right'>"
					. "<input type='hidden' name='perg_type' value='{$type}'>"
					. "<a class='title'>Situação:</a><a class='btn {$pergtype} wc_tooltip' style='width:100px'><span class='wc_tooltip_balloon' >Marque a opção correta</span>{$type}</a>"];
					
					
		break;
		
		
		case'av_result':
		
		$UserId = $Post['user_id'];
		$Res = $Post['avaliacao_result'];
		$Refst = $Post['avaliacao_refazer_status'];
		$RefDat = $Post['avaliacao_refazer_date'];
		$Avtitle= $Post['avaliacao_title'];
		$AvQtd= $Post['avaliacao_qtd'];
		$NotMin = $Post['avaliacao_aprovado'];
		$AvId = $Post['avaliacao_id'];
		$date = date(DATE_W3C);
		$soma = 0;
				
				//EDITAR APOS A RESPOSTA DO FORM
			$Read->ExeRead(DB_EAD_AVALIACAO_H," WHERE avaliacao_id = :id AND user_id = :user","id={$AvId}&user={$UserId}");
			if(!$Read->getResult()):	
			$RefS = date('Y-m-d H:i:s', strtotime("+".$RefDat."days"));
			$IndIn = [
                'avaliacao_id' => $AvId,
				 'avaliacao_title' => $Avtitle,
				'user_id' => $UserId,
                'res_valor_av' => $Res,
				'res_nota_av' => $NotMin,
				'res_fez'=> $date,
				'res_refazer_status' => $Refst,
				'res_refazer_date' => $RefS
				];
              
		     $Create->ExeCreate(DB_EAD_AVALIACAO_H, $IndIn); 
			else:
			$RefS = date('Y-m-d H:i:s', strtotime("+".$RefDat."days"));
			$IndIn = [
				'res_refazer'=> $date,
				'res_refazer_date' => $RefS
				];
				$Update->ExeUpdate("av_res_acc", $IndIn, "WHERE avaliacao_id = :id AND user_id = :user","id={$AvId}&user={$UserId}");
								
			endif;
	
		
			    $resav = [
				 'avaliacao_id' => $AvId,
				 'avaliacao_title' => $Avtitle,
				'user_id' => $UserId,
                'res_valor_av' => $Res,
				'res_nota_av' => $NotMin,
				'avaliacao_qtd' => $AvQtd
								];
				$jSON['form'] = ".jwc_form_result";
				$jSON['result'] = $resav;
					   $jSON['content_res'] ="";
					   $tot = 0;
				 $Read->ExeRead("av_res_acc"," WHERE avaliacao_id = :id","id={$AvId}");
					$tot += $Read->getRowCount();
					   $NotAp = $tot;//pega a quantidade de perguntas acertadas para a nota final
						 $jSON['content_res'] .="<div style='padding-bottom: 40px;border-bottom:3px solid #eee;' class='label_50'><label style='width:48%;color:#fff'><p style='width:100%;' class='btn btn_medium bg_green'>Acertos: {$Read->getRowCount()}</p></label>";
				 $Read->ExeRead("av_res_err"," WHERE avaliacao_id = :id","id={$AvId}");
                 $tot += $Read->getRowCount();
				 $NotInd = $Res / $tot;//entrega o valor individual da questão
				 $nap = $NotInd * $NotAp;//multiplica pelo valor individual das questões
				$jSON['content_res'] .="<label style='padding-left: 1%; width:48%;color:#fff'><p style='width:100%;background:#FF6347;' class='btn btn_medium'>Erros: {$Read->getRowCount()}</p></label>";
				if($nap < $NotMin):
				
				 $jSON['content_res'] .="<label style='width:99%;padding-top: 10px; color:#fff'><p style='width:100%;background:red;' class='btn btn_medium'>Reprovado</p></label></div>";
				 else:
				 $aprov = ['res_aprovado_status' => 1];
				   
		        $Update->ExeUpdate(DB_EAD_AVALIACAO_H, $aprov, "WHERE avaliacao_id = :id AND user_id = :user","id={$AvId}&user={$UserId}"); 
				 $jSON['content_res'] .="<label style='width:99%;padding-top: 10px; color:#fff'><p class='btn btn_medium bg_green'>Aprovado</p></label></div>";
				 endif;
				 $jSON['content_res'] .="<div style='padding-top: 40px; class='label_50'><label style='width:48%;color:#fff'><p style='width:100%;' class='btn btn_medium bg_yellow'>Quantidade de Questões: {$tot}</p></label><label style='width:48%; padding-left: 1%; color:#fff'><p style='width:100%;background:#FFE4B5;' class='btn btn_medium'>Valor por questão: {$NotInd}</p></label><label style='width:48%; color:#fff'><p style='width:100%;background:#1584f6;' class='btn btn_medium'>Media da Avaliação {$NotMin}</p></label><label style='width:48%; padding-left: 1%; color:#fff'><p style='width:100%;background:#ADFF2F;' class='btn btn_medium'>Minha Pontuação: {$nap}</p></label></div>";
				 
				   
				 
				 
				 
		break;
		
        default :
            $jSON['trigger'] = AjaxErro("<span class='icon-cross al_center ds_block'>Uma ação não foi selecionada no formulário!</span>", E_USER_ERROR);
            break;
    endswitch;
endif;

echo json_encode($jSON);
