<?php
/*****************************
SUPORTE MDP SOFTWARES LTDA
PROJETO: MDP TUTORIAL
SOBRE: Sistema de Tutoriais dinamico.
Pietro Napoleão | atendimento@mdpempresarial.com.br
WhatsApp - Grupo/Suporte: (32) 9 9992-0439
Copyright (c) 2019 - 2020 MDP SOFTWARES LTDA

******************************
IMPORTANTE: É expressamente proibido compartilhar estes arquivos por
qualquer meio ou com terceiros. Seu uso é exclusivo e intransferível
para o profissional.Podendo ser comercializado apenas a clientes sobre seus serviços.

A violação dos direitos exclusivos do produtor MDP SOFTWARES LTDA sobre a obra
é crime, ART. 184 DO CÓDIGO PENAL.
******************************/
session_start();
require '../../_app/Config.inc.php';
$NivelAcess = 6;
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
if (empty($_SESSION['userLogin']) || empty($_SESSION['userLogin']['user_level']) || $_SESSION['userLogin']['user_level'] < $NivelAcess):
    $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPPSSS:</b> Você não tem permissão para essa ação ou não está logado como administrador!', E_USER_ERROR);
    echo json_encode($jSON);
    die;
endif;

usleep(50000);

//DEFINE O CALLBACK E RECUPERA O POST
$jSON = null;
$CallBack = 'MDPTuto';
$PostData = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//VALIDA AÇÃO
if ($PostData && $PostData['callback_action'] && $PostData['callback'] == $CallBack):
    //PREPARA OS DADOS
    $Case = $PostData['callback_action'];
    unset($PostData['callback'], $PostData['callback_action']);
	/*****************************/
	/**** AÇÕES INSTANCIADAS *****/
	/*****************************/
    $Read = new Read;
    $Create = new Create;
    $Update = new Update;
    $Delete = new Delete;

 
	

 /*****************************/
 /***** BATERIA DA APP MDP TUTORIAL *****/
 /*****************************/
	switch ($Case):
//////////////////////////
////////* PANEL */////////
//////////////////////////
case 'panel_edite':
	

	$P = $PostData['panel_id'];
	/////////////////////////////////
	
	$Read->ExeRead(DB_TUTORIAIS_PANEL,"WHERE panel_id = {$P}");
		if($Read->getResult()):
		  $jSON['trigger'] = AjaxErro("<b class='icon-info'>AVISO:</b><BR/>Meu querido, Todas as informações foram alteradas com<b> Sucesso</b>!");
		  $Update->ExeUpdate(DB_TUTORIAIS_PANEL, $PostData, "WHERE panel_id = :name","name={$P}");
		 $jSON['redirect'] = "dashboard.php?wc=mdptutorial/homep";
		endif;
		
	break;
		 case 'panel_delete':
		$delAv =  $PostData['del_id'];
		 $Read->FullRead("SELECT * FROM " . DB_TUTORIAIS_PANEL . " WHERE panel_id = :id", "id={$delAv}");
		 extract($Read->getResult()[0]);
		$Delete->ExeDelete(DB_TUTORIAIS_PANEL, "WHERE panel_id = :id","id={$delAv}");
		//$jSON['redirect'] = "dashboard.php?wc=fullead/home&id=". $course_id ."&module=".$module_id ;
		$jSON['success'] = true;
		
		 break;
//////////////////////////
////////* HOST *//////////
//////////////////////////
	
case 'host_edite':
	$h = $PostData['host_id'];
	$Read->ExeRead(DB_TUTORIAIS_HOST,"WHERE host_id = {$h}");
		if($Read->getResult()):
		  $jSON['trigger'] = AjaxErro("<b class='icon-info'>AVISO:</b><BR/>Meu querido, Todas as informações foram alteradas com<b> Sucesso</b>!");
		  $Update->ExeUpdate(DB_TUTORIAIS_HOST, $PostData, "WHERE host_id = :name","name={$h}");
		 $jSON['redirect'] = "dashboard.php?wc=mdptutorial/homeh";
		endif;
		
	break;
		 case 'host_delete':
		$delAv =  $PostData['del_id'];
		 $Read->FullRead("SELECT * FROM " . DB_TUTORIAIS_HOST . " WHERE host_id = :id", "id={$delAv}");
		 extract($Read->getResult()[0]);
		$Delete->ExeDelete(DB_TUTORIAIS_HOST, "WHERE host_id = :id","id={$delAv}");
		$jSON['success'] = true;
		
		 break;
//////////////////////////
////////* CLASS */////////
//////////////////////////
	
case 'class_edite':
	$c = $PostData['class_id'];
	$Read->ExeRead(DB_TUTORIAIS_CLASS,"WHERE class_id = {$c}");
		if($Read->getResult()):
		  $jSON['trigger'] = AjaxErro("<b class='icon-info'>AVISO:</b><BR/>Meu querido, Todas as informações foram alteradas com<b> Sucesso</b>!");
		  $Update->ExeUpdate(DB_TUTORIAIS_CLASS, $PostData, "WHERE class_id = :name","name={$c}");
		 $jSON['redirect'] = "dashboard.php?wc=mdptutorial/homec";
		endif;
		
	break;
		 case 'class_delete':
		$delAv =  $PostData['del_id'];
		 $Read->FullRead("SELECT * FROM " . DB_TUTORIAIS_CLASS . " WHERE class_id = :id", "id={$delAv}");
		 extract($Read->getResult()[0]);
		$Delete->ExeDelete(DB_TUTORIAIS_CLASS, "WHERE class_id = :id","id={$delAv}");
		$jSON['success'] = true;
		
		 break;	
//////////////////////////
////////* TUTORIAL *//////
//////////////////////////
	
case 'tutorial_edite':
	$t = $PostData['tutorial_id'];
	$Read->ExeRead(DB_TUTORIAIS,"WHERE tutorial_id = {$t}");
		if($Read->getResult()):
		  $jSON['trigger'] = AjaxErro("<b class='icon-info'>AVISO:</b><BR/>Meu querido, Todas as informações foram alteradas com<b> Sucesso</b>!");
		  $Update->ExeUpdate(DB_TUTORIAIS, $PostData, "WHERE tutorial_id = :name","name={$t}");
		 $jSON['redirect'] = "dashboard.php?wc=mdptutorial/home";
		endif;
		
	break;
		 case 'tutorial_delete':
		$delAv =  $PostData['del_id'];
		 $Read->FullRead("SELECT * FROM " . DB_TUTORIAIS . " WHERE tutorial_id = :id", "id={$delAv}");
		 extract($Read->getResult()[0]);
		$Delete->ExeDelete(DB_TUTORIAIS, "WHERE tutorial_id = :id","id={$delAv}");
		$jSON['success'] = true;
		
		 break;			 
	
    endswitch;

    //RETORNA O CALLBACK
    if ($jSON):
        echo json_encode($jSON);
    else:
        $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPSS:</b> Desculpe. Mas uma ação do sistema não respondeu corretamente. Ao persistir, contate o desenvolvedor!', E_USER_ERROR);
        echo json_encode($jSON);
    endif;
else:
    //ACESSO DIRETO
    die('<br><br><br><center><h1>Acesso Restrito!</h1></center>');
endif;