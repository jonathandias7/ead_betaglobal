<?php

session_start();
require '../../_app/Config.inc.php';
$NivelAcess = 6;
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
if (empty($_SESSION['userLogin']) || empty($_SESSION['userLogin']['user_level']) || $_SESSION['userLogin']['user_level'] < $NivelAcess):
    $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPPSSS:</b> Você não tem permissão para essa ação ou não está logado como administrador!', E_USER_ERROR);
    echo json_encode($jSON);
    die;
endif;

usleep(50000);

//DEFINE O CALLBACK E RECUPERA O POST
$jSON = null;
$CallBack = 'AvFullead';
$PostData = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//VALIDA AÇÃO
if ($PostData && $PostData['callback_action'] && $PostData['callback'] == $CallBack):
    //PREPARA OS DADOS
    $Case = $PostData['callback_action'];
    unset($PostData['callback'], $PostData['callback_action']);
	/*****************************/
	/**** AÇÕES INSTANCIADAS *****/
	/*****************************/
    $Read = new Read;
    $Create = new Create;
    $Update = new Update;
    $Delete = new Delete;

 
	
	////////////////////////////////////////////////////////////////////////
	//////////////////////////* CREATE DA AVALIACAO *///////////////////////
	////////////////////////////////////////////////////////////////////////
    
 /*****************************/
 /***** BATERIA DA APP AV *****/
 /*****************************/
	switch ($Case):
	
	case 'avaliacao_create':
	$getTitle = $PostData['avaliacao_title'];
	//Converte o tempo em segundos
	$getTime = $PostData['avaliacao_time'];
	$timeTotal = $getTime * 60 ;
	
	/////////////////////////////////
	
	$Read->FullRead("SELECT avaliacao_title FROM " . DB_EAD_AVALIACAO . " WHERE avaliacao_title = :title", "title={$PostData['avaliacao_title']}");
	 
	 switch($Read->getResult()):
	 case(!empty($getTitle)):

	 
	  $jSON['trigger'] = AjaxErro("<b class='icon-warning'>AVISO:</b>Meu querido, Já existe uma avaliação com esse mesmo nome {$PostData['avaliacao_title']}", E_USER_NOTICE);
		$jSON['redirect'] = "dashboard.php?wc=fullead/home&id=". $PostData['course_id'] ."&module=".$PostData['module_id'];
		
	break;
	default:

		//substitui os campos recebidos do formulario pelos campos tratados com as conversões criadas acima
	
		$PostData['avaliacao_time'] = $timeTotal;
		$Create->ExeCreate(DB_EAD_AVALIACAO, $PostData);
		$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b>Meu querido, sua avaliação foi criada com sucesso!<br/><b class='icon-clock'>Você está sendo redirecionado para pagina de avaliações:</b> Aguarde aguarde só mais um instante.");
		$jSON['redirect'] = "dashboard.php?wc=fullead/home&id={$PostData['course_id']}&module={$PostData['module_id']}";
	break;
	endswitch;
	
	 break;
	 	case 'avaliacao_manage':
            $getProvaId = $PostData['avaliacao_id'];
            unset($PostData['avaliacao_id']);

            $PostData['avaliacao_name'] = $getProvaId . "-" . Check::Name($PostData['avaliacao_title']);
            $Update->ExeUpdate(DB_EAD_AVALIACAO, $PostData, "WHERE avaliacao_id = :id", "id={$getProvaId}");
            $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> A prova <b>{$PostData['avaliacao_title']}</b> foi atualizada com sucesso!");
            break;

	
	
	///////FIM CREATE AVALIAÇÃO/////////

	//DELETANDO
		 case 'av_delete':
		$delAv =  $PostData['del_id'];
		 $Read->FullRead("SELECT * FROM " . DB_EAD_AVALIACAO . " WHERE avaliacao_id = :id", "id={$delAv}");
		 extract($Read->getResult()[0]);
		$Delete->ExeDelete(DB_EAD_AVALIACAO, "WHERE avaliacao_id = :id","id={$delAv}");
		//$jSON['redirect'] = "dashboard.php?wc=fullead/home&id=". $course_id ."&module=".$module_id ;
		$jSON['success'] = true;
		
		 break;
	
		 	 
		////////////////////////////////////////////////////////////////////////
		///////////////////////* PERGUNTAS DA AVALIACAO *///////////////////////
		////////////////////////////////////////////////////////////////////////
		
			///////CREATE/////////
		 
		  case 'pergunta_create':
		   //Armazena o modulo recebido do formulario dentro da variavel
		   $ModId = $PostData['module_id'];
			//LEITURA DA TABELA AVALIAÇÕES(Retorna o ID CASO O MODULO SEJA O MESMO DA AVALIAÇÃO)
				$Read->FullRead("SELECT avaliacao_id FROM ". DB_EAD_AVALIACAO . " WHERE module_id = :module "," module={$ModId} ");
						extract($Read->getResult()[0]);//Extrai o campo(avaliacao_id)
						$avaliacao = $avaliacao_id;	
						$Perg = $PostData['perg_title'];//Armazena o valor recebido do formulario na variavel
				//usa a classe check passando o name como parametro.(Ex: Title: teste de pergunta / resultado: teste-de-pergunta)
						$PergName = Check::Name($PostData['perg_title']);
							$Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS, " WHERE avaliacao_id = :prov  AND perg_name = :perg", " prov={$avaliacao}&perg={$PergName} ");
							
							
							//Valida se existe um resultado. Caso exista ela extrai o indice 0
								if($Read->getRowCount()):
								$jSON['trigger'] = AjaxErro("<b class='icon-warning'>AVISO:</b> Meu querido,  <b></b> Já existe essa pergunta:<br/><b> {$PostData['perg_title']}?</b><br/> para essa Avaliação!!",E_USER_NOTICE);
								$jSON['success'] = true;
								$jSON['redirect'] = "dashboard.php?wc=fullead/av_perguntas&module=". $ModId ."&prov=".$avaliacao ;
								
								else: //Caso não exista essa mesma pergunta na tabela de perguntas(Pertencente a essa avaliação) Realiza o cadastro
							
								//CREATE(Inserindo dados na tabela)
										$Perg = $PostData['perg_title'];//Armazena o valor recebido do formulario na variavel
										
								//usa a classe check passando o name como parametro.(Ex: Title: teste de pergunta / resultado: teste-de-pergunta)
										$PergName = Check::Name($PostData['perg_title']);
								//Armazeno na variavel apenas os Arrays que quero inserir na tabela(passo os parametros do array separadamente)
										$CreatPerg = ['avaliacao_id' => $avaliacao, 'perg_title' => $Perg , 'perg_name' => $PergName ];
								//Armazena na tabela os Arrays que foram armazenados na variavel($CreatPerg)		
									
								
							
										$Create->ExeCreate(DB_EAD_AVALIACAO_PERGUNTAS,$CreatPerg);
								
								$Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS, " WHERE avaliacao_id = :prov  AND perg_name = :perg", " prov={$avaliacao}&perg={$PergName} ");		
						  extract($Read->getResult()[0]);
						 
							
								//Retorna o Trigger avisando que foi concluido com sucesso e após success	
										$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> A Perg  <b></b> foi Criada com sucesso!");
										$jSON['content'] = "";
		       /*  $jSON['content'] .= "<article class='box box100 mdp_avaliacao' id='{$perg_id}'>
                            <div class='box_content'>
                                <h1 class='row_title'>
								
                                   {$PostData['perg_title']}
								   
								   
                                <p class='actions fl_right'>";
                                    
									
                                    //verifica o número de opções da questão
                                    $Read->FullRead("SELECT op_id FROM ". DB_EAD_AVALIACAO_RESPOSTAS . " WHERE perg_id = :perg", "perg={$perg_id}");
                                    $TotOp = $Read->getRowCount();
                                    
                                    $jSON['content'] .="<a title='Adicionar opções' href='dashboard.php?wc=fullead/av_resposta&perg={$avaliacao}' class='btn btn_green icon-plus icon-notext'></a>
                                    <a href='dashboard.php?wc=fullead/av_perguntas&module={$ModId}&prov={$avaliacao}&perg={$perg_id}' title='Editar Questão' class='btn btn_blue icon-pencil2 icon-notext'></a>
                                    <span rel='mdp_avaliacao' class='j_delete_action icon-cancel-circle icon-notext btn btn_red' id='{$perg_id}'></span>
                                    <span rel='mdp_avaliacao' callback='AvFullead' callback_action='pergunta_delete' class='j_delete_action_confirm icon-warning icon-notext btn btn_yellow' style='display: none' id='{$perg_id}'></span>
									<h2 style='color:orange;'>Total:";
									$Read->FullRead("SELECT op_id FROM " . DB_EAD_AVALIACAO_RESPOSTAS . " WHERE perg_id = :perg", "perg={$perg_id}");
									$TotOp = $Read->getRowCount();
                                    $jSON['content'] .="<a style='margin-left:10px;'class='btn btn_yellow '>{$TotOp}</a>
								</p></h1>
                            </div>
							<hr/>
                        </article>"; */
										$jSON['redirect'] = "dashboard.php?wc=fullead/av_perguntas&module=". $ModId ."&prov=".$avaliacao ;
										$jSON['success'] = true;
								endif;	
					
			
            break;
			
			//////UPDATE//////////
			
         case'pergunta_update':
		 $Perg = $PostData['perg_title'];//Armazena o valor recebido do formulario na variavel
		 $PergId = $PostData['perg_id'];	
		   $ModId = $PostData['module_id'];	
		$AvId = $PostData['avaliacao_id'];			 
		//usa a classe check passando o name como parametro.(Ex: Title: teste de pergunta / resultado: teste-de-pergunta)
				$PergName = Check::Name($PostData['perg_title']);
		//Armazeno na variavel apenas os Arrays que quero inserir na tabela(passo os parametros do array separadamente)
				$UpPerg = ['perg_title' => $Perg , 'perg_name' => $PergName ];
		//Armazena na tabela os Arrays que foram armazenados na variavel($CreatPerg)		
				
			$Update->ExeUpdate(DB_EAD_AVALIACAO_PERGUNTAS,$UpPerg, "WHERE avaliacao_id = :prov AND perg_id = :perg","prov={$AvId}&perg={$PergId}");		
			$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> A Perg  <b>{$Perg}</b> foi Atualizada com sucesso!");							
			$jSON['success'] = true;		
			$jSON['redirect'] = "dashboard.php?wc=fullead/av_perguntas&module=". $ModId ."&prov=".$AvId."&perg=".$PergId;
				
		 
		 break;
			///////DELETE/////////
			case 'pergunta_delete':
				
				 $delAv =  $PostData['del_id'];
				//pega a questão pelo Id
				 $Read->FullRead("SELECT perg_id FROM " . DB_EAD_AVALIACAO_PERGUNTAS);
				 $Delete->ExeDelete(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE perg_id = :perg","perg={$delAv}");		 
				 $jSON['success'] = true;
			break;
			
			///////FIM DAS PERGUNTAS/////////
			
			////////////////////////////////////////////////////////////////////////
		///////////////////////* OPÇÕES DE RESPOSTAS DA AVALIACAO *///////////////////////
		////////////////////////////////////////////////////////////////////////
		
			
           
			case 'op_create':
			$perg = $PostData['perg_id'];
			$AvId = $PostData['avaliacao_id'];
			$op = $PostData['op_content'];
			if(isset($PostData['op_sit'])):
				$opcreate =[
				'perg_id' => $perg,
				'op_content' => $op,
				'op_sit' => 1
				];
			
			else:
			$opcreate =[
			'perg_id' => $perg,
			'op_content' => $op
		
			];
			endif;
			$Read->ExeRead(DB_EAD_AVALIACAO_RESPOSTAS, " WHERE perg_id = :perg  AND op_content = :op", " perg={$perg}&op={$op} ");
							
			//CONDIÇÃO
				if($Read->getRowCount()):
				$jSON['trigger'] = AjaxErro("<b class='icon-warning'>AVISO:</b> Meu querido, Já existe essa Opção de resposta: <b> {$op}</b><br/>para essa pergunta!!<br/>!!",E_USER_NOTICE);
				$jSON['redirect'] = "dashboard.php?wc=fullead/av_resposta&perg=". $perg ."&prov=".$AvId ;
				
				$jSON['success'] = true;
				
				else:
				
			///////CREATE/////////
			
			
				$Create->ExeCreate(DB_EAD_AVALIACAO_RESPOSTAS,$opcreate);
				$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> A Opção: <b>{$op}</b> foi Criada com sucesso!");
				$jSON['success'] = true;		
				$jSON['redirect'] = "dashboard.php?wc=fullead/av_resposta&perg=". $perg ."&prov=".$AvId ;
														
				endif;
            break;
		
		
		
		
		///////DELETE/////////
		case 'op_delete':
				
				 $delOp =  $PostData['del_id'];
				 $Delete->ExeDelete(DB_EAD_AVALIACAO_RESPOSTAS, "WHERE op_id = :op","op={$delOp}");		 
				 $jSON['success'] = true;
			break;
		 ///////FIM DAS OPÇÕES DE RESPOSTA/////////
		 
		 
		 
		 
		 
		 
		 
		 ////////////////////////////////////////////////////////////////////////
	//////////////////////////* CREATE DE EXERCICIOS *///////////////////////
	////////////////////////////////////////////////////////////////////////
    
 /*****************************/
 /***** BATERIA DA APP AV *****/
 /*****************************/
	
	
	case 'exe_create':
	
	
	$getTitle = $PostData['exe_title'];
	//Converte o tempo em segundos
	//$getTime = $PostData['exe_time'];
	//$timeTotal = $getTime * 60 ;
	
	/////////////////////////////////
	
	$Read->FullRead("SELECT exe_title FROM " . DB_EAD_EXE . " WHERE exe_title = :title", "title={$PostData['exe_title']}");
	 
	 switch($Read->getResult()):
	 case(!empty($getTitle)):

	 
	  $jSON['trigger'] = AjaxErro("<b class='icon-warning'>AVISO:</b>Meu querido, Já existe uma avaliação com esse mesmo nome {$PostData['exe_title']}", E_USER_NOTICE);
		$jSON['redirect'] = "dashboard.php?wc=fullead/homeexe&id=". $PostData['course_id'] ."&module=".$PostData['module_id']."&class=".$PostData['class_id'];
		
	break;
	default:

		//substitui os campos recebidos do formulario pelos campos tratados com as conversões criadas acima
	
		//$PostData['exe_time'] = $timeTotal;
		$Create->ExeCreate(DB_EAD_EXE, $PostData);
		
		$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b>Meu querido, seu exercicio foi criado com sucesso!<br/><b class='icon-clock'>Você está sendo redirecionado para pagina de avaliações:</b> Aguarde aguarde só mais um instante.");
		$jSON['redirect'] = "dashboard.php?wc=fullead/homeexe&id=". $PostData['course_id'] ."&module=".$PostData['module_id']."&class=".$PostData['class_id'];
		
	break;
	endswitch;
	
	 break;
	 case 'exe_update':
            $getProvaId = $PostData['exe_id'];
            unset($PostData['exe_id']);

            $PostData['exe_name'] = $getProvaId . "-" . Check::Name($PostData['exe_title']);
            $Update->ExeUpdate(DB_EAD_EXE, $PostData, "WHERE exe_id = :id", "id={$getProvaId}");
		   $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> A prova <b>{$PostData['exe_title']}</b> foi atualizada com sucesso!");
            $jSON['redirect'] = "dashboard.php?wc=fullead/homeexe&id=". $PostData['course_id'] ."&module=".$PostData['module_id'];
		
			break;

	 
	 
	 	
			////////////////////////////////////////////////////////////////////////
		///////////////////////* PERGUNTAS DO EXERCICIO *///////////////////////
		////////////////////////////////////////////////////////////////////////
		
	 //perguntas exercicios
	 case 'exe_pergunta_create':
	 
		   //Armazena o modulo recebido do formulario dentro da variavel
		   $ModId = $PostData['module_id'];
		   $AvId = $PostData['avaliacao_id'];
		   $ClassId = $PostData['class_id'];
			//LEITURA DA TABELA AVALIAÇÕES(Retorna o ID CASO O MODULO SEJA O MESMO DA AVALIAÇÃO)
				$Read->FullRead("SELECT exe_id FROM ". DB_EAD_EXE . " WHERE module_id = :module AND class_id = :class"," module={$ModId}&class={$ClassId} ");
						extract($Read->getResult()[0]);//Extrai o campo(avaliacao_id)
						$avaliacao = $exe_id;	
						$Perg = $PostData['perg_title'];//Armazena o valor recebido do formulario na variavel
				//usa a classe check passando o name como parametro.(Ex: Title: teste de pergunta / resultado: teste-de-pergunta)
						$PergName = Check::Name($PostData['perg_title']);
							$Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS, " WHERE avaliacao_id = :class  AND perg_name = :perg", " class={$AvId}&perg={$PergName} ");
							
							//Valida se existe um resultado. Caso exista ela extrai o indice 0
								if($Read->getRowCount()):
								$jSON['trigger'] = AjaxErro("<b class='icon-warning'>AVISO:</b> Meu querido,  <b></b> Já existe essa pergunta:<br/><b> {$PostData['perg_title']}?</b><br/> para essa Avaliação!!",E_USER_NOTICE);
								$jSON['success'] = true;
								//$jSON['redirect'] = "dashboard.php?wc=fullead/exe_perguntas&module=". $ModId ."&prov=".$avaliacao."&class=".$ClassId  ;
										
								else: //Caso não exista essa mesma pergunta na tabela de perguntas(Pertencente a essa avaliação) Realiza o cadastro
							
								//CREATE(Inserindo dados na tabela)
										$Perg = $PostData['perg_title'];//Armazena o valor recebido do formulario na variavel
										
								//usa a classe check passando o name como parametro.(Ex: Title: teste de pergunta / resultado: teste-de-pergunta)
										$PergName = Check::Name($PostData['perg_title']);
								//Armazeno na variavel apenas os Arrays que quero inserir na tabela(passo os parametros do array separadamente)
										$CreatPerg = ['avaliacao_id' => $AvId, 'perg_title' => $Perg , 'perg_name' => $PergName ];
								//Armazena na tabela os Arrays que foram armazenados na variavel($CreatPerg)		
									
										$Create->ExeCreate(DB_EAD_AVALIACAO_PERGUNTAS,$CreatPerg);
								//Retorna o Trigger avisando que foi concluido com sucesso e após success	
										$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> A Perg  <b></b> foi Criada com sucesso!");
										$jSON['redirect'] = "dashboard.php?wc=fullead/exe_perguntas&module=". $ModId ."&prov=".$AvId."&class=".$ClassId  ;
										$jSON['success'] = true;
								endif;	
					
			
            break;
			
			
			//////UPDATE//////////
			
         case'exe_pergunta_update':
		 $Perg = $PostData['perg_title'];//Armazena o valor recebido do formulario na variavel
		 $PergId = $PostData['perg_id'];	
		  $ClassId = $PostData['class_id'];	
		   $ModId = $PostData['module_id'];	
		$AvId = $PostData['avaliacao_id'];			 
		//usa a classe check passando o name como parametro.(Ex: Title: teste de pergunta / resultado: teste-de-pergunta)
				$PergName = Check::Name($PostData['perg_title']);
		//Armazeno na variavel apenas os Arrays que quero inserir na tabela(passo os parametros do array separadamente)
				$UpPerg = ['perg_title' => $Perg , 'perg_name' => $PergName ];
		//Armazena na tabela os Arrays que foram armazenados na variavel($CreatPerg)		
				
			$Update->ExeUpdate(DB_EAD_AVALIACAO_PERGUNTAS,$UpPerg, "WHERE avaliacao_id = :prov AND perg_id = :perg","prov={$AvId}&perg={$PergId}");		
			$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> A Perg  <b>{$Perg}</b> foi Atualizada com sucesso!");							
			$jSON['success'] = true;		
			$jSON['redirect'] = "dashboard.php?wc=fullead/exe_perguntas&module=". $ModId ."&prov=".$AvId."&class=".$ClassId;
				
		 
		 break;
		 
		 
		 
		 	
			////////////////////////////////////////////////////////////////////////
		///////////////////////* PERGUNTAS DE TEXTO DO EXERCICIO*///////////////////////
		////////////////////////////////////////////////////////////////////////
		 case 'exe_perg_txt':
		$PostData['perg_material'] = null;
		 $Create->ExeCreate(DB_EAD_AVALIACAO_PERGUNTAS, $PostData);
		$PergUpdate['perg_name'] = $Create->getResult() . "-" . Check::Name($PostData['perg_title']);

		//MATERIAL
            if (!empty($_FILES['perg_material'])):
                $File = $_FILES['perg_material'];
                $Upload = new Upload('../../../uploads/');
                $Upload->File($File, $PergUpdate['perg_name'], "courses/perguntas");
                if (!$Upload->getError()):
                    $PergUpdate['perg_material'] = $Upload->getResult();
					$jSON['trigger'] = AjaxErro("<b class='icon-warning'>SUCESSO:</b> O material foi cadastrado com sucesso!");
           
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-warning'>OPPSSS:</b> O arquivo enviado não é compatível, para cadastrar a aula <b>envie um arquivo .zip</b> ou não envie!", E_USER_WARNING);
                    $Delete->ExeDelete(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE perg_id = :id", "id={$Create->getResult()}");
                    break;
                endif;
            endif;
			 $Update->ExeUpdate(DB_EAD_AVALIACAO_PERGUNTAS, $PergUpdate, "WHERE perg_id = :id", "id={$Create->getResult()}");


            
			        
			break;
			
		//FIM DAS PERGUNTAS DE TEXTO//
			
			///////DELETE/////////
			case 'exe_pergunta_delete':
				
				 $delAv =  $PostData['del_id'];
				//pega a questão pelo Id
				 $Read->FullRead("SELECT perg_id FROM " . DB_EAD_AVALIACAO_PERGUNTAS);
				 $Delete->ExeDelete(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE perg_id = :perg","perg={$delAv}");		 
				 $jSON['success'] = true;
			break;
			
			///////FIM DAS PERGUNTAS/////////
			
			
			
			
			
			
			////////////////////////////////////////////////////////////////////////
		///////////////////////* OPÇÕES DE RESPOSTAS DO EXERCICIO *///////////////////////
		////////////////////////////////////////////////////////////////////////
		
			
           
			case 'exe_op_create':
			$perg = $PostData['perg_id'];
			$AvId = $PostData['exe_id'];
			$ClassId = $PostData['class_id'];
			$op = $PostData['op_content'];
			if(isset($PostData['op_sit'])):
				$opcreate =[
				'perg_id' => $perg,
				'op_content' => $op,
				'op_sit' => 1
				];
			
			else:
			$opcreate =[
			'perg_id' => $perg,
			'op_content' => $op
		
			];
			endif;
			$Read->ExeRead(DB_EAD_AVALIACAO_RESPOSTAS, " WHERE perg_id = :perg  AND op_content = :op", " perg={$perg}&op={$op} ");
							
			//CONDIÇÃO
				if($Read->getRowCount()):
				$jSON['trigger'] = AjaxErro("<b class='icon-warning'>AVISO:</b> Meu querido, Já existe essa Opção de resposta: <b> {$op}</b><br/>para essa pergunta!!<br/>!!",E_USER_NOTICE);
				$jSON['redirect'] = "dashboard.php?wc=fullead/exe_resposta&perg=". $perg ."&prov=".$AvId."&class=".$ClassId  ;
				
				$jSON['success'] = true;
				
				else:
				
			///////CREATE/////////
			
			
				$Create->ExeCreate(DB_EAD_AVALIACAO_RESPOSTAS,$opcreate);
				$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> A Opção: <b>{$op}</b> foi Criada com sucesso!");
				$jSON['success'] = true;		
				$jSON['redirect'] = "dashboard.php?wc=fullead/exe_resposta&perg=". $perg ."&prov=".$AvId."&class=".$ClassId  ;
														
				endif;
            break;
		
		
		
		///////DELETE/////////
		case 'exe_op_delete':
				
				 $delOp =  $PostData['del_id'];
				 $Delete->ExeDelete(DB_EAD_AVALIACAO_RESPOSTAS, "WHERE op_id = :op","op={$delOp}");		 
				 $jSON['success'] = true;
			break;
		 ///////FIM DAS OPÇÕES DE RESPOSTA/////////
		 
		 
		 
	 
	
    endswitch;

    //RETORNA O CALLBACK
    if ($jSON):
        echo json_encode($jSON);
    else:
        $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPSS:</b> Desculpe. Mas uma ação do sistema não respondeu corretamente. Ao persistir, contate o desenvolvedor!', E_USER_ERROR);
        echo json_encode($jSON);
    endif;
else:
    //ACESSO DIRETO
    die('<br><br><br><center><h1>Acesso Restrito!</h1></center>');
endif;