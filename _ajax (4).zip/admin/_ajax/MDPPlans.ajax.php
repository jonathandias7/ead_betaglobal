<?php

session_start();
require '../../_app/Config.inc.php';
$NivelAcess = 6;
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
if (empty($_SESSION['userLogin']) || empty($_SESSION['userLogin']['user_level']) || $_SESSION['userLogin']['user_level'] < $NivelAcess):
    $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPPSSS:</b> Você não tem permissão para essa ação ou não está logado como administrador!', E_USER_ERROR);
    echo json_encode($jSON);
    die;
endif;

usleep(50000);

//DEFINE O CALLBACK E RECUPERA O POST
$jSON = null;
$CallBack = 'MDPPlans';
$PostData = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//VALIDA AÇÃO
if ($PostData && $PostData['callback_action'] && $PostData['callback'] == $CallBack):
    //PREPARA OS DADOS
    $Case = $PostData['callback_action'];
    unset($PostData['callback'], $PostData['callback_action']);
	/*****************************/
	/**** AÇÕES INSTANCIADAS *****/
	/*****************************/
    $Read = new Read;
    $Create = new Create;
    $Update = new Update;
    $Delete = new Delete;

 
	
	////////////////////////////////////////////////////////////////////////
	//////////////////////////* PLANOS *///////////////////////
	////////////////////////////////////////////////////////////////////////
    
 
 
 
 
 /*****************************/
 /*** BATERIA DA APP PLANOS ***/
 /*****************************/
	switch ($Case):
	
	//////////// UPDATE/////////////////////

	case 'plans_create':
		$Update->ExeUpdate("mdp_plans", $PostData, "WHERE mdp_plans_id = :id", "id={$PostData['mdp_plans_id']}");
		$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> O plano <b>{$PostData['mdp_plans_title']}</b> foi atualizada com sucesso!");
		
	break;
	//////////// DELETE /////////////////////
		 case 'plans_delete':
		$delAv =  $PostData['del_id'];
		 $Read->FullRead("SELECT * FROM mdp_plans WHERE mdp_plans_id = :id", "id={$delAv}");
		 extract($Read->getResult()[0]);
		$Delete->ExeDelete("mdp_plans", "WHERE mdp_plans_id = :id","id={$delAv}");
		$jSON['success'] = true;
		
		break;
	
		 	 
		////////////////////////////////////////////////////////////////////////
		///////////////////////* ATRIBUTOS DOS PLANOS *///////////////////////
		////////////////////////////////////////////////////////////////////////
		
		
           //////////// UPDATE/////////////////////

	case 'attr_create':
		$Update->ExeUpdate("mdp_plans_attr", $PostData, "WHERE mdp_plans_attr_id = :id", "id={$PostData['mdp_plans_attr_id']}");
		$ico = ['mdp_plans_ico' => $PostData['mdp_plans_attr_min']];
		$Update->ExeUpdate("mdp_plans_attr", $ico, "WHERE mdp_plans_attr_id = :id", "id={$PostData['mdp_plans_attr_id']}");
		$jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>SUCESSO:</b> O Atributo <b>{$PostData['mdp_plans_attr_title']}</b> foi atualizada com sucesso!");
		
	break; 
	//////////// DELETE /////////////////////
		 case 'attr_delete':
		$delAv =  $PostData['del_id'];
		 $Read->FullRead("SELECT * FROM mdp_plans_attr WHERE mdp_plans_attr_id = :id", "id={$delAv}");
		 extract($Read->getResult()[0]);
		$Delete->ExeDelete("mdp_plans_attr", "WHERE mdp_plans_attr_id = :id","id={$delAv}");
		$jSON['success'] = true;
		
		break;
	//////////// FIM DA BATERIA PLANS /////////////////////
		
	
    endswitch;

    //RETORNA O CALLBACK
    if ($jSON):
        echo json_encode($jSON);
    else:
        $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPSS:</b> Desculpe. Mas uma ação do sistema não respondeu corretamente. Ao persistir, contate o desenvolvedor!', E_USER_ERROR);
        echo json_encode($jSON);
    endif;
else:
    //ACESSO DIRETO
    die('<br><br><br><center><h1>Acesso Restrito!</h1></center>');
endif;