<?php

session_start();
require '../../_app/Config.inc.php';
$NivelAcess = LEVEL_WC_PAGES;

if (empty($_SESSION['userLogin']) || empty($_SESSION['userLogin']['user_level']) || $_SESSION['userLogin']['user_level'] < $NivelAcess):
    $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPPSSS:</b> Você não tem permissão para essa ação ou não está logado como administrador!', E_USER_ERROR);
    echo json_encode($jSON);
    die;
endif;

usleep(50000);

//DEFINE O CALLBACK E RECUPERA O POST
$jSON = null;
$CallBack = 'MDPSetup';
$PostData = filter_input_array(INPUT_POST, FILTER_DEFAULT);

//VALIDA AÇÃO
if ($PostData && $PostData['callback_action'] && $PostData['callback'] == $CallBack):
    //PREPARA OS DADOS
    $Case = $PostData['callback_action'];
    unset($PostData['callback'], $PostData['callback_action']);

    // AUTO INSTANCE OBJECT READ
    if (empty($Read)):
        $Read = new Read;
    endif;

    // AUTO INSTANCE OBJECT CREATE
    if (empty($Create)):
        $Create = new Create;
    endif;

    // AUTO INSTANCE OBJECT UPDATE
    if (empty($Update)):
        $Update = new Update;
    endif;
    
    // AUTO INSTANCE OBJECT DELETE
    if (empty($Delete)):
        $Delete = new Delete;
    endif;

    //SELECIONA AÇÃO
    switch ($Case):
       
        //MANAGER
        case 'manage':
            $SetupId = $PostData['setup_img_id'];
            unset($PostData['setup_img_id']);

            $PostData['setup_img_status'] = (!empty($PostData['setup_img_status']) ? '1' : '0');
         
            $PostData['setup_img_name'] = (!empty($PostData['setup_img_name']) ? Check::Name($PostData['setup_img_name']) : Check::Name($PostData['setup_img_title']));
            
            $Read->ExeRead("mdp_setup_img", "WHERE setup_img_id = :id", "id={$SetupId}");
            $ThisSetup = $Read->getResult()[0];
            
            if (!empty($_FILES['setup_img_cover'])):
                $File = $_FILES['setup_img_cover'];

                if ($ThisSetup['setup_img_cover'] && file_exists("../../uploads/{$ThisSetup['setup_img_cover']}") && !is_dir("../../uploads/{$ThisSetup['setup_img_cover']}")):
                    unlink("../../uploads/{$ThisSetup['setup_img_cover']}");
                endif;

                $Upload = new Upload('../../uploads/');
                $Upload->Image($File, $PostData['setup_img_name'] . '-' . time(), IMAGE_W, 'pages');
                if ($Upload->getResult()):
                    $PostData['setup_img_cover'] = $Upload->getResult();
                else:
                    $jSON['trigger'] = AjaxErro("<b class='icon-image'>ERRO AO ENVIAR CAPA:</b> Olá {$_SESSION['userLogin']['user_name']}, selecione uma imagem JPG ou PNG para enviar como capa!", E_USER_WARNING);
                    echo json_encode($jSON);
                    return;
                endif;
            else:
                unset($PostData['setup_img_cover']);
            endif;

            
   
            $Update->ExeUpdate("mdp_setup_img", $PostData, "WHERE setup_img_id = :id", "id={$SetupId}");
            $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>Página atualizada com sucesso!</b>");
            break;
			
			
			 case 'setup_create':
            $SetupId = $PostData['setup_id'];
            unset($PostData['setup_id']);

     
            $Update->ExeUpdate("mdp_setup", $PostData, "WHERE setup_id = :id", "id={$SetupId}");
            $jSON['trigger'] = AjaxErro("<b class='icon-checkmark'>Página atualizada com sucesso!</b>");
            break;
        //PAGE IMAGE
       
     
    endswitch;

    //RETORNA O CALLBACK
    if ($jSON):
        echo json_encode($jSON);
    else:
        $jSON['trigger'] = AjaxErro('<b class="icon-warning">OPSS:</b> Desculpe. Mas uma ação do sistema não respondeu corretamente. Ao persistir, contate o desenvolvedor!', E_USER_ERROR);
        echo json_encode($jSON);
    endif;
else:
    //ACESSO DIRETO
    die('<br><br><br><center><h1>Acesso Restrito!</h1></center>');
endif;
