<?php
/*****************************
SUPORTE MDP SOFTWARES LTDA
PROJETO: MDP TUTORIAL
SOBRE: Sistema de Tutoriais dinamico.
Pietro Napoleão | atendimento@mdpempresarial.com.br
WhatsApp - Grupo/Suporte: (32) 9 9992-0439
Copyright (c) 2019 - 2020 MDP SOFTWARES LTDA

******************************
IMPORTANTE: É expressamente proibido compartilhar estes arquivos por
qualquer meio ou com terceiros. Seu uso é exclusivo e intransferível
para o profissional.Podendo ser comercializado apenas a clientes sobre seus serviços.

A violação dos direitos exclusivos do produtor MDP SOFTWARES LTDA sobre a obra
é crime, ART. 184 DO CÓDIGO PENAL.
******************************/
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif; 



?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-profile">APP'S ON</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            Gerenciar APP'S
        </p>
    </div>
			<div style="width:50%" class="dashboard_header_search">
        <a title="Novo O" href="dashboard.php?wc=mdpsecurity/create" class="btn btn_green icon-plus">Cadastrar tutorial</a>
	</div>
</header>

<div class="dashboard_content">
    <section class="box box100">
        <article class="box box100 course_list">
            <header class="header_green">
                <h1 class="icon-file-text2">Lista de APP'S:</h1>
                <div class="clear"></div>
		
            </header>
            <div class="box_content">
                <?php
                $Read->ExeRead("mdp_app_on","WHERE app_id > 0 ");

                if (!$Read->getResult()):
                    echo "<div class='trigger al_center trigger_info trigger_none font_medium'>Ainda não existem Contas cadastradas!</div>";
                else:
                    foreach ($Read->getResult() as $cc):
                        extract($cc);
                         $Read->ExeRead("mdp_app","WHERE app_id = :id","id={$app_id}");
						if ($Read->getResult()):
                        extract($Read->getResult()[0]);
						endif;
						 $Read->ExeRead(DB_USERS,"WHERE user_id = :id","id={$app_user}");
						if ($Read->getResult()):
                        extract($Read->getResult()[0]);
						endif;
						 
                        
                    //  if($result != '3' || $result != 0)://valida o filtro
					  
					 // if($exe_title != null):
					 ?>
					 <div class="callback_return"></div>
                            <article class="course_gerent_module course_list" id="<?= $appon_id; ?>">
                            <h1 style='max-width:280px;' class="row_title">
                              <?= " <b style='padding:5px 15px;width:30px;height:30px;background:{$app_color};'></b><span style='width:100%!important;color:#000; padding:5px 5px;  text-align:center; font-size:1em; width:300px;'>". $app_url ; ?></span>
                            </h1><p style='width:500px;' class=" row ">
							<?
							$tipo = ($appon_status == 1 ? 'ATIVO' : 'DESATIVADO');
							$typeColor = ($appon_status == 1 ? 'bg_green' : 'bg_red');
							?>
                              <?= "<span style='background:{$app_color};color:#fff; text-align:center; font-size:1em; width:150px;'><b> ".$user_name."</b></span>"; ?><span class="<?= $typeColor?>" style="color:#fff; text-align:center; font-size:1em; width:150px;"><b><?= $tipo;?></b></span>
                            <?=" <span style='float:left;padding:5px 5px; background:{$app_color}; color:#fff; text-align:center; font-size:1em; width:159px;'><b> ". $app_ip ."</b></span>";?>
						   
						   </p><p class="row fl_right">
								
								 
							 <a title="Editar esse banco" href="dashboard.php?wc=mdpsecurity/create&appon=<?= $appon_id; ?>" class="fl_right btn btn_yellow icon-list icon-notext"></a>
								 <a title="Editar esse banco" href="dashboard.php?wc=mdpsecurity/create&appon=<?= $appon_id; ?>" class="fl_right btn btn_blue icon-pencil2 icon-notext"></a>
								<a rel="course_list" class="j_delete_action icon-cancel-circle btn btn_red fl_right icon-notext" id="<?= $appon_id; ?>"></a>
								<a rel="course_list" callback='MDPSecurity' callback_action="appon_delete" class="j_delete_action_confirm icon-warning btn btn_yellow" style="display: none ;margin-tcc: 30px;" id="<?= $appon_id; ?>">Deletar tutorial?</a>
                </p>
                        </article>
                        <?php
						// else:
						//echo $result;
						//endif; 
					//endif;
                    endforeach;
                endif;
                ?>
                <div class="clear"></div>
            </div>
        </article>
		
    </section>
</div>

