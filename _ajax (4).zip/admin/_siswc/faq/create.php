<?php
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;



// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;
if (empty($Create)):
    $Create = new Create;
endif;
$FaqId = filter_input(INPUT_GET, 'faq', FILTER_VALIDATE_INT);

if(empty($FaqId)):
$faq = ['faq_status'=> 0];
$Create->ExeCreate("mdp_faq",$faq);
Header("Location: dashboard.php?wc=faq/create&faq=". $Create->getResult());
exit;
endif;
$Read->ExeRead("mdp_faq","WHERE faq_id = $FaqId");
if($Read->getResult()):
extract($Read->getResult()[0]);
endif;

?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-pagebreak">Novo Faq</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
           Faq
        </p>
    </div>


</header>


<div class="dashboard_content">

    <div class="box box100">

        <div class="panel_header default">
            <h2 class="icon-tree">Faq </h2>
        </div>
 
        <div class="panel">
           <form class="" name="faq_create" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="MDPFaq"/>
                <input type="hidden" name="callback_action" value="faq_create"/>
				<input type="hidden" name="faq_id" value="<?= $FaqId ?>">
                
            
				<div class="label_33">
							<label class="label">
								<span class="legend">TITULO</span>
								<input style="font-size: 1.5em;" type="text" name="faq_title" value="<?= $faq_title?>" placeholder="Título do Faq:" required/>
							</label>
							
							<label class="label">
								<span class="legend">Status<span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Caso desativa, a prova será criada mas não exibida e nem necessária no campus</span></span></span>
								<select name="faq_status"  required="required">
								<option value="0" <?=($faq_status == 0 ? 'selected="selected"' : '')?> >Desativado</option>
								<option value="1" <?=($faq_status == 1 ? 'selected="selected"' : '')?>>Ativado</option>
							
								</select>
							</label>
							
                   <label class="label">
								<span class="legend">PAGINA</span>
								<select name="page_id" required="required">
									<?php
									 $Read->FullRead("SELECT page_id, page_title FROM ". DB_PAGES ." WHERE page_status = 1");
									if ($Read->getResult()):
									foreach ($Read->getResult() as $FAQ):
                                    echo "<option";
                                    if ($FAQ['page_id'] == $page_id):
                                        echo " selected='selected'";
                                    endif;
									echo " value='{$FAQ['page_id']}'>{$FAQ['page_title']}</option>";
                                endforeach;
                            endif;?>
									</select>
									
							</label>
                
                 
                </div>
				
                <div class="m_top">&nbsp;</div>
					
              

				
                <div class="m_top">&nbsp;</div>
                <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                <button class="btn btn_green icon-price-tags fl_right">Finalizar</button>
				
                <div class="clear"></div>
            </form>
        </div>
    </div>
</div>