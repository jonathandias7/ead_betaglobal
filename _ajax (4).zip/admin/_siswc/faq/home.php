<?php
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;
$Read = new Read;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-profile">FAQ</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            Gerenciar Faq
        </p>
    </div>
	  <div class="dashboard_header_search">
        <a title="Nova Duvida" href="dashboard.php?wc=faq/create" class="btn btn_green icon-plus">Cadastrar Novo Faq!</a>
    </div>

</header>

<div class="j_content dashboard_content">
    <section class="box box100">
        <article class="box box100 course_list">
            <header class="header_green">
                <h1 class="icon-file-text2">Meus Faq:</h1>
                <div class="clear"></div>
            </header>
            <div class="box_content">
                <?php
                $Read->FullRead("SELECT * FROM mdp_faq");

                if (!$Read->getResult()):
                    echo "<div class='trigger al_center trigger_info trigger_none font_medium'>Ainda não existem atributos cadastrados.</div>";
                else:
                    foreach ($Read->getResult() as $attr):
                      
                         $Read->FullRead("SELECT * FROM mdp_faq_resp WHERE faq_id = :id", "id={$attr['faq_id']}");
                        if($Read->getResult()):
                            extract($Read->getResult()[0]);
                        endif;
                       extract($attr);
                      
                        ?>
                    
					 <div class="callback_return"></div>
                            <article class="course_gerent_module course_list" id="<?= $faq_id; ?>">
                            <h1 class="row_title icon-profile">
                                <?= $faq_title; ?>
                            </h1><p class="row">
							<?
							$status = ($faq_status == 1 ? 'ON' : 'OFF');
							$statusColor = ($faq_status == 1 ? 'bg_green' : 'bg_red');
							$typeColor = (isset($faq_resp_id) ? 'bg_blue' : 'bg_yellow');
							$type = (isset($faq_resp_id)  ? 'Compelto' : 'Inompleto');
							?>
                                <span class="<?= $statusColor?>" style="color:#fff; text-align:center; font-size:1em; width:100px;"><b> <?= $status;?></b></span><span class="<?= $typeColor?>" style="color:#fff; text-align:center; font-size:1em; width:200px;"><b><?= $faq_title;?></b></span>
                            </p><p class="row">
							<a title="Adicionar Resposta" href="dashboard.php?wc=faq/creater<?= (empty($faq_resp_id) ? '&faq='. $faq_id :  '&faq='. $faq_id .'&faqr='.$faq_resp_id); ?>" class="btn <?= $typeColor?> icon-plus icon-notext"></a>
                                <a title="Editar essa Avaliação" href="dashboard.php?wc=faq/create&faq=<?= $faq_id; ?>" class="btn btn_blue icon-pencil2 icon-notext"></a>
								<a rel="course_list" class="j_delete_action icon-cancel-circle btn btn_red icon-notext" id="<?= $faq_id; ?>"></a>
								<a rel="course_list" callback='MDPFaq' callback_action="faq_delete" class="j_delete_action_confirm icon-warning btn btn_yellow" style="display: none ;margin-top: 30px;" id="<?= $faq_id; ?>">Deletar faq?</a>
                </p>
                        </article>
                        <?php
						/* else:
						echo $result;*/

                    endforeach;
                endif;
                ?>
                <div class="clear"></div>
            </div>
        </article>
		
    </section>
</div>

