<?php
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;
$Read = new Read;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-profile">SETUP</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
           
          
            <span class="crumb">/</span>
            Gerenciar Setup
        </p>
    </div>

</header>

<div class="j_content dashboard_content">
    <section class="box box100">
        <article class="box box100 course_list">
            <header class="header_green">
                <h1 class="icon-file-text2">Meus Setup:</h1>
                <div class="clear"></div>
            </header>
            <div class="box_content">
                <?php
                $Read->FullRead("SELECT * FROM mdp_setup");

                if (!$Read->getResult()):
                    echo "<div class='trigger al_center trigger_info trigger_none font_medium'>Ainda não existe um setup. Clique em Novo Setup!</div>";
                else:
                    foreach ($Read->getResult() as $plan):
                        extract($plan);
                        
                     
                     ?>
					 <div class="callback_return"></div>
                            <article class="course_gerent_module course_list" id="<?= $mdp_plans_id; ?>">
                            <h1 class="row_title icon-profile">
                               FORMULÁRIO DE CONTATO
                            </h1><p class="row">
							<?
							$status = ($setup_form_contato == 1 ? 'ON' : 'OFF');
							$statusColor = ($setup_form_contato == 1 ? 'bg_green' : 'bg_red');
							$days = ($setup_form_days ? $setup_form_days : 07);
							
							?>
                                <span class="<?= $statusColor?>" style="color:#fff; text-align:center; font-size:1em; width:100px;"><b> <?= $status;?></b></span><span class="bg_yellow" style="color:#fff; text-align:center; font-size:1em; width:200px;"><b> <?= $days;?> Dias</b></span>
                            </p><p class="row">
                                <a title="Editar esse Setup" href="dashboard.php?wc=setup/create&set=<?= $setup_id; ?>" class="btn btn_blue icon-pencil2 icon-notext"></a>
								
								
                </p>
                        </article>
                        <?php
						/* else:
						echo $result;*/
 
                    endforeach;
                endif;
                ?>
                <div class="clear"></div>
            </div>
        </article>
		
    </section>
</div>

