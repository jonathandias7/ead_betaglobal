<?php
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;
$Read = new Read;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-profile">PLANOS</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=mdpplays/homelist">Atributos do playo</a>
            <span class="crumb">/</span>
            Gerenciar Planos
        </p>
    </div>
	<div class="dashboard_header_search">
        <a title="Nova Hellobar" href="dashboard.php?wc=mdpvideo/create" class="btn btn_green icon-plus">Cadastrar Novo Plano!</a>
    </div>
</header>

<div class="j_content dashboard_content">
    <section class="box box100">
        <article class="box box100 course_list">
            <header class="header_green">
                <h1 class="icon-file-text2">Meus Planos:</h1>
                <div class="clear"></div>
            </header>
            <div class="box_content">
                <?php
                $Read->FullRead("SELECT * FROM mdp_play");

                if (!$Read->getResult()):
                    echo "<div class='trigger al_center trigger_info trigger_none font_medium'>Ainda não existem provas cadastradas. Acesse os módulos dos cursos para cadastrar as provas!</div>";
                else:
                    foreach ($Read->getResult() as $play):
                        extract($play);
                        
                     
                      
                        ?>
                     <? //if($result != '3' || $result != 0')://valida o filtro?>
					  <?
					  if($mdp_play_title != null):?>
					 <div class="callback_return"></div>
                            <article class="course_gerent_module course_list" id="<?= $mdp_play_id; ?>">
                            <h1 class="row_title icon-profile">
                                <?= $mdp_play_title; ?>
                            </h1><p class="row">
							<?
							$status = ($mdp_play_status == 1 ? 'ON' : 'OFF');
							$statusColor = ($mdp_play_status == 1 ? 'bg_green' : 'bg_red');
							$tipo = ($mdp_play_host == 1 ? "YOUTUBE" : "VIMEO");
							$typeColor = ($mdp_play_host == 1 ? 'bg_red' : 'bg_blue');
							?>
                                <span class="<?= $statusColor?>" style="color:#fff; text-align:center; font-size:1em; width:100px;"><b> <?= $status;?></b></span><span class="<?= $typeColor?>" style="color:#fff; text-align:center; font-size:1em; width:200px;"><b> <?= $tipo;?></b></span>
                            </p><p class="row">
                                <a title="Editar essa Avaliação" href="dashboard.php?wc=mdpvideo/create&play=<?= $mdp_play_id; ?>" class="btn btn_blue icon-pencil2 icon-notext"></a>
								<a rel="course_list" class="j_delete_action icon-cancel-circle btn btn_red icon-notext" id="<?= $mdp_play_id; ?>"></a>
								<a rel="course_list" callback='AvFullead' callback_action="av_delete" class="j_delete_action_confirm icon-warning btn btn_yellow" style="display: none ;margin-top: 30px;" id="<?= $mdp_play_id; ?>">Deletar Avaliação?</a>
                </p>
                        </article>
                        <?php
						/* else:
						echo $result;*/
						endif; 
                    endforeach;
                endif;
                ?>
                <div class="clear"></div>
            </div>
        </article>
		
    </section>
</div>

