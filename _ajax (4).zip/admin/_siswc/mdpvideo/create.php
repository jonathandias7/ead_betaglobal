<?php
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;



// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;
if (empty($Create)):
    $Create = new Create;
endif;
$PlansId = filter_input(INPUT_GET, 'play', FILTER_VALIDATE_INT);

if(empty($PlansId)):
$plays = ['mdp_play_status'=> 0];
$Create->ExeCreate("mdp_play",$plays);
Header("Location: dashboard.php?wc=mdpvideo/create&play=". $Create->getResult());
exit;
endif;
$Read->ExeRead("mdp_play","WHERE mdp_play_id = $PlansId");
if($Read->getResult()):
extract($Read->getResult()[0]);
endif;

?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-pagebreak">Novo Plano</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
           Planos
        </p>
    </div>


</header>


<div class="dashboard_content">

    <div class="box box100">

        <div class="panel_header default">
            <h2 class="icon-tree">Sobre o Plano</h2>
        </div>
 
        <div class="panel">
           <form class="" name="mdp_play_create" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="MDPPlay"/>
                <input type="hidden" name="callback_action" value="play_create"/>
				<input type="hidden" name="mdp_play_id" value="<?= $PlansId ?>">
                
            
				<div class="label_50">
							<label class="label">
								<span class="legend">TITULO</span>
								<input style="font-size: 1.5em;" type="text" name="mdp_play_title" value="<?= $mdp_play_title?>" placeholder="Título Do Plano:" required/>
							</label>
							
							
						
							 <label class="label">
								<span class="legend">url:</span>
								<input style="font-size: 1.5em;" type="text" name="mdp_play_url" value="<?= $mdp_play_url?>" placeholder="Descrição:" required/>
							</label>
							
							<div class="clear"></div>
							
						</div>
				

               
                <div class="label_33">
							<label class="label">
								<span class="legend">Status<span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Caso desativa, a prova será criada mas não exibida e nem necessária no campus</span></span></span>
								<select name="mdp_play_status"  required="required">
								<option value="0" <?=($mdp_play_status == 0 ? 'selected="selected"' : '')?> >Desativado</option>
								<option value="1" <?=($mdp_play_status == 1 ? 'selected="selected"' : '')?>>Ativado</option>
							
								</select>
							</label>
							

							

                 

                    <label class="label">
                        <span class="legend">TIPO:</span>
                        <select name="mdp_play_type">
						<option value="0" <?=($mdp_play_type == 0 ? 'selected="selected"' : '')?>>selecione</option>
                            <option value="1"  <?=($mdp_play_type == 1 ? 'selected="selected"' : '')?>>Exibir Por Session</option>
                            <option value="2"  <?=($mdp_play_type == 2 ? 'selected="selected"' : '')?>>Sem Session</option>
							
                        </select>
                    </label>
                
                    <label class="label">
                        <span class="legend">HOST:</span>
                        <select name="mdp_play_host">
						<option value="0" <?=($mdp_play_host == 0 ? 'selected="selected"' : '')?>>selecione</option>
                            <option value="1"  <?=($mdp_play_host == 1 ? 'selected="selected"' : '')?>>Youtube</option>
                            <option value="2"  <?=($mdp_play_host == 2 ? 'selected="selected"' : '')?>>Vimeo</option>
							
                        </select>
                    </label>

                 
                </div>
				
                <div class="m_top">&nbsp;</div>
					
              

				
                <div class="m_top">&nbsp;</div>
                <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                <button class="btn btn_green icon-price-tags fl_right">Finalizar</button>
				
                <div class="clear"></div>
            </form>
        </div>
    </div>
</div>