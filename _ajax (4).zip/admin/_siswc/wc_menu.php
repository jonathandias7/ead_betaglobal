	<?php
$NivelAdm = 6 ;
	if ($_SESSION['userLogin']['user_level'] >= $NivelAdm):
		if (APP_PAGES && $_SESSION['userLogin']['user_level'] >= LEVEL_WC_PAGES):
                        $wc_pages_alerts = null;
                        $Read->FullRead("SELECT count(page_id) as total FROM " . DB_PAGES . " WHERE page_status != 1 AND page_type_serv >= 1");
                        if ($Read->getResult() && $Read->getResult()[0]['total'] >= 1):
                            $wc_pages_alerts .= "<span class='wc_alert bar_yellow'>{$Read->getResult()[0]['total']}</span>";
                        endif;
                        ?>
                        <li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'attr/home') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-plus" title="Serviços" href="dashboard.php?wc=attr/home">Serviços<?= $wc_pages_alerts; ?></a>
							
						</li>
						<?php
                    endif;
		?>

	
		<?php endif;?>
	<!--	<li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'setup/home') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="" title="Setup" href="dashboard.php?wc=setup/home">Setup</a>
		<ul class="dashboard_nav_menu_sub">	
        <li class="dashboard_nav_menu_sub_li <?= strstr($getViewInput, 'setup/homeimg') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-image" title="imagens" href="dashboard.php?wc=setup/homeimg">Imagem Destaque</a></li>				
		<li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'setup/home') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="" title="Setup" href="dashboard.php?wc=setup/home">Formulário</a></li>
		
		</ul>
		</li>
		<li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'mdpplans/home') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-calendar" title="Avaliação" href="dashboard.php?wc=mdpplans/home">Planos</a>
		<ul class="dashboard_nav_menu_sub">	
        <li class="dashboard_nav_menu_sub_li <?= strstr($getViewInput, 'mdpplans/create') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-list" title="Hellobar" href="dashboard.php?wc=mdpplans/homelist">Atributos Do Plano</a></li>				
		<li class="dashboard_nav_menu_sub_li <?= strstr($getViewInput, 'mdpplans/create') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-plus" title="Hellobar" href="dashboard.php?wc=mdpplans/create">criar Plano</a></li>
		
		</ul>
		</li>
		<li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'mdpvideo/home') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-play" title="Avaliação" href="dashboard.php?wc=mdpvideo/home">Video Destaque</a>
		<ul class="dashboard_nav_menu_sub">		
		<li class="dashboard_nav_menu_sub_li <?= strstr($getViewInput, 'mdpvideo/create') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-plus" title="Hellobar" href="dashboard.php?wc=mdpvideo/create">Criar Video</a></li>		
		</ul>
		</li>
	-->	
<li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'mdpsecurity/home') ? 'dashboard_nav_menu_sub_li_active' : ''; ?>"><a class="icon-play" title="Videos" href="dashboard.php?wc=faq/home">FAQ</a></li>
  
</li>
<?php
// SETOR ADMINISTRATIVO
if ($_SESSION['userLogin']['user_level'] >= 9): ?>
<li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'mdpcustom/') ? 'dashboard_nav_menu_active' : ''; ?>"><a class="icon-droplet">Customizações</a>
    <ul class="dashboard_nav_menu_sub">
        <li class="dashboard_nav_menu_li <?= strstr($getViewInput, 'mdpcustom/create') ? 'dashboard_nav_menu_sub_li_active' : ''; ?>"><a  title="Variação do produto" href="dashboard.php?wc=mdpcustom/create">&raquo;Customizar</a></li>
    </ul>
</li>
<?php
endif;