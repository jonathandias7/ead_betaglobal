<?php
$AdminLevel = 6;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;



// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;
if (empty($Create)):
    $Create = new Create;
endif;
$PlansId = filter_input(INPUT_GET, 'plan', FILTER_VALIDATE_INT);

if(empty($PlansId)):
$plans = ['mdp_plans_status'=> 0];
$Create->ExeCreate("mdp_plans",$plans);
Header("Location: dashboard.php?wc=mdpplans/create&plan=". $Create->getResult());
exit;
endif;
$Read->ExeRead("mdp_plans","WHERE mdp_plans_id = $PlansId");
if($Read->getResult()):
extract($Read->getResult()[0]);
endif;

?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-pagebreak">Novo Plano</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
           Planos
        </p>
    </div>


</header>


<div class="dashboard_content">

    <div class="box box100">

        <div class="panel_header default">
            <h2 class="icon-tree">Sobre o Plano</h2>
        </div>
 
        <div class="panel">
           <form class="" name="mdp_plans_create" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="MDPPlans"/>
                <input type="hidden" name="callback_action" value="plans_create"/>
				<input type="hidden" name="mdp_plans_id" value="<?= $PlansId ?>">
                
            
				<div class="label_100">
							<label class="label">
								<span class="legend">TITULO</span>
								<input style="font-size: 1.5em;" type="text" name="mdp_plans_title" value="<?= $mdp_plans_title?>" placeholder="Título Do Plano:" required/>
							</label>
							<div class="clear"></div>
							</div><div class="label_50">
							 <label class="label">
								<span class="legend">Dica:</span>
								<input style="font-size: 1.5em;" type="text" name="mdp_plans_dica" value="<?= $mdp_plans_dica?>" placeholder="Descrição:" required/>
							</label>
							<label class="label">
								<span class="legend">Descrição:</span>
								 <input style="font-size: 1.5em;" type="text" name="mdp_plans_desc" value="<?= $mdp_plans_desc?>" placeholder="Descrição:" required/>
							</label>
							<div class="clear"></div>
							
						</div>
				

               
                <div class="label_33">
							<label class="label">
								<span class="legend">Status<span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Caso desativa, a prova será criada mas não exibida e nem necessária no campus</span></span></span>
								<select name="mdp_plans_status"  required="required">
								<option value="0" <?=($mdp_plans_status == 0 ? 'selected="selected"' : '')?> >Desativado</option>
								<option value="1" <?=($mdp_plans_status == 1 ? 'selected="selected"' : '')?>>Ativado</option>
							
								</select>
							</label>
							

							

                 

                    <label class="label">
                        <span class="legend">Quantidade de questões:</span>
                        <select name="mdp_plans_type">
						<option value="0" <?=($mdp_plans_type == 0 ? 'selected="selected"' : '')?>>Selecione uma opção</option>
                            <option value="1"  <?=($mdp_plans_type == 1 ? 'selected="selected"' : '')?>>Com Preço</option>
                            <option value="2"  <?=($mdp_plans_type == 2 ? 'selected="selected"' : '')?>>Sem Preço</option>
							
                        </select>
                    </label>
                
                    <label class="label">
                        <span class="legend">Valor: <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Valor referente ao total de pontos para Essa avaliação.</span></span></span>
                        <input style="font-size: 1.2em;" type="text" name="mdp_plans_price" value="<?= (isset($mdp_plans_price) ? $mdp_plans_price : ''); ?>" placeholder="valor mensal(opcional)">
                    </label>

                 
                </div>
				
                <div class="m_top">&nbsp;</div>
					
              

				
                <div class="m_top">&nbsp;</div>
                <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                <button class="btn btn_green icon-price-tags fl_right">Finalizar</button>
				
                <div class="clear"></div>
            </form>
        </div>
    </div>
</div>