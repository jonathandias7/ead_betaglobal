/*
Navicat MariaDB Data Transfer

Source Server         : localhost
Source Server Version : 100128
Source Host           : localhost:3306
Source Database       : charme_fitness

Target Server Type    : MariaDB
Target Server Version : 100128
File Encoding         : 65001

Date: 2018-02-01 16:21:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ws_products_wishlist
-- ----------------------------
DROP TABLE IF EXISTS `ws_products_wishlist`;
CREATE TABLE `ws_products_wishlist` (
  `wishlist_id` int(11) NOT NULL AUTO_INCREMENT,
  `pdt_id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`wishlist_id`),
  KEY `ws_wishlist_products` (`pdt_id`),
  KEY `ws_wishlist_user` (`user_id`),
  CONSTRAINT `ws_wishlist_products` FOREIGN KEY (`pdt_id`) REFERENCES `ws_products` (`pdt_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `ws_wishlist_user` FOREIGN KEY (`user_id`) REFERENCES `ws_users` (`user_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ws_products_wishlist
-- ----------------------------
