<?php

$AdminLevel = LEVEL_WC_EAD_COURSES;
//!APP_EAD || !EAD_STUDENT_EVALUATES ||
if ( empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

$Read = new Read;
$Create = new Create;

$AvId = filter_input(INPUT_GET, 'prov', FILTER_VALIDATE_INT);
if (!$AvId):
    $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar questões a uma prova sem informá-la!", E_USER_NOTICE);
    header('Location: dashboard.php?wc=teach/courses');
else:
    $Read->FullRead("SELECT avaliacao_id, avaliacao_title, avaliacao_type FROM " . DB_EAD_AVALIACAO . " WHERE avaliacao_id = :id", "id={$AvId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar questões a uma prova sem informar...!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=teach/courses');
    endif;
endif;

$ModId = filter_input(INPUT_GET, 'module', FILTER_VALIDATE_INT);
if ($ModId):
    $Read->ExeRead(DB_EAD_MODULES, "WHERE module_id = :id", "id={$ModId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar provas a um módulo de curso que não existe ou que foi removido recentemente!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=teach/courses_gerente&id=' . $course_id);
    endif;
else:
    $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar provas a um módulo de curso que não existe ou que foi removido recentemente!", E_USER_NOTICE);
    header('Location: dashboard.php?wc=teach/courses_gerente&id=' . $course_id);
endif;
?>
<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-question">Perguntas: <?= $avaliacao_title; ?></h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=teach/courses">Cursos</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=teach/courses_gerent&id=<?= $course_id; ?>"><?= $avaliacao_title; ?></a>
            <span class="crumb">/</span>
            Perguntas
        </p>
    </div>

    <div class="dashboard_header_search">
        <a class="btn btn_green icon-pencil2 icon-notext" href="dashboard.php?wc=teach/courses_modules&id=<?= $course_id; ?>&module=<?= $module_id; ?>" title="Editar Módulo"></a>
        <a class="btn btn_yellow icon-profile icon-notext" href="dashboard.php?wc=fullead/home" title="Ver Provas"></a>
        <a title="Voltar ao Curso!" href="dashboard.php?wc=teach/courses_gerent&id=<?= $course_id; ?>" class="wc_view btn btn_blue icon-lab">Ver Módulos!</a>
    </div>

</header>
 <!-- INSIRA AQUI O SEU panel_header -->
    <div class="panel">
                <div class="box box100 ">
				
				<div class="box box50">
				<!--painel-->
				<div class="panel_header success">
				
					<span>
						<a href="javascript:void(0)" class="btn icon-notext icon-link"></a>
					</span>
				<h1 style="color:#fff" class="icon-plus">Cadastrar Pergunta<b style="color:#fff"></h1>
				</div>
				<div class="clear"></div>
				<br/>
				    <form name="pergunta_create" action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="callback" value="AvFullead"/>
                    <input type="hidden" name="callback_action" value="pergunta_create"/>
                    <input type="hidden" name="avaliacao_id" value="<?= $AvId; ?>"/>
					<input type="hidden" name="module_id" value="<?= $ModId; ?>"/>
                    <label class="label">
                        <span class="legend"></span>
                        <input style="font-size: 1.2em;" type="text" name="perg_title" value="<?= $perg_title;?>" placeholder="Título da Questão:" required/>
                    </label>

                    <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 6px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                    <button style="padding: 10px;" class="btn btn_green icon-plus fl_right">Cadastrar</button>
                    <div class="clear"></div>
                </form>
               
			</div><div class="box box50">
				
			
				<!--painel-->
				<div class="panel_header alert">
				
					<span>
						<a href="javascript:void(0)" class="btn icon-notext icon-link"></a>
					</span>
					<h1 style="color:#fff" class="icon-pencil2">Perguntas da <b style="color:#fff">Av:</b> <?= $avaliacao_title;?></a></h1>
					</h1></h2>
				</div><br/>
				
				
				<?php
				if ($avaliacao_type == 1):
        
				
             $Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE avaliacao_id = :id ORDER BY perg_id ASC", "id={$AvId}");
                if (!$Read->getResult()):
                    echo '<div class="trigger trigger_info trigger_none al_center icon-info">Ainda não existem questões cadastradas para a prova ' . $avaliacao_title . '!</div>';
                    echo '<div class="clear"></div>';
                else:
				$Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE avaliacao_id = :id ORDER BY perg_id ASC", "id={$AvId}");
    
                foreach ($Read->getResult() as $avfull):
                    extract($avfull);?>
					
                        <article class="box box100 mdp_avaliacao" id="<?= $perg_id; ?>">
                            <div class="box_content">
                                <h1 class="row_title">
								
                                   <?= $perg_title;?>
								   
								   
                                <p class="actions fl_right">
                                    <?php
                                    //verifica o número de opções da questão
                                    $Read->FullRead("SELECT op_id FROM " . DB_EAD_AVALIACAO_RESPOSTAS . " WHERE perg_id = :perg", "perg={$perg_id}");
                                    $TotOp = $Read->getRowCount();
                                    ?>
                                    <a title="Adicionar opções" href="dashboard.php?wc=fullead/av_resposta&perg=<?= $perg_id; ?>&prov=<?= $AvId; ?>" class="btn btn_green icon-plus icon-notext"></a>
                                    <a href="dashboard.php?wc=fullead/questionedit&prov=<?= $AvId; ?>&perg=<?= $perg_id; ?>" title="Editar Questão" class="btn btn_blue icon-pencil2 icon-notext"></a>
                                    <span rel='mdp_avaliacao' class='j_delete_action icon-cancel-circle icon-notext btn btn_red' id='<?= $perg_id; ?>'></span>
                                    <span rel='mdp_avaliacao' callback='AvFullead' callback_action='pergunta_delete' class='j_delete_action_confirm icon-warning icon-notext btn btn_yellow' style='display: none' id='<?= $perg_id; ?>'></span>
									<h2 style="color:orange;">Total:<?$Read->FullRead("SELECT op_id FROM " . DB_EAD_AVALIACAO_RESPOSTAS . " WHERE perg_id = :perg", "perg={$perg_id}");
									$TotOp = $Read->getRowCount();
                                    ?><a style="margin-left:10px;"class="btn btn_yellow "><?= $TotOp; ?></a>
								</p></h1>
                            </div>
							<hr/>
                        </article><?php
                endforeach;
            endif;
		endif;
            ?>
				</div>
				
			</div>

					<div class="box box33">
				
						<!-- INSIRA AQUI O SEU panel_header -->
						<div style="border: solid 3px orange;font-size:1em;color:#282828; height:160px;" class="panel">
							<p><h2 style="color:orange;text-align:center;">Total:</h2></p>
								<p>Contabiliza quantas respostas existem para a pergunta.</p><div class="clear"></div>
						</div>
						
					</div>
					<div class="box box33">
				
						<!-- INSIRA AQUI O SEU panel_header -->
						<div style="border: solid 3px orange;font-size:1em;color:#282828; height:160px;" class="panel">
							<p style="text-align:center"><a  class="btn btn_green icon-plus icon-notext"></a></p>
							Gera uma nova resposta para a pergunta.</p><br/>
						</div>
						
					</div>
					<div class="box box33">
				
						<!-- INSIRA AQUI O SEU panel_header -->
						<div style="border: solid 3px orange;font-size:1em;color:#282828; height:160px;" class="panel">
							<p style="text-align:center"><a class="btn btn_blue icon-pencil2 icon-notext"></a></p>
							 Clique aqui para editar a pergunta.</p><br/>
						</div>
						
					</div>			
	</div>
	
</div>
