<?php
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
$AdminLevel = LEVEL_WC_EAD_COURSES;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;
$CourseId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$MId = filter_input(INPUT_GET, 'module', FILTER_VALIDATE_INT);
$Read = new Read;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-profile">AVALIAÇÕES</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=evaluates/home">Provas</a>
            <span class="crumb">/</span>
            Gerenciar Provas
        </p>
    </div>
</header>

<div class="j_content dashboard_content">
    <section class="box box100">
        <article class="box box100 course_list">
            <header class="header_green">
                <h1 class="icon-file-text2">Provas:</h1>
                <div class="clear"></div>
            </header>
            <div class="box_content">
                <?php
                $Read->FullRead("SELECT * FROM ".DB_EAD_AVALIACAO." WHERE module_id = {$MId}");

                if (!$Read->getResult()):
                    echo "<div class='trigger al_center trigger_info trigger_none font_medium'>Ainda não existem provas cadastradas. Acesse os módulos dos cursos para cadastrar as provas!</div>";
                else:
                    foreach ($Read->getResult() as $avaliacao):
                        extract($avaliacao);
                        
                        $Read->FullRead("SELECT module_id, module_title FROM " . DB_EAD_MODULES . " WHERE module_id = :id", "id={$module_id}");
                        if($Read->getResult()):
                            extract($Read->getResult()[0]);
                        endif;
                      
                        ?>
                     <? //if($result != '3' || $result != 0')://valida o filtro?>
					  <?
					  if($avaliacao_title != null):?>
					 <div class="callback_return"></div>
                            <article class="course_gerent_module course_list" id="<?= $avaliacao_id; ?>">
                            <h1 class="row_title icon-profile">
                                <?= $avaliacao_title; ?>
                            </h1><p class="row">
							<?
							$tipo = ($avaliacao_type == 1 ? 'MARCAÇÃO' : 'TEXTO');
							$typeColor = ($avaliacao_type == 1 ? 'bg_green' : 'bg_blue');
							?>
                                <span>Módulo: <?= $module_title; ?></span><span class="<?= $typeColor?>" style="color:#fff; text-align:center; font-size:1em; width:100px;"><b> <?= $tipo;?></b></span>
                            </p><p class="row">
                                <a title="Editar essa Avaliação" href="dashboard.php?wc=fullead/courses_av_modules&id=<?= $CourseId; ?>&module=<?= $module_id; ?>&prov=<?= $avaliacao_id; ?>" class="btn btn_yellow icon-pencil2 icon-notext"></a>
								<a title="Criar perguntas Avaliação" href="dashboard.php?wc=fullead/av_perguntas&module=<?= $module_id; ?>&prov=<?= $avaliacao_id; ?>" class="btn btn_green icon-profile icon-notext"></a>
								<a rel="course_list" class="j_delete_action icon-cancel-circle btn btn_red icon-notext" id="<?= $avaliacao_id; ?>"></a>
								<a rel="course_list" callback='AvFullead' callback_action="av_delete" class="j_delete_action_confirm icon-warning btn btn_yellow" style="display: none ;margin-top: 30px;" id="<?= $avaliacao_id; ?>">Deletar Avaliação?</a>
                </p>
                        </article>
                        <?php
						/* else:
						echo $result;*/
						endif; 
                    endforeach;
                endif;
                ?>
                <div class="clear"></div>
            </div>
        </article>
		<div class="box box50">
				
						<!-- INSIRA AQUI O SEU panel_header -->
						<div style="border: solid 3px #00b594;font-size:1em;" class="panel">
							<p><a class="btn btn_green icon-profile icon-notext"></a>  </p>
							Você Será direcionado para formular as perguntas da avaliação selecionada.
							Também poderá visualizar ou editar as perguntas criadas para a avaliação selecionada.</p>
						</div>
						
					</div>
					<div class="box box50">
				
						<!-- INSIRA AQUI O SEU panel_header -->
						<div style="border: solid 3px orange;font-size:1em;" class="panel">
							<p><a class="btn btn_yellow icon-pencil2 icon-notext"></a></p>
							  Você será direcionado a página de edição da avaliação.
							  Aqui poderá alterar todos os aspectos necessários para seu projeto.</p><br/>
						</div>
						
					</div>
    </section>
</div>

