/*
Navicat MariaDB Data Transfer

Source Server         : localhost
Source Server Version : 100128
Source Host           : localhost:3306
Source Database       : charme_fitness

Target Server Type    : MariaDB
Target Server Version : 100128
File Encoding         : 65001

Date: 2018-02-01 16:21:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ws_products_gallery
-- ----------------------------
DROP TABLE IF EXISTS `ws_products_gallery`;
CREATE TABLE `ws_products_gallery` (
  `product_id` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wc_produtcts_gallery` (`product_id`),
  CONSTRAINT `wc_produtcts_gallery` FOREIGN KEY (`product_id`) REFERENCES `ws_products` (`pdt_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ws_products_gallery
-- ----------------------------
INSERT INTO `ws_products_gallery` VALUES ('1', '1', 'images/2017/10/1-1-1508200428mtuwodiwmdqyoa.jpg');
INSERT INTO `ws_products_gallery` VALUES ('1', '2', 'images/2017/10/1-1-1508200431mtuwodiwmdqzmq.jpg');
INSERT INTO `ws_products_gallery` VALUES ('2', '3', 'images/2017/10/2-1-1508200861mtuwodiwmdg2mq.jpg');
INSERT INTO `ws_products_gallery` VALUES ('2', '4', 'images/2017/10/2-1-1508200865mtuwodiwmdg2nq.jpg');
INSERT INTO `ws_products_gallery` VALUES ('3', '5', 'images/2017/10/3-1-1508201058mtuwodiwmta1oa.jpg');
INSERT INTO `ws_products_gallery` VALUES ('4', '6', 'images/2017/10/4-1-1508202138mtuwodiwmjezoa.jpg');
INSERT INTO `ws_products_gallery` VALUES ('4', '7', 'images/2017/10/4-1-1508202142mtuwodiwmje0mg.jpg');
INSERT INTO `ws_products_gallery` VALUES ('5', '8', 'images/2017/10/5-1-1508202344mtuwodiwmjm0na.jpg');
INSERT INTO `ws_products_gallery` VALUES ('5', '9', 'images/2017/10/5-1-1508202347mtuwodiwmjm0nw.jpg');
INSERT INTO `ws_products_gallery` VALUES ('6', '10', 'images/2017/10/6-1-1508202482mtuwodiwmjq4mg.jpg');
INSERT INTO `ws_products_gallery` VALUES ('6', '11', 'images/2017/10/6-1-1508202487mtuwodiwmjq4nw.jpg');
INSERT INTO `ws_products_gallery` VALUES ('7', '12', 'images/2017/10/7-1-1508202652mtuwodiwmjy1mg.jpg');
INSERT INTO `ws_products_gallery` VALUES ('7', '13', 'images/2017/10/7-1-1508202656mtuwodiwmjy1ng.jpg');
INSERT INTO `ws_products_gallery` VALUES ('8', '14', 'images/2017/10/8-1-1508203031mtuwodiwmzazmq.jpg');
INSERT INTO `ws_products_gallery` VALUES ('8', '15', 'images/2017/10/8-1-1508203035mtuwodiwmzaznq.jpg');
INSERT INTO `ws_products_gallery` VALUES ('9', '16', 'images/2017/10/9-1-1508203212mtuwodiwmzixmg.jpg');
INSERT INTO `ws_products_gallery` VALUES ('9', '17', 'images/2017/10/9-1-1508203215mtuwodiwmzixnq.jpg');
INSERT INTO `ws_products_gallery` VALUES ('9', '18', 'images/2017/10/9-1-1508203218mtuwodiwmzixoa.jpg');
INSERT INTO `ws_products_gallery` VALUES ('10', '19', 'images/2017/10/10-1-1508203642mtuwodiwmzy0mg.jpg');
INSERT INTO `ws_products_gallery` VALUES ('10', '20', 'images/2017/10/10-1-1508203645mtuwodiwmzy0nq.jpg');
INSERT INTO `ws_products_gallery` VALUES ('11', '21', 'images/2017/10/11-1-1508203757mtuwodiwmzc1nw.jpg');
INSERT INTO `ws_products_gallery` VALUES ('11', '22', 'images/2017/10/11-1-1508203760mtuwodiwmzc2ma.jpg');
INSERT INTO `ws_products_gallery` VALUES ('12', '23', 'images/2017/10/12-1-1508203902mtuwodiwmzkwmg.jpg');
INSERT INTO `ws_products_gallery` VALUES ('12', '24', 'images/2017/10/12-1-1508203904mtuwodiwmzkwna.jpg');
INSERT INTO `ws_products_gallery` VALUES ('13', '25', 'images/2017/10/13-1-1508203997mtuwodiwmzk5nw.jpg');
INSERT INTO `ws_products_gallery` VALUES ('13', '26', 'images/2017/10/13-1-1508204000mtuwodiwndawma.jpg');
INSERT INTO `ws_products_gallery` VALUES ('14', '27', 'images/2017/10/14-1-1508204099mtuwodiwnda5oq.jpg');
INSERT INTO `ws_products_gallery` VALUES ('15', '28', 'images/2017/10/15-1-1508204261mtuwodiwndi2mq.jpg');
INSERT INTO `ws_products_gallery` VALUES ('15', '29', 'images/2017/10/15-1-1508204263mtuwodiwndi2mw.jpg');
INSERT INTO `ws_products_gallery` VALUES ('16', '30', 'images/2017/10/16-1-1508204423mtuwodiwndqymw.jpg');
INSERT INTO `ws_products_gallery` VALUES ('16', '31', 'images/2017/10/16-1-1508204426mtuwodiwndqyng.jpg');
INSERT INTO `ws_products_gallery` VALUES ('17', '32', 'images/2017/10/17-1-1508204544mtuwodiwndu0na.jpg');
INSERT INTO `ws_products_gallery` VALUES ('17', '33', 'images/2017/10/17-1-1508204546mtuwodiwndu0ng.jpg');
