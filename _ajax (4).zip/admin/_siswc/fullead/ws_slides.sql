/*
Navicat MariaDB Data Transfer

Source Server         : localhost
Source Server Version : 100128
Source Host           : localhost:3306
Source Database       : charme_fitness

Target Server Type    : MariaDB
Target Server Version : 100128
File Encoding         : 65001

Date: 2018-02-01 16:30:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ws_slides
-- ----------------------------
DROP TABLE IF EXISTS `ws_slides`;
CREATE TABLE `ws_slides` (
  `slide_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `slide_status` int(11) NOT NULL DEFAULT '0',
  `slide_image_mobile` varchar(255) DEFAULT NULL,
  `slide_image_tablet` varchar(255) DEFAULT NULL,
  `slide_image_desktop` varchar(255) DEFAULT NULL,
  `slide_title` varchar(255) DEFAULT NULL,
  `slide_desc` text,
  `slide_link` varchar(255) DEFAULT NULL,
  `slide_date` timestamp NULL DEFAULT NULL,
  `slide_start` timestamp NULL DEFAULT NULL,
  `slide_end` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`slide_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ws_slides
-- ----------------------------
INSERT INTO `ws_slides` VALUES ('1', '1', 'slides/2017/11/moda-fitness-mobile.jpg', 'slides/2017/11/moda-fitness-tablet.jpg', 'slides/2017/11/moda-fitness-desktop.jpg', 'Moda Fitness', 'Descrição de teste', 'https://localhost/charme_fitness/produtos/moda-fitness', '2018-01-20 11:37:50', '2018-01-01 00:00:00', '2019-01-01 00:00:00');
INSERT INTO `ws_slides` VALUES ('2', '1', 'slides/2017/11/legging-fitness-mobile.jpg', 'slides/2017/11/legging-fitness-tablet.jpg', 'slides/2017/11/legging-fitness-desktop.jpg', 'Legging Fitness', 'Descrição de teste', 'https://localhost/charme_fitness/produtos/legging-fitness', '2018-01-20 11:38:00', '2018-01-01 00:00:00', '2019-01-01 00:00:00');
INSERT INTO `ws_slides` VALUES ('3', '1', 'slides/2017/11/body-fitness-mobile.jpg', 'slides/2017/11/body-fitness-tablet.jpg', 'slides/2017/11/body-fitness-desktop.jpg', 'Body Fitness', 'Descrição de teste', 'https://localhost/charme_fitness/produtos/body-fitness', '2018-01-20 11:38:08', '2018-01-01 00:00:00', '2019-01-01 00:00:00');
