<?php
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
$AdminLevel = LEVEL_WC_EAD_COURSES;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

$Read = new Read;
$Create = new Create;

$QuestionId = filter_input(INPUT_GET, 'perg', FILTER_VALIDATE_INT);
if ($QuestionId):
    $Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE question_id = :id", "id={$QuestionId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar opções a uma questão não existente!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=evaluates/home');
    endif;
else:
    $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar opções a uma questão não existente", E_USER_NOTICE);
    header('Location: dashboard.php?wc=evaluates/home');
endif;

$EvalId = filter_input(INPUT_GET, 'prov', FILTER_VALIDATE_INT);
if (!$EvalId):
    $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar opções a uma prova não existente!", E_USER_NOTICE);
    header('Location: dashboard.php?wc=teach/courses');
else:
    $Read->FullRead("SELECT avaliacao_title, module_id FROM " . DB_EAD_AVALIACAO . " WHERE avaliacao_id = :id", "id={$EvalId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar opções a uma prova não existente!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=teach/courses');
    endif;
endif;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-checkmark">Opções para a questão: <?= $question_title; ?></h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=teach/courses">Cursos</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=evaluates/avaliacao_questions&eval=<?= $EvalId;?>&module=<?= $module_id;?>">Questões</a>
            <span class="crumb">/</span>
            Adicionar Opções
        </p>
    </div>

    <div class="dashboard_header_search">
        <a title="Voltar aos Cursos!" href="dashboard.php?wc=teach/courses" class="wc_view btn btn_blue icon-lab">Ver Cursos!</a>
        <a title="Voltar às Provas!" href="dashboard.php?wc=evaluates/avaliacao_questions&eval=<?= $EvalId;?>&module=<?= $module_id;?>" class="wc_view btn btn_green icon-backward2">Voltar</a>
    </div>

</header>
<div class="dashboard_content">
<div class="box box100">

    <!-- <article class="box box50" style="margin: 0; padding: 0;">
       <section class="course_gerent_evaluate j_content">
            <?php
            $Read->ExeRead(DB_EAD_AVALIACAO_RESPOSTAS, "WHERE question_id = :id ORDER BY question_id ASC", "id={$QuestionId}");
            if (!$Read->getResult()):
                echo '<div class="trigger trigger_info trigger_none al_center icon-info">Ainda não existem opções cadastradas para a questão ' . $question_title . '!</div>';
                echo '<div class="clear"></div>';
            else:
                foreach ($Read->getResult() as $evals):
                    extract($evals);
                    $OK = ($option_ok == 1 ? 'CORRETA' : 'ERRADA');
                    $StatusOk = ($option_ok == 1 ? " btn_green" : " btn_red");
                    ?><article class="course_gerent_evaluates box box25" id="<?= $option_id;?>">
                        <div class="box_content">
                            <h1 class="row_title">
                                <?= str_pad($option_id, 2, 0, 0); ?>º - <?= $option_content; ?>
                            </h1><p class="actions">
                                <span class="btn <?= $StatusOk;?>"><?= $OK; ?></span>
                                <a href="dashboard.php?wc=evaluates/optionedit&question=<?= $question_id; ?>&option=<?= $option_id;?>" title="Editar Opção" class="btn btn_blue icon-pencil2 icon-notext"></a>
                                <span rel='course_gerent_evaluates' class='j_delete_action icon-cancel-circle icon-notext btn btn_red' id='<?= $option_id; ?>'></span>
                                <span rel='course_gerent_evaluates' callback='AvFullead' callback_action='option_delete' class='j_delete_action_confirm icon-warning icon-notext btn btn_yellow' style='display: none' id='<?= $option_id; ?>'></span>
                            </p>
                        </div>
                    </article><?php
                endforeach;
            endif;
            ?>
        </section>
    </article>-->
    <div class="box box50" style="margin: 0; padding: 0 5px;">
        <div class="box_content">
            <form name="class_add" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="AvFullead"/>
                <input type="hidden" name="callback_action" value="option_add"/>
                <input type="hidden" name="question_id" value="<?= $question_id; ?>"/>

                <label class="label">
                    <span class="legend">Opção:</span>
                    <input style="font-size: 1.2em;" type="text" name="option_content" value="" placeholder="Título da Opção:" required/>
                </label>

                <div class="m_top">&nbsp;</div>
                <div class="wc_actions" style="text-align: right">
                    <label class="label_check label_publish" style="padding: 11px; margin-right: 10px; font-weight: 500;"><input style="margin-top: -1px;" type="checkbox" value="1" name="option_ok"> CORRETA!</label>
                    <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 6px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                    <button style="padding: 10px;" class="btn btn_green icon-plus fl_right">CADASTRAR OPÇÃO!</button>
                </div>

                <div class="clear"></div>
            </form>
        </div>
    </div>
</div>