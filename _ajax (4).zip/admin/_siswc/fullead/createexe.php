<?php
$AdminLevel = 6;
if (!APP_EAD || empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

// AUTO INSTANCE OBJECT CREATE
if (empty($Create)):
    $Create = new Create;
endif;

//Usuario
$getUserId = Check::UserId($Admin['user_id']);
$CourseId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$ModId = filter_input(INPUT_GET, 'module', FILTER_VALIDATE_INT);
$ClassId = filter_input(INPUT_GET, 'class', FILTER_VALIDATE_INT);
if (!$ModId):
    $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou editar uma prova sem informar o módulo a que ela pertence!", E_USER_NOTICE);
    header('Location: dashboard.php?wc=teach/courses');
else:
    $Read->FullRead("SELECT module_id, course_id, module_title FROM " . DB_EAD_MODULES . " WHERE module_id = :id", "id={$ModId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou editar uma prova sem informar o módulo a que ela pertence!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=teach/courses');
    endif;
endif;

$getProvaId = filter_input(INPUT_GET, 'prov', FILTER_VALIDATE_INT);
if ($getProvaId):
    $Read->ExeRead(DB_EAD_EXE);
	 if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou editar uma prova de um que não existe ou que foi removido recentemente!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=teach/courses_gerente&id=' . $ModId);
    endif;
else:
    $Date = date('Y-m-d H:i:s');
    $FulleadCreate = ['module_id' => $ModId, 'exe_create' => $Date];
    $Create->ExeCreate(DB_EAD_EXE, $FulleadCreate);
    header('Location: dashboard.php?wc=fullead/createexe&id='. $CourseId .'&module=' . $ModId . '&prov=' . $Create->getResult());
endif;



$avaliacao_status = 0;
		$avaliacao_type = 0;
		$avaliacao_necessaria = 0;
		

?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-pagebreak">Avaliação</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
           Avaliação
        </p>
    </div>

    <div class="dashboard_header_search">
        <a title="Nova Página" href="dashboard.php?wc=pages/create" class="btn btn_green icon-plus">Voltar</a>
        <span class="btn btn_green icon-spinner9 wc_drag_active" title="Organizar Cursos">Ordenar</span>
    </div>

</header>


<div class="dashboard_content">

    <div class="box box100">
<?php if(!$ClassId):?>
        <div class="panel_header info">
            <h2 class="icon-tree">Exercicio</h2>
       </div>
	   <div class="panel">
	  <?php 
	  $exe_type = 0;
	  $exe_status = 0;
	  $exe_qtd = 0;
	  $date = date(DATE_W3C);
		$Read->ExeRead(DB_EAD_EXE);
		if($Read->getResult()):
		$exe = $Read->getResult();
		extract($exe[0]);
		endif;
		?>
	  
		<form  name="exe_add" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="AvFullead"/>
                <input type="hidden" name="callback_action" value="exe_create"/>
				 <input type="hidden" name="course_id" value="<?= $CourseId; ?>"/>
				 <input type="hidden" name="exe_create" value="<?= $date; ?>"/>
				  <input type="hidden" name="exe_update" value="<?= $date; ?>"/>
				  <input type="hidden" name="user_id" value="<?= $Admin['user_id']; ?>"/>
				 <input type="hidden" name="module_id" value="<?= $ModId ?>"/>
                <input type="hidden" name="class_id" value="<?= $class_id; ?>"/>
            
				<div class="label_50">
							<label class="label">
								<span class="legend">Author</span>
								<input class="bg_green" style="font-size: 1.4em;color:#fff;border:solid 3px #ccc;" disabled="disabled" value="<?= $Admin['user_name']." ".$Admin['user_lastname'];?>">
							</label>
							
							 <label class="label">
								<span class="legend">Identificação:</span>
								<input style="font-size: 1.5em;" type="text" name="exe_title" value="" placeholder="Título da prova:" required/>
							</label>
		
							<div class="clear"></div>
							
				
						</div>
				
		<div>
            <h3 class="icon-tree">Parâmetros do Exercicio:</h3>
        </div>
              
               <div class="label_50">
							

					<label class="label">
                        <span class="legend">Valor: <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Valor referente ao total de pontos para Essa avaliação.</span></span></span>
                        <input style="font-size: 1em;" type="number" name="exe_result" value="<?= (isset($exe_result) ? $exe_result : '10'); ?>" placeholder="Quanto vale essa prova(1 a 10)?" required/>
                    </label>

				
					
							<label class="label">
                        <span class="legend">Quantidade de questões:</span>
                        <select style="font-size: 1em;" name="exe_qtd">
						<option value="0">Selecione uma opção</option>
                            <option value="5" <?= (($exe_qtd == 5) ? "selected='selected'" : ""); ?>>5 Questões</option>
                            <option value="10" <?= (($exe_qtd == 10) ? "selected='selected'" : ""); ?>>10 Questões</option>
							<option value="15" <?= (($exe_qtd == 15) ? "selected='selected'" : ""); ?>>15 Questões</option>
                            <option value="20" <?= (($exe_qtd == 20) ? "selected='selected'" : ""); ?>>20 Questões</option>
							<option value="25" <?= (($exe_qtd == 25) ? "selected='selected'" : ""); ?>>25 Questões</option>
                            <option value="30" <?= (($exe_qtd == 30) ? "selected='selected'" : ""); ?>>30 Questões</option>
							<option value="40" <?= (($exe_qtd == 40) ? "selected='selected'" : ""); ?>>40 Questões</option>
                            <option value="50" <?= (($exe_qtd == 50) ? "selected='selected'" : ""); ?>>50 Questões</option>
							<option value="60" <?= (($exe_qtd == 60) ? "selected='selected'" : ""); ?>>60 Questões</option>
                            <option value="100" <?= (($exe_qtd == 100) ? "selected='selected'" : ""); ?>>100 Questões</option>
							<option value="150" <?= (($exe_qtd == 150) ? "selected='selected'" : ""); ?>>150 Questões</option>
							<option value="200" <?= (($exe_qtd == 200) ? "selected='selected'" : ""); ?>>200 Questões</option>
                        </select>
                    </label>
				</div> 
					

				<div>
				<h3 class="icon-tree">Opcionais da Avaliação:</h3><br/>
				</div>
				<div class="label_50">
						<label class="label">
								<span class="legend">Tipo<span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Caso desativada, mesmo o aluno não conseguindo a pontuação,poderá realizar novamente a prova.</span></span></span>
								<select style="font-size: 1em;" name="exe_type" required="required">
								<option value="0" <?= (($exe_type == 0) ? "selected='selected'" : ""); ?>>Selecione um tipo</option>
								<option value="1" <?= (($exe_type == 1) ? "selected='selected'" : ""); ?>>Marcação</option>
								<option value="2" <?= (($exe_type == 2) ? "selected='selected'" : ""); ?>>Texto</option>
							
								</select>
							</label>
							  
					<label class="label">
								<span class="legend">Status da Avaliação <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Caso desativa, a prova será criada mas não exibida e nem necessária no campus</span></span></span>
								<select style="font-size: 1em;" name="exe_status" required="required">
								<option value="0" <?= (($exe_status == 0) ? "selected='selected'" : ""); ?>>Desativado para Aluno</option>
								<option value="1" <?= (($exe_status == 1) ? "selected='selected'" : ""); ?>>Ativado para Aluno</option>
							
								</select>
							</label>
					
         
                </div>
			
                <div class="m_top">&nbsp;</div>
                <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                <button class="btn btn_green icon-price-tags fl_right">Finalizar</button>
				
                <div class="clear"></div>
            </form>
			 </div>  
    </div>
<?php else:?>
<div class="panel_header info">
            <h2 class="icon-tree">Exercicio</h2>
       </div>
	   <div class="panel">
	  <?php 
	  $exe_type = 0;
	  $exe_status = 0;
	  $exe_qtd = 0;
	  $date = date(DATE_W3C);
		$Read->ExeRead(DB_EAD_EXE);
		if($Read->getResult()):
		$exe = $Read->getResult();
		extract($exe[0]);
		endif;
		?>
	  
		<form  name="exe_add" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="AvFullead"/>
                <input type="hidden" name="callback_action" value="exe_update"/>
				 <input type="hidden" name="course_id" value="<?= $CourseId; ?>"/>
				 <input type="hidden" name="exe_create" value="<?= $date; ?>"/>
				  <input type="hidden" name="exe_update" value="<?= $date; ?>"/>
				  <input type="hidden" name="user_id" value="<?= $Admin['user_id']; ?>"/>
				 <input type="hidden" name="module_id" value="<?= $ModId ?>"/>
                <input type="hidden" name="class_id" value="<?= $class_id; ?>"/>
				 <input type="hidden" name="exe_id" value="<?= $exe_id; ?>"/>
            
				<div class="label_50">
							<label class="label">
								<span class="legend">Author</span>
								<input class="bg_green" style="font-size: 1.4em;color:#fff;border:solid 3px #ccc;" disabled="disabled" value="<?= $Admin['user_name']." ".$Admin['user_lastname'];?>">
							</label>
							
							 <label class="label">
								<span class="legend">Identificação:</span>
								<input style="font-size: 1.5em;" type="text" name="exe_title" value="<?= $exe_title; ?>" placeholder="Título da prova:" required/>
							</label>
		
							<div class="clear"></div>
							
				
				</div>
				
		<div>
            <h3 class="icon-tree">Parâmetros do Exercicio:</h3>
        </div>
             <div class="label_50">
				
							

					<label class="label">
                        <span class="legend">Valor: <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Valor referente ao total de pontos para Essa avaliação.</span></span></span>
                        <input style="font-size: 1em;" type="number" name="exe_result" value="<?= (isset($exe_result) ? $exe_result : '10'); ?>" placeholder="Quanto vale essa prova(1 a 10)?" required/>
                    </label>

                    
					<label class="label">
								<span class="legend">Status da Avaliação <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Caso desativa, a prova será criada mas não exibida e nem necessária no campus</span></span></span>
								<select style="font-size: 1em;" name="exe_status" required="required">
								<option value="0" <?= (($exe_status == 0) ? "selected='selected'" : ""); ?>>Desativado para Aluno</option>
								<option value="1" <?= (($exe_status == 1) ? "selected='selected'" : ""); ?>>Ativado para Aluno</option>
							
								</select>
							</label>
			</div><div class="label_50">		
						<input class="bg_green" type="hidden" style="font-size: 1.4em;color:#fff;border:solid 3px #ccc;" name="exe_type"  value="1">
					
							<label class="label">
                        <span class="legend">Quantidade de questões:</span>
                        <select style="font-size: 1em;" name="exe_qtd">
						<option value="0">Selecione uma opção</option>
                            <option value="5" <?= (($exe_qtd == 5) ? "selected='selected'" : ""); ?>>5 Questões</option>
                            <option value="10" <?= (($exe_qtd == 10) ? "selected='selected'" : ""); ?>>10 Questões</option>
							<option value="15" <?= (($exe_qtd == 15) ? "selected='selected'" : ""); ?>>15 Questões</option>
                            <option value="20" <?= (($exe_qtd == 20) ? "selected='selected'" : ""); ?>>20 Questões</option>
							<option value="25" <?= (($exe_qtd == 25) ? "selected='selected'" : ""); ?>>25 Questões</option>
                            <option value="30" <?= (($exe_qtd == 30) ? "selected='selected'" : ""); ?>>30 Questões</option>
							<option value="40" <?= (($exe_qtd == 40) ? "selected='selected'" : ""); ?>>40 Questões</option>
                            <option value="50" <?= (($exe_qtd == 50) ? "selected='selected'" : ""); ?>>50 Questões</option>
							<option value="60" <?= (($exe_qtd == 60) ? "selected='selected'" : ""); ?>>60 Questões</option>
                            <option value="100" <?= (($exe_qtd == 100) ? "selected='selected'" : ""); ?>>100 Questões</option>
							<option value="150" <?= (($exe_qtd == 150) ? "selected='selected'" : ""); ?>>150 Questões</option>
							<option value="200" <?= (($exe_qtd == 200) ? "selected='selected'" : ""); ?>>200 Questões</option>
                        </select>
                    </label>
                </div>
				</div>
				
				
                <div class="m_top">&nbsp;</div>
                <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                <button class="btn btn_green  fl_right">Atualizar</button>
				
                <div class="clear"></div>
            </form>
			 </div>
    </div>

<?php endif;?>
       
    </div>
</div>