<?php

$AdminLevel = LEVEL_WC_EAD_COURSES;
//!APP_EAD || !EAD_STUDENT_EVALUATES ||
if ( empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

$Read = new Read;
$Create = new Create;

$AvId = filter_input(INPUT_GET, 'prov', FILTER_VALIDATE_INT);
if (!$AvId):
    $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar questões a uma prova sem informá-la!", E_USER_NOTICE);
    header('Location: dashboard.php?wc=teach/courses');
else:
    $Read->FullRead("SELECT avaliacao_id, avaliacao_title, avaliacao_type FROM " . DB_EAD_AVALIACAO . " WHERE avaliacao_id = :id", "id={$AvId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar questões a uma prova sem informar...!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=teach/courses');
    endif;
endif;

$ModId = filter_input(INPUT_GET, 'module', FILTER_VALIDATE_INT);
if ($ModId):
    $Read->ExeRead(DB_EAD_MODULES, "WHERE module_id = :id", "id={$ModId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar provas a um módulo de curso que não existe ou que foi removido recentemente!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=teach/courses_gerente&id=' . $course_id);
    endif;
else:
    $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar provas a um módulo de curso que não existe ou que foi removido recentemente!", E_USER_NOTICE);
    header('Location: dashboard.php?wc=teach/courses_gerente&id=' . $course_id);
endif;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-question">Questões para a prova: <?= $avaliacao_title; ?></h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=teach/courses">Cursos</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=teach/courses_gerent&id=<?= $course_id; ?>"><?= $avaliacao_title; ?></a>
            <span class="crumb">/</span>
            Adicionar Questões
        </p>
    </div>

    <div class="dashboard_header_search">
        <a class="btn btn_green icon-pencil2 icon-notext" href="dashboard.php?wc=teach/courses_modules&id=<?= $course_id; ?>&module=<?= $module_id; ?>" title="Editar Módulo"></a>
        <a class="btn btn_violet icon-question icon-notext" href="dashboard.php?wc=fullead/home" title="Ver Provas"></a>
        <a title="Voltar ao Curso!" href="dashboard.php?wc=teach/courses_gerent&id=<?= $course_id; ?>" class="wc_view btn btn_blue icon-lab">Ver Módulos!</a>
    </div>

</header>
<div class="dashboard_content">
			

    <?php
	
	
	
    if ($avaliacao_type == 1):
        ?>
        <article class="box box50" style="margin: 0; padding: 0;">
		
            <section class="course_gerent_evaluate j_content">
                <?php
                $Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE avaliacao_id = :id ORDER BY question_id ASC", "id={$avaliacao_id}");
                if (!$Read->getResult()):
                    echo '<div class="trigger trigger_info trigger_none al_center icon-info">Ainda não existem questões cadastradas para a prova ' . $avaliacao_title . '!</div>';
                    echo '<div class="clear"></div>';
                else:
                    foreach ($Read->getResult() as $evals):
                        extract($evals);
                        ?><article class="course_gerent_evaluates box box25" id="<?= $question_id; ?>">
                            <div class="box_content">
                                <h1 class="row_title">
                                    <?= str_pad($question_id, 2, 0, 0); ?>º - <?= $question_title; ?>
                                </h1><p class="actions">
                                    <?php
                                    //verifica o número de opções da questão
                                    $Read->FullRead("SELECT option_id FROM " . DB_EAD_AVALIACAO_RESPOSTAS . " WHERE question_id = :quid", "quid={$question_id}");
                                    $numOpt = $Read->getRowCount();
                                    ?>
                                    <a title="Adicionar opções" href="dashboard.php?wc=fullead/av_respostas&perg=<?= $question_id; ?>&prov=<?= $avaliacao_id; ?>" class="btn btn_green"><?= $numOpt; ?></a>
                                    <a href="dashboard.php?wc=fullead/questionedit&prov=<?= $avaliacao_id; ?>&perg=<?= $question_id; ?>" title="Editar Questão" class="btn btn_blue icon-pencil2 icon-notext"></a>
                                    <span rel='course_gerent_evaluates' class='j_delete_action icon-cancel-circle icon-notext btn btn_red' id='<?= $question_id; ?>'></span>
                                    <span rel='course_gerent_evaluates' callback='AvFullead' callback_action='pergunta_delete' class='j_delete_action_confirm icon-warning icon-notext btn btn_yellow' style='display: none' id='<?= $question_id; ?>'></span>
                                </p>
                            </div>
                        </article><?php
                    endforeach;
                endif;
                ?>
            </section>
        </article><!--article list-->

        <div class="box box50" style="margin: 0; padding: 0 5px;">
            <div class="box_content">
                <form name="class_add" action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="callback" value="AvFullead"/>
                    <input type="hidden" name="callback_action" value="question_add"/>
                    <input type="hidden" name="avaliacao_id" value="<?= $avaliacao_id; ?>"/>

                    <label class="label">
                        <span class="legend">Questão:</span>
                        <input style="font-size: 1.2em;" type="text" name="question_title" value="" placeholder="Título da Questão:" required/>
                    </label>

                    <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 6px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                    <button style="padding: 10px;" class="btn btn_green icon-plus fl_right">CADASTRAR QUESTÃO!</button>
                    <div class="clear"></div>
                </form>
            </div>
        </div><!--formulario-->
		</div>
        <?php
    endif;
    if ($avaliacao_type == 2):
        ?>
        <article class="box box100" style="margin: 0; padding: 0;">
            <section class="course_gerent_evaluateses j_content">
                <?php
                $Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE avaliacao_id = :id ORDER BY question_id ASC", "id={$avaliacao_id}");
                if (!$Read->getResult()):
                    echo '<div class="trigger trigger_info trigger_none al_center icon-info">Ainda não existem questões cadastradas para a prova ' . $avaliacao_title . '!</div>';
                    echo '<div class="clear"></div>';
                else:
                    foreach ($Read->getResult() as $evals):
                        $FormData = array_map('htmlspecialchars', $evals);
                        extract($FormData);
                        ?><article class="course_gerent_evaluates box box25" id="<?= $question_id; ?>">
                            <div class="box_content">
                                <h1 class="row_title">
                                    <?= str_pad($question_id, 2, 0, 0); ?>º - <?= $question_title; ?>
                                </h1><p class="actions">
                                    <?= $question_material && file_exists("../uploads/{$question_material}") && !is_dir("../uploads/{$question_material}") ? "<a class='btn btn_yellow icon-download icon-notext' href='" . BASE . "/uploads/{$question_material}' title=''></a>" : '' ?>
                                    <a href="dashboard.php?wc=fullead/questionedit&prov=<?= $avaliacao_id; ?>&perg=<?= $question_id; ?>" title="Editar Questão" class="btn btn_blue icon-pencil2 icon-notext"></a>
                                    <span rel='course_gerent_evaluates' class='j_delete_action icon-cancel-circle icon-notext btn btn_red' id='<?= $question_id; ?>'></span>
                                    <span rel='course_gerent_evaluates' callback='AvFullead' callback_action='question_delete' class='j_delete_action_confirm icon-warning icon-notext btn btn_yellow' style='display: none' id='<?= $question_id; ?>'></span>
                                </p>
                            </div>
                        </article><?php
                    endforeach;
                endif;
                ?>
            </section>
        </article><!--article list-->

        <div class="box box100" style="margin: 0; padding: 0 5px;">
            <div class="box_content">
                <form name="class_add" action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="callback" value="AvFullead"/>
                    <input type="hidden" name="callback_action" value="question_add"/>
                    <input type="hidden" name="avaliacao_id" value="<?= $avaliacao_id; ?>"/>

                    <label class="label">
                        <span class="legend">Assunto da questão:</span>
                        <input style="font-size: 1.2em;" type="text" name="question_title" value="" placeholder="Título da Questão:" required/>
                    </label>

                    <label class="label">
                        <span class="legend">Atividade (Descreva a atividade a ser realizada):</span>
                        <textarea class="work_mce_basic" style="font-size: 1.3em;" name="question_text" rows="5"></textarea>
                    </label>

                    <label class="label">
                        <span class="legend">Material de apoio (1 arquivo ZIP):</span>
                        <input type="file" name="question_material"/>
                    </label>

                    <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 6px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                    <button style="padding: 10px;" class="btn btn_green icon-plus fl_right">CADASTRAR ATIVIDADE!</button>
                    <div class="clear"></div>
                </form>
            </div>
        </div><!--formulario-->
        <?php
    endif;
    if ($avaliacao_type == 3):
        ?>
        <article class="box box100" style="margin: 0; padding: 0;">
            <section class="course_gerent_evaluateses j_content">
                <?php
                $Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE avaliacao_id = :id ORDER BY question_id ASC", "id={$avaliacao_id}");
                if (!$Read->getResult()):
                    echo '<div class="trigger trigger_info trigger_none al_center icon-info">Ainda não existe fórum cadastradas para a prova ' . $avaliacao_title . '!</div>';
                    echo '<div class="clear"></div>';
                else:
                    foreach ($Read->getResult() as $evals):
                        $FormData = array_map('htmlspecialchars', $evals);
                        extract($FormData);
                        ?><article class="course_gerent_evaluates box box25" id="<?= $question_id; ?>">
                            <div class="box_content">
                                <h1 class="row_title">
                                    <?= str_pad($question_id, 2, 0, 0); ?>º - <?= $question_title; ?>
                                </h1><p class="actions">
                                    <?= $question_material && file_exists("../uploads/{$question_material}") && !is_dir("../uploads/{$question_material}") ? "<a class='btn btn_yellow icon-download icon-notext' href='" . BASE . "/uploads/{$question_material}' title=''></a>" : '' ?>
                                    <a href="dashboard.php?wc=fullead/questionedit&prov=<?= $avaliacao_id; ?>&perg=<?= $question_id; ?>" title="Editar Questão" class="btn btn_blue icon-pencil2 icon-notext"></a>
                                    <span rel='course_gerent_evaluates' class='j_delete_action icon-cancel-circle icon-notext btn btn_red' id='<?= $question_id; ?>'></span>
                                    <span rel='course_gerent_evaluates' callback='AvFullead' callback_action='question_delete' class='j_delete_action_confirm icon-warning icon-notext btn btn_yellow' style='display: none' id='<?= $question_id; ?>'></span>
                                </p>
                            </div>
                        </article><?php
                    endforeach;
                endif;
                ?>
            </section>
        </article><!--article list-->

        <div class="box box100" style="margin: 0; padding: 0 5px;">
            <div class="box_content">
                <form name="class_add" action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="callback" value="AvFullead"/>
                    <input type="hidden" name="callback_action" value="question_add"/>
                    <input type="hidden" name="avaliacao_id" value="<?= $avaliacao_id; ?>"/>

                    <label class="label">
                        <span class="legend">Assunto do Fórum:</span>
                        <input style="font-size: 1.2em;" type="text" name="question_title" value="" placeholder="Título da Questão:" required/>
                    </label>

                    <label class="label">
                        <span class="legend">Atividade (Descreva a atividade a ser realizada): TINY NÃO ESTÁ DEIXANDO O FORM SER ENVIADO</span>
                        <textarea class="work_mce_basic" style="font-size: 1.3em;" name="question_text" rows="5"></textarea>
                    </label>

                    <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 6px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                    <button style="padding: 10px;" class="btn btn_green icon-plus fl_right">CADASTRAR ATIVIDADE!</button>
                    <div class="clear"></div>
                </form>
            </div>
        </div><!--formulario-->
        <?php
    endif;
    ?>
</div><!--content principal-->