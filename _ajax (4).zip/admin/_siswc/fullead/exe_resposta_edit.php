<?php
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
$AdminLevel = LEVEL_WC_EAD_COURSES;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

$Read = new Read;
$Create = new Create;

$QuestionId = filter_input(INPUT_GET, 'perg', FILTER_VALIDATE_INT);
if ($QuestionId):
    $Read->ExeRead(DB_EAD_AVALIACAO_PERGUNTAS, "WHERE perg_id = :id", "id={$QuestionId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar opções a uma questão não existente!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=evaluates/home');
    endif;
else:
    $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar opções a uma questão não existente", E_USER_NOTICE);
    header('Location: dashboard.php?wc=evaluates/home');
endif;
$AvId = filter_input(INPUT_GET, 'prov', FILTER_VALIDATE_INT);
$ClassId = filter_input(INPUT_GET, 'class', FILTER_VALIDATE_INT);

if (!$AvId):
    $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar opções a uma prova não existente!", E_USER_NOTICE);
    header('Location: dashboard.php?wc=teach/courses');
else:
    $Read->FullRead("SELECT * FROM " . DB_EAD_EXE . " WHERE exe_id = :prov AND class_id = :class", "prov={$AvId}&class={$ClassId}");
   if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
	
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou adicionar opções a uma prova não existente!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=teach/courses');
    endif;
endif;
?>
<header class="dashboard_header">
    <div class="dashboard_header_title">
 <h1 class="icon-profile">Gerenciar Provas</h1>
    </div>
 <div class="dashboard_header_search" id="<?= $ModId; ?>">
        <a title="Voltar ao Curso!" href="dashboard.php?wc=teach/courses" class="wc_view btn btn_green icon-lab icon-notext"></a>
        </div>

</header>
 <!-- INSIRA AQUI O SEU panel_header -->
    <div class="panel">
                <div class="box box100 ">
				<div class="box box100">
				
						<!-- INSIRA AQUI O SEU panel_header -->
						<div style="border: solid 3px #00b594;font-size:1.1em;" class="panel">
							<p><b>OBS: Clicando em :</b></p>
							<a class="btn btn_green icon-plus icon-notext"></a>  Você estará cadastrando automaticamente a resposta errada.</p>
							<a class="btn btn_light  icon-checkmark icon-notext"></a>  Marque essa opção Para informar qual é a resposta correta.</p>
						</div>
						
					</div><div class="box box50">
				<!--painel-->
				<div class="panel_header success">
				
					<span>
						<a href="javascript:void(0)" class="btn icon-notext icon-link"></a>
					</span>
					<h2 class="icon-arrow-up">Cadastre uma opção!</h2>
				</div>
				<div class="clear"></div>
				<form name="class_add" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="AvFullead"/>
                <input type="hidden" name="callback_action" value="exe_op_create"/>
                <input type="hidden" name="perg_id" value="<?= $perg_id; ?>"/>
				 <input type="hidden" name="exe_id" value="<?= $AvId; ?>"/>
				  <input type="hidden" name="class_id" value="<?= $ClassId; ?>"/>
				
				<label class="label">
                    <br/>
                    <input style="font-size: 1.2em;" type="text" name="op_content" value="" placeholder="Título da Opção:" required/>
                </label>
				   <div class="wc_actions" style="text-align: right">
                    <label class="label_check label_publish" style="padding: 11px; margin-right: 10px; font-weight: 500;"><input style="margin-top: -1px;" type="checkbox" value="1" name="op_sit"><i class="icon-checkmark icon-notext"></i></label>
                    <img class="form_load fl_right none icon-notext" style="margin-left: 10px; margin-top: 6px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                    <button style="padding: 10px;" class="btn btn_green icon-plus icon-notext fl_right"></button>
				</div>
                <div class="clear"></div>
            </form>
                
			</div><div class="box box50">
				
			
				<!--painel-->
				<div class="panel_header info">
				
					<span>
						<a href="javascript:void(0)" class="btn icon-notext icon-link"></a>
					</span>
					<h2 class="icon-arrow-up">Perguntas</h2>
				</div><br/><h1>Pergunta:</h1><h2> <b style="color:#ccc"><?= $perg_title;?></b></h2><br/>
				<?php
            $Read->ExeRead(DB_EAD_AVALIACAO_RESPOSTAS, "WHERE perg_id = :id ORDER BY perg_id ASC", "id={$QuestionId}");
            if (!$Read->getResult()):
                echo '<div class="trigger trigger_info trigger_none al_center icon-info">Ainda não existem opções cadastradas para a questão ' . $perg_title . '!</div>';
                echo '<div class="clear"></div>';
            else:
                foreach ($Read->getResult() as $avalia):
                    extract($avalia);
                    $OK = ($op_sit == 1 ? 'CORRETA' : ' ERRADA ');
                    $StatusOk = ($op_sit == 1 ? " btn_green" : " btn_red");?>
				     <div class="course_gerent_module">
					  <article class="mdp_avaliacao" id="<?= $op_id; ?>"
                            <h1 class="row_title">
                              Resposta: <b><?= $op_content; ?></b>
                            </h1><p class="row"><b>Avaliação:</b> <?= $exe_title;?>:</b></p>
							<p class="actions">
							<span class="btn <?= $StatusOk;?>"><?= $OK; ?></span>
                                <a href="dashboard.php?wc=fullead/exe_respostadit&class=<?= $ClassId; ?>&perg=<?= $perg_id; ?>&op=<?= $op_id;?>" title="Editar Opção" class="btn btn_blue icon-pencil2 icon-notext"></a>
                                <span rel='mdp_avaliacao' class='j_delete_action icon-cancel-circle icon-notext btn btn_red' id='<?= $op_id; ?>'></span>
                                <span rel='mdp_avaliacao' callback='AvFullead' callback_action='exe_op_delete' class='j_delete_action_confirm icon-warning icon-notext btn btn_yellow' style='display: none' id='<?= $op_id; ?>'></span>
                               </p>
							
                        </article>
					</div>
		<?php
                endforeach;
            endif;
            ?>
				</div>
			</div>	
	</div>
</div>