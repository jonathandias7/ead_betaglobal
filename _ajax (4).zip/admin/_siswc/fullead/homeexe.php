<?php
//!APP_EAD || !EAD_STUDENT_EVALUATES || 
$AdminLevel = LEVEL_WC_EAD_COURSES;
if (empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;
$CourseId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$MId = filter_input(INPUT_GET, 'module', FILTER_VALIDATE_INT);
$class = filter_input(INPUT_GET, 'class', FILTER_VALIDATE_INT);
$Read = new Read;
?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-profile">EXERCICIOS</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            Gerenciar Exercicios
        </p>
    </div>

    <div class="dashboard_header_search">
		
		 <form class="auto_save" name="filtra_lista" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="FilterFullead"/>
                <input type="hidden" name="callback_action" value="filtra_lista"/>
				<input type="hidden" name="course_id" value="<?= $CourseId?>">
				<input type="hidden" name="module_id" value="<?= $MId?>">
				<input type="hidden" name="class_id" value="<?= $class?>">
				
					<label class="label auto_save">
						<span class="legend">FILTRO DE AVALIAÇÃO</span>
						<select class="bg_green" style="color:#fff; font-size: 1.4em; border: solid 3px #ccc;" name="exe_type">
						<option style="background:#fff;color:#1584f6;  border: solid 3px #1584f6;" value="1" selected="selected">Somente de Marcar</option>
						<option  style="background:#fff;color:#1584f6; border: solid 3px #1584f6;" value="2" selected="selected">Somente de Texto</option>
						<option value="" type="hidden" selected="selected" disabled="disabled">Todas(Padrão)</option>
						</select>
					</label>
					
				</form>
<div class="j_content">
<H2 style="color: #00b594; text-align: left;text-shadow: 1px 1px 1px #000" class="tipo"> LISTAGEM PADRÃO<?$result = "<p style='font-size:0;' class='result'>0</p>";?></h2></div>

		
	
	</div>
</header>

<div class="dashboard_content">
    <section class="box box100">
        <article class="box box100 course_list">
            <header class="header_green">
                <h1 class="icon-file-text2">Provas:</h1>
                <div class="clear"></div>
            </header>
            <div class="box_content">
                <?php
                $Read->FullRead("SELECT * FROM ".DB_EAD_EXE." WHERE module_id = {$MId}");

                if (!$Read->getResult()):
                    echo "<div class='trigger al_center trigger_info trigger_none font_medium'>Ainda não existem provas cadastradas. Acesse os módulos dos cursos para cadastrar as provas!</div>";
                else:
                    foreach ($Read->getResult() as $avaliacao):
                        extract($avaliacao);
                        
                        $Read->FullRead("SELECT module_id, module_title FROM " . DB_EAD_MODULES . " WHERE module_id = :id", "id={$module_id}");
                        if($Read->getResult()):
                            extract($Read->getResult()[0]);
                        endif;
                      
                        
                    //  if($result != '3' || $result != 0)://valida o filtro
					  
					 // if($exe_title != null):
					 ?>
					 <div class="callback_return"></div>
                            <article class="course_gerent_module course_list" id="<?= $exe_id; ?>">
                            <h1 class="row_title icon-profile">
                                <?= $exe_title; ?>
                            </h1><p class="row">
							<?
							$tipo = ($exe_type == 1 ? 'MARCAÇÃO' : 'TEXTO');
							$typeColor = ($exe_type == 1 ? 'bg_green' : 'bg_blue');
							?>
                                <span>Módulo: <?= $module_title; ?></span><span class="<?= $typeColor?>" style="color:#fff; text-align:center; font-size:1em; width:100px;"><b> <?= $tipo;?></b></span>
                            </p><p class="row">
                                <a title="Editar essa Avaliação" href="dashboard.php?wc=fullead/createexe&id=<?= $CourseId; ?>&module=<?= $module_id; ?>&class=<?= $exe_id; ?>" class="btn btn_yellow icon-pencil2 icon-notext"></a>
								<a title="Criar perguntas Avaliação" href="dashboard.php?wc=fullead/exe_perguntas&module=<?= $module_id; ?>&prov=<?= $exe_id; ?>&class=<?= $class_id; ?>" class="btn btn_green icon-profile icon-notext"></a>
								<a rel="course_list" class="j_delete_action icon-cancel-circle btn btn_red icon-notext" id="<?= $exe_id; ?>"></a>
								<a rel="course_list" callback='FilterFullead' callback_action="filter_delete" class="j_delete_action_confirm icon-warning btn btn_yellow" style="display: none ;margin-top: 30px;" id="<?= $exe_id; ?>">Deletar Avaliação?</a>
                </p>
                        </article>
                        <?php
						// else:
						//echo $result;
						//endif; 
					//endif;
                    endforeach;
                endif;
                ?>
                <div class="clear"></div>
            </div>
        </article>
		<div class="box box50">
				
						<!-- INSIRA AQUI O SEU panel_header -->
						<div style="border: solid 3px #00b594;font-size:1em;" class="panel">
							<p><a class="btn btn_green icon-profile icon-notext"></a>  </p>
							Você Será direcionado para formular as perguntas da avaliação selecionada.
							Também poderá visualizar ou editar as perguntas criadas para a avaliação selecionada.</p>
						</div>
						
					</div>
					<div class="box box50">
				
						<!-- INSIRA AQUI O SEU panel_header -->
						<div style="border: solid 3px orange;font-size:1em;" class="panel">
							<p><a class="btn btn_yellow icon-pencil2 icon-notext"></a></p>
							  Você será direcionado a página de edição da avaliação.
							  Aqui poderá alterar todos os aspectos necessários para seu projeto.</p><br/>
						</div>
						
					</div>
    </section>
</div>

