<?php
$AdminLevel = 6;
if (!APP_EAD || empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;


//Usuario
$getUserId = Check::UserId($Admin['user_id']);
// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;
$avaliacao_status = 0;
		$avaliacao_type = 0;
		$avaliacao_necessaria = 0;
		

?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-pagebreak">Avaliação</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
           Avaliação
        </p>
    </div>

    <div class="dashboard_header_search">
        <a title="Nova Página" href="dashboard.php?wc=pages/create" class="btn btn_green icon-plus">Voltar</a>
        <span class="btn btn_green icon-spinner9 wc_drag_active" title="Organizar Cursos">Ordenar</span>
    </div>

</header>


<div class="dashboard_content">

    <div class="box box100">

        <div class="panel_header default">
            <h2 class="icon-tree">Dados sobre o módulo</h2>
        </div>
 
        <div class="panel">
           <form class="" name="avaliacao_create" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="AvFullead"/>
                <input type="hidden" name="callback_action" value="avaliacao_create"/>
				<input type="hidden" name="avaliacao_date" value="<?= $Date = date('Y-m-d H:i:s');?>">;
				<input type="hidden" name="avaliacao_type" value="1">;
                
            
				<div class="label_50">
							<label class="label">
								<span class="legend">Author</span>
								<input class="bg_green" style="font-size: 1.4em;color:#fff;border:solid 3px #ccc;" disabled="disabled" value="<?= $getUserId['user_name'].$getUserId['user_lastname'];?>">
							</label>
							<label class="label">
								<span class="legend">Curso</span>
								<select class="bg_green" name="course_id" style="font-size: 1.4em;color:#fff;border:solid 3px #ccc;"  required="required">
									<?php
									 $Read->FullRead("SELECT course_id, course_title FROM ws_ead_courses");
									if ($Read->getResult()):
									foreach ($Read->getResult() as $Course):
                                    echo "<option ";
                                    if ($Course['course_id'] == $Course):
                                        echo " selected='selected'";
                                    endif;
									echo " value='{$Course['course_id']}'>{$Course['course_title']}</option>";
                                endforeach;
                            endif;?>
									</select>
							</label><div class="clear"></div>
							</div><div class="label_50">
							<? $Read->FullRead("SELECT avaliacao_title FROM mdp_avaliacao");extract($Read->getResult()[0]);?>
							 <label class="label">
								<span class="legend">Identificação:</span>
								<input style="font-size: 1.5em;" type="text" name="avaliacao_title" value="" placeholder="Título da prova:" required/>
							</label>
							<label class="label">
								<span class="legend">Modulo</span>
								<select name="module_id" required="required">
									<?php
									 $Read->FullRead("SELECT module_id,module_title, course_id FROM ws_ead_modules");
									if ($Read->getResult()):
									foreach ($Read->getResult() as $Module):
                                    echo "<option";
                                    if ($Module['module_id'] == $Module):
                                        echo " selected='selected'";
                                    endif;
									echo " value='{$Module['module_id']}'>{$Module['module_title']}</option>";
                                endforeach;
                            endif;?>
									</select>
							</label>
							<div class="clear"></div>
							
				
						</div>
				

               
                <div class="label_50">
							<label class="label">
								<span class="legend">Status da Avaliação <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Caso desativa, a prova será criada mas não exibida e nem necessária no campus</span></span></span>
								<select name="avaliacao_status" required="required">
								<option value="0" selected="selected" >Desativado para Aluno</option>
								<option value="1" selected="selected" >Ativado para Aluno</option>
							
								</select>
							</label>
							

							

                 

                    <label class="label">
                        <span class="legend">Quantidade de questões:</span>
                        <select name="avaliacao_qtd">
						<option value="0" selected="selected">Selecione uma opção</option>
                            <option value="5"   selected="selected">5 Questões</option>
                            <option value="10"  selected="selected">10 Questões</option>
							<option value="15"  selected="selected">15 Questões</option>
                            <option value="20"   selected="selected">20 Questões</option>
							<option value="25"   selected="selected">25 Questões</option>
                            <option value="30"   selected="selected">30 Questões</option>
							<option value="40"   selected="selected">40 Questões</option>
                            <option value="50"   selected="selected">50 Questões</option>
							<option value="60"   selected="selected">60 Questões</option>
                            <option value="100"  selected="selected">100 Questões</option>
							<option value="150"  selected="selected">150 Questões</option>
							<option value="200"  selected="selected">200 Questões</option>
                        </select>
                    </label>
                </div>
				<div class="label_33">
                    <label class="label">
                        <span class="legend">Valor: <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Valor referente ao total de pontos para Essa avaliação.</span></span></span>
                        <input style="font-size: 1.2em;" type="number" name="avaliacao_result" value="<?= (isset($avaliacao_result) ? $avaliacao_result : '10'); ?>" placeholder="Quanto vale essa prova(1 a 10)?" required/>
                    </label>

                    <label class="label">
                        <span class="legend">Média: <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Nota que O aluno deve tirar para aprovação.</span></span></span>
                        <input style="font-size: 1.2em;" type="number" name="avaliacao_aprovado" value="<?= (isset($avaliacao_aprovado) ? $avaliacao_aprovado : '6'); ?>" placeholder=" Nota para aprovação 1 = 10%(Padrão 6)?:" required/>
                    </label>
					<label class="label">
                        <span class="legend">Duração: <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Defina o tempo de duração em minutos:</span></span></span>
                        <input style="font-size: 1em;" type="number" name="avaliacao_time" value="<?= (isset($avaliacao_time) ? $avaliacao_time : '60'); ?>" placeholder="Tempo para realizar a prova:" required/>
                    </label>
				
					</div>
				<div>
				<h3 class="icon-tree">Opcionais da Avaliação:</h3><br/>
				</div>
				<div class="label_50">
						<label class="label">
								<span class="legend">Situação <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Caso desativada, mesmo o aluno não conseguindo a pontuação,poderá realizar novamente a prova.</span></span></span>
								<select style="font-size: 1em;" name="avaliacao_refazer_status" required="required">
								<option value="0" selected="selected" >Desativado para Aluno</option>
								<option value="1" selected="selected" >Ativado para Aluno</option>
							
								</select>
							</label>
					
                    <label class="label">
                        <span class="legend">Liberação:<span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Data para o aluno poder refazer a avaliação caso seja reprovado.</span></span></span>
                        <input style="font-size: 1em;"  type="text" name="avaliacao_refazer_date" placeholder="digite 0 para liberação imediata">
                    </label>	
                </div>
				
                <div class="m_top">&nbsp;</div>
					
              

				
                <div class="m_top">&nbsp;</div>
                <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                <button class="btn btn_green icon-price-tags fl_right">Finalizar</button>
				
                <div class="clear"></div>
            </form>
        </div>
    </div>
</div>