/*
Navicat MariaDB Data Transfer

Source Server         : localhost
Source Server Version : 100128
Source Host           : localhost:3306
Source Database       : charme_fitness

Target Server Type    : MariaDB
Target Server Version : 100128
File Encoding         : 65001

Date: 2018-02-01 16:21:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ws_products_stock
-- ----------------------------
DROP TABLE IF EXISTS `ws_products_stock`;
CREATE TABLE `ws_products_stock` (
  `stock_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pdt_id` int(11) unsigned NOT NULL,
  `stock_code` varchar(255) NOT NULL DEFAULT '',
  `stock_code_title` varchar(255) NOT NULL,
  `stock_color` varchar(255) NOT NULL,
  `stock_color_title` varchar(255) NOT NULL,
  `stock_inventory` decimal(10,0) NOT NULL DEFAULT '0',
  `stock_sold` decimal(10,0) NOT NULL DEFAULT '0',
  PRIMARY KEY (`stock_id`),
  KEY `wc_products_stock` (`pdt_id`),
  CONSTRAINT `wc_products_stock` FOREIGN KEY (`pdt_id`) REFERENCES `ws_products` (`pdt_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ws_products_stock
-- ----------------------------
INSERT INTO `ws_products_stock` VALUES ('1', '1', 'P', 'P', '#f62638', 'Vermelho', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('2', '1', 'M', 'M', '#f62638', 'Vermelho', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('3', '1', 'G', 'G', '#f62638', 'Vermelho', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('4', '1', 'GG', 'GG', '#f62638', 'Vermelho', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('5', '2', 'P', 'P', '#008a72', 'Verde', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('6', '2', 'M', 'M', '#008a72', 'Verde', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('7', '2', 'G', 'G', '#008a72', 'Verde', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('8', '2', 'GG', 'GG', '#008a72', 'Verde', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('9', '3', 'P', 'P', '#02dc6e', 'Limão', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('10', '3', 'M', 'M', '#02dc6e', 'Limão', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('11', '3', 'G', 'G', '#02dc6e', 'Limão', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('12', '3', 'GG', 'GG', '#02dc6e', 'Limão', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('13', '4', 'P', 'P', '#2e68d4', 'Azul', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('14', '4', 'M', 'M', '#2e68d4', 'Azul', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('15', '4', 'G', 'G', '#2e68d4', 'Azul', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('16', '4', 'GG', 'GG', '#2e68d4', 'Azul', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('17', '5', 'P', 'P', '#fd2d93', 'Rosa', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('18', '5', 'M', 'M', '#fd2d93', 'Rosa', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('19', '5', 'G', 'G', '#fd2d93', 'Rosa', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('20', '5', 'GG', 'GG', '#fd2d93', 'Rosa', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('21', '6', 'P', 'P', '#e94757', 'Coral', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('22', '6', 'M', 'M', '#e94757', 'Coral', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('23', '6', 'G', 'G', '#e94757', 'Coral', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('24', '6', 'GG', 'GG', '#e94757', 'Coral', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('25', '7', 'P', 'P', '#ffffff', 'Branco', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('26', '7', 'M', 'M', '#ffffff', 'Branco', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('27', '7', 'G', 'G', '#ffffff', 'Branco', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('28', '7', 'GG', 'GG', '#ffffff', 'Branco', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('29', '8', 'P', 'P', '#735f6d', 'Cinza', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('30', '8', 'M', 'M', '#735f6d', 'Cinza', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('31', '8', 'G', 'G', '#735f6d', 'Cinza', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('32', '8', 'GG', 'GG', '#735f6d', 'Cinza', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('33', '9', 'P', 'P', '#000000', 'Preto', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('34', '9', 'M', 'M', '#000000', 'Preto', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('35', '9', 'G', 'G', '#000000', 'Preto', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('36', '9', 'GG', 'GG', '#000000', 'Preto', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('37', '10', 'P', 'P', '#000000', 'Preto', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('38', '10', 'M', 'M', '#000000', 'Preto', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('39', '10', 'G', 'G', '#000000', 'Preto', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('40', '10', 'GG', 'GG', '#000000', 'Preto', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('41', '11', 'P', 'P', '#735f6d', 'Cinza', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('42', '11', 'M', 'M', '#735f6d', 'Cinza', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('43', '11', 'G', 'G', '#735f6d', 'Cinza', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('44', '11', 'GG', 'GG', '#735f6d', 'Cinza', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('45', '12', 'P', 'P', '#fd2d93', 'Rosa', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('46', '12', 'M', 'M', '#fd2d93', 'Rosa', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('47', '12', 'G', 'G', '#fd2d93', 'Rosa', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('48', '12', 'GG', 'GG', '#fd2d93', 'Rosa', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('49', '13', 'P', 'P', '#ffffff', 'Branco', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('50', '13', 'M', 'M', '#ffffff', 'Branco', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('51', '13', 'G', 'G', '#ffffff', 'Branco', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('52', '13', 'GG', 'GG', '#ffffff', 'Branco', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('53', '14', 'P', 'P', '#008a72', 'Verde', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('54', '14', 'M', 'M', '#008a72', 'Verde', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('55', '14', 'G', 'G', '#008a72', 'Verde', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('56', '14', 'GG', 'GG', '#008a72', 'Verde', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('57', '15', 'P', 'P', '#979caa', 'Bege', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('58', '15', 'M', 'M', '#979caa', 'Bege', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('59', '15', 'G', 'G', '#979caa', 'Bege', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('60', '15', 'GG', 'GG', '#979caa', 'Bege', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('61', '16', 'P', 'P', '#f62638', 'Vermelho', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('62', '16', 'M', 'M', '#f62638', 'Vermelho', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('63', '16', 'G', 'G', '#f62638', 'Vermelho', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('64', '16', 'GG', 'GG', '#f62638', 'Vermelho', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('117', '17', 'P', 'P', '#2e68d4', 'Azul', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('125', '17', 'M', 'M', '#2e68d4', 'Azul', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('126', '17', 'G', 'G', '#2e68d4', 'Azul', '25', '0');
INSERT INTO `ws_products_stock` VALUES ('127', '17', 'GG', 'GG', '#2e68d4', 'Azul', '25', '0');
