/*
Navicat MariaDB Data Transfer

Source Server         : localhost
Source Server Version : 100128
Source Host           : localhost:3306
Source Database       : charme_fitness

Target Server Type    : MariaDB
Target Server Version : 100128
File Encoding         : 65001

Date: 2018-02-01 16:21:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ws_products_groups_attributes
-- ----------------------------
DROP TABLE IF EXISTS `ws_products_groups_attributes`;
CREATE TABLE `ws_products_groups_attributes` (
  `group_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_type` varchar(255) DEFAULT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  `group_title` varchar(255) DEFAULT NULL,
  `group_order` int(11) DEFAULT NULL,
  `group_created` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ws_products_groups_attributes
-- ----------------------------
INSERT INTO `ws_products_groups_attributes` VALUES ('1', 'size', 'tamanhos-roupas', 'Tamanhos :: Roupas', '1', '2017-10-17 02:17:01');
INSERT INTO `ws_products_groups_attributes` VALUES ('2', 'color', 'cores-roupas', 'Cores :: Roupas', '2', '2017-10-17 02:17:29');
