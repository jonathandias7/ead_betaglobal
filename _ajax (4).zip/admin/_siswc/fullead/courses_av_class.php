<?php
$AdminLevel = LEVEL_WC_EAD_COURSES;
if (!APP_EAD || empty($DashboardLogin) || empty($Admin) || $Admin['user_level'] < $AdminLevel):
    die('<div style="text-align: center; margin: 5% 0; color: #C54550; font-size: 1.6em; font-weight: 400; background: #fff; float: left; width: 100%; padding: 30px 0;"><b>ACESSO NEGADO:</b> Você não esta logado<br>ou não tem permissão para acessar essa página!</div>');
endif;

// AUTO INSTANCE OBJECT READ
if (empty($Read)):
    $Read = new Read;
endif;

// AUTO INSTANCE OBJECT CREATE
if (empty($Create)):
    $Create = new Create;
endif;

//Usuario
$getUserId = Check::UserId($Admin['user_id']);
$CourseId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$ModId = filter_input(INPUT_GET, 'module', FILTER_VALIDATE_INT);
if (!$ModId):
    $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou editar uma prova sem informar o módulo a que ela pertence!", E_USER_NOTICE);
    header('Location: dashboard.php?wc=teach/courses');
else:
    $Read->FullRead("SELECT module_id, course_id, module_title FROM " . DB_EAD_MODULES . " WHERE module_id = :id", "id={$ModId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou editar uma prova sem informar o módulo a que ela pertence!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=teach/courses');
    endif;
endif;

$getProvaId = filter_input(INPUT_GET, 'prov', FILTER_VALIDATE_INT);
if ($getProvaId):
    $Read->ExeRead(DB_EAD_AVALIACAO, "WHERE avaliacao_id = :id", "id={$getProvaId}");
    if ($Read->getResult()):
        extract($Read->getResult()[0]);
    else:
        $_SESSION['trigger_controll'] = Erro("<b>OPPSS {$Admin['user_name']}</b>, você tentou editar uma prova de um que não existe ou que foi removido recentemente!", E_USER_NOTICE);
        header('Location: dashboard.php?wc=teach/courses_gerente&id=' . $ModId);
    endif;
else:
    $Date = date('Y-m-d H:i:s');
    $FulleadCreate = ['module_id' => $ModId, 'avaliacao_date' => $Date];
    $Create->ExeCreate(DB_EAD_AVALIACAO, $FulleadCreate);
    header('Location: dashboard.php?wc=fullead/courses_av_modules&id='. $CourseId .'&module=' . $ModId . '&prov=' . $Create->getResult());
endif;

?>

<header class="dashboard_header">
    <div class="dashboard_header_title">
        <h1 class="icon-profile">Gerenciar Provas</h1>
        <p class="dashboard_header_breadcrumbs">
            &raquo; <?= ADMIN_NAME; ?>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=home">Dashboard</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=teach/courses">Cursos</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=teach/courses_gerent&id=<?= $course_id; ?>">Modulos</a>
            <span class="crumb">/</span>
            <a title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=fullead/home&id=<?= $course_id; ?>&module=<?= $ModId; ?>">Avaliações</a>
            
			<span class="crumb">/</span>
            Gerenciar Avaliações
        </p>
    </div>

    <div class="dashboard_header_search" id="<?= $ModId; ?>">
        <a title="Voltar ao Curso!" href="dashboard.php?wc=teach/courses_gerent&id=<?= $CourseId; ?>" class="wc_view btn btn_green icon-lab icon-notext"></a>
        <a class="btn btn_yellow icon-list icon-notext" href="dashboard.php?wc=fullead/home&id=<?= $course_id; ?>&module=<?= $ModId; ?>" title="Listar Aulas Desse Modulo"></a>
		 <a class="btn btn_blue icon-list" title="<?= ADMIN_NAME; ?>" href="dashboard.php?wc=teach/courses_gerent&id=<?= $course_id; ?>&module=<?= $ModId; ?>">Modulos do Curso</a>
        </div>

</header>

<div class="dashboard_content">

    <div class="box box100">

        <div class="panel_header default">
            <h2 class="icon-tree">Dados sobre o módulo</h2>
        </div>

        <div class="panel">
            <form  name="avaliacao_add" action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="callback" value="AvFullead"/>
                <input type="hidden" name="callback_action" value="avaliacao_manage"/>
				 <input type="hidden" name="course_id" value="<?= $CourseId; ?>"/>
				 <input type="hidden" name="module_id" value="<?= $ModId ?>"/>
                <input type="hidden" name="avaliacao_id" value="<?= $getProvaId; ?>"/>
            
				<div class="label_50">
							<label class="label">
								<span class="legend">Author</span>
								<input class="bg_green" style="font-size: 1.4em;color:#fff;border:solid 3px #ccc;" disabled="disabled" value="<?= $getUserId['user_name'].$getUserId['user_lastname'];?>">
							</label>
						
								<input  type="hidden" name="course_id" value="<? $ModId; ?>" required="required">
									
						
							
							 <label class="label">
								<span class="legend">Identificação:</span>
								<input style="font-size: 1.5em;" type="text" name="avaliacao_title" value="<?= $avaliacao_title; ?>" placeholder="Título da prova:" required/>
							</label>
							<label class="label">
								
								
								<input  type="hidden" name="module_id" value="<?= $ModId;?>" required="required">
									
                           
							</label>
							<div class="clear"></div>
							
				
						</div>
				
		<div>
            <h3 class="icon-tree">Parâmetros da Avaliação:</h3>
        </div>
               <div class="box box50">
                <div class="label_33">
				
							

					<label class="label">
                        <span class="legend">Valor: <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Valor referente ao total de pontos para Essa avaliação.</span></span></span>
                        <input style="font-size: 1em;" type="number" name="avaliacao_result" value="<?= (isset($avaliacao_result) ? $avaliacao_result : '10'); ?>" placeholder="Quanto vale essa prova(1 a 10)?" required/>
                    </label>

                    <label class="label">
                        <span class="legend">Média: <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Nota que O aluno deve tirar para aprovação.</span></span></span>
                        <input style="font-size: 1em;" type="number" name="avaliacao_aprovado" value="<?= (isset($avaliacao_aprovado) ? $avaliacao_aprovado : '6'); ?>" placeholder=" Nota para aprovação 1 = 10%(Padrão 6)?:" required/>
                    </label>		

                  <label class="label">
                        <span class="legend">Duração: <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Defina o tempo de duração em minutos:</span></span></span>
                        <input style="font-size: 1em;" type="number" name="avaliacao_time" value="<?= (isset($avaliacao_time) ? $avaliacao_time : '60'); ?>" placeholder="Tempo para realizar a prova:" required/>
                    </label>
					</div> 
					
				</div>
	
				  <div class="box box50">
				<div class="label_50">
				
                    
					<label class="label">
								<span class="legend">Status da Avaliação <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Caso desativa, a prova será criada mas não exibida e nem necessária no campus</span></span></span>
								<select style="font-size: 1em;" name="avaliacao_status" required="required">
								<option value="0" <?= (($avaliacao_qtd == 0) ? "selected='selected'" : ""); ?>>Desativado para Aluno</option>
								<option value="1" <?= (($avaliacao_qtd == 1) ? "selected='selected'" : ""); ?>>Ativado para Aluno</option>
							
								</select>
							</label>
					
						<input class="bg_green" type="hidden" style="font-size: 1.4em;color:#fff;border:solid 3px #ccc;" name="avaliacao_type"  value="1">
					
							<label class="label">
                        <span class="legend">Quantidade de questões:</span>
                        <select style="font-size: 1em;" name="avaliacao_qtd">
						<option value="0">Selecione uma opção</option>
                            <option value="5" <?= (($avaliacao_qtd == 5) ? "selected='selected'" : ""); ?>>5 Questões</option>
                            <option value="10" <?= (($avaliacao_qtd == 10) ? "selected='selected'" : ""); ?>>10 Questões</option>
							<option value="15" <?= (($avaliacao_qtd == 15) ? "selected='selected'" : ""); ?>>15 Questões</option>
                            <option value="20" <?= (($avaliacao_qtd == 20) ? "selected='selected'" : ""); ?>>20 Questões</option>
							<option value="25" <?= (($avaliacao_qtd == 25) ? "selected='selected'" : ""); ?>>25 Questões</option>
                            <option value="30" <?= (($avaliacao_qtd == 30) ? "selected='selected'" : ""); ?>>30 Questões</option>
							<option value="40" <?= (($avaliacao_qtd == 40) ? "selected='selected'" : ""); ?>>40 Questões</option>
                            <option value="50" <?= (($avaliacao_qtd == 50) ? "selected='selected'" : ""); ?>>50 Questões</option>
							<option value="60" <?= (($avaliacao_qtd == 60) ? "selected='selected'" : ""); ?>>60 Questões</option>
                            <option value="100" <?= (($avaliacao_qtd == 100) ? "selected='selected'" : ""); ?>>100 Questões</option>
							<option value="150" <?= (($avaliacao_qtd == 150) ? "selected='selected'" : ""); ?>>150 Questões</option>
							<option value="200" <?= (($avaliacao_qtd == 200) ? "selected='selected'" : ""); ?>>200 Questões</option>
                        </select>
                    </label>
                </div>
				</div>
				<div>
				<h3 class="icon-tree">Opcionais da Avaliação:</h3><br/>
				</div>
				<div class="label_50">
						<label class="label">
								<span class="legend">Situação <span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Caso desativada, mesmo o aluno não conseguindo a pontuação,poderá realizar novamente a prova.</span></span></span>
								<select style="font-size: 1em;" name="avaliacao_refazer_status" required="required">
								<option value="0" <?= (($avaliacao_refazer_status == 0) ? "selected='selected'" : ""); ?>>Desativado para Aluno</option>
								<option value="1" <?= (($avaliacao_refazer_status == 1) ? "selected='selected'" : ""); ?>>Ativado para Aluno</option>
							
								</select>
							</label>
					
                    <label class="label">
                        <span class="legend">Liberação:<span class="icon-info icon-notext wc_tooltip"><span class="wc_tooltip_balloon">Data para o aluno poder refazer a avaliação caso seja reprovado.</span></span></span>
                        <input style="font-size: 1em;"  type="text" name="avaliacao_refazer_date" placeholder=" 07">
                    </label>	
                </div>
				
                <div class="m_top">&nbsp;</div>
                <img class="form_load fl_right none" style="margin-left: 10px; margin-top: 2px;" alt="Enviando Requisição!" title="Enviando Requisição!" src="_img/load.gif"/>
                <button class="btn btn_green icon-price-tags fl_right">Finalizar</button>
				
                <div class="clear"></div>
            </form>
        </div>
    </div>
</div>