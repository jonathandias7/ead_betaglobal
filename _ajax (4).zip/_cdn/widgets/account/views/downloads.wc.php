<?php

	if(isset($_POST['newdown'])):
	    $Update = new Update();
	   $Read->ExeRead("mdp_user_downloads"," WHERE pdt_id = :id AND user_id = :u","id={$_POST['pdt_id']}&u={$user_id}");
          if($Read->getResult()):
              $mdpdown = $Read->getResult()[0];
                    $countdown =  $mdpdown['down_count']+1;
                $UpDown = [
                 'down_date' => date('Y-m-d H:i:s'),
                 'down_count' =>  $countdown
                 ];
                $Update->ExeUpdate('mdp_user_downloads',$UpDown," WHERE pdt_id = :id AND user_id = :u","id={$_POST['pdt_id']}&u={$user_id}");
               if($Update->getResult()):
                    $Read->ExeRead(DB_PDT," WHERE pdt_id = :id","id={$_POST['pdt_id']}");
                if($Read->getResult()):
                    extract($Read->getResult()[0]);
                 endif;
                     $Email = new Email();
                    require '_cdn/ass.email.php';
                     $ToCliente = "<div style='text-align:center;' class='content'><p style='margin-top:-40px;padding:0 0 40px 0' ><img style='max-height:100px; max-width:100px;' src='". INCLUDE_PATH ."/images/logo.png'></p><p style='font-size: 1.2em;'>Caro(a) <b>{$_SESSION['userLogin']['user_name']} {$_SESSION['userLogin']['user_lastname']}</b>,</p><p style='font-size: 1.2em;'>Você solicitou um download (<b>". strtolower($pdt_title)."</b>) em  nosso site para este endereço de email:<b>{$_SESSION['userLogin']['user_email']}</b>.Caso ainda não tenha efetuado o downloado, clique em Baixar no final do corpo deste email.<br/> <p>Para visualizar todos os seus projetos comprados ou ganhados, clicar em minhas compras:</p><p><a href='".  BASE ."/conta' style='font-size: 1.2em;text-decoration:none; background:#eee;padding:5px' class='btn btn_blue'>Minhas Compras</a></p>
                
                     <p style='padding:40px' ><hr><h3>{$pdt_title}</h3></p>
                     <p style='width:100%;height:100%;' ><img  src='". BASE ."/uploads/{$pdt_cover}'></p>
                         <p><a style='font-size: 1.5em;margin-top:20px;text-decoration:none; background:#00b594;color:#fff;padding:10px 15px'href='". $pdt_urldown ."'>BAIXAR</a></p>
                            <p><em>Atenciosamente,</em></p>
                        ";
                        $MailMensage = str_replace("#mail_body#", $ToCliente, $MailContent);
                        $Email->EnviarMontando("MDP LTDA - {$pdt_title} - Link de Download ", $MailMensage, SITE_NAME, MAIL_SENDER, $_SESSION['userLogin']['user_name'], $_SESSION['userLogin']['user_email']);
                   
                   Header("location:{$_POST['pdt_urldown']}");
                
                exit;
                endif;
            endif;
    endif;
if (empty($_SESSION['userLogin']) || !APP_PRODUCTS):
    die('<h1 style="padding: 50px 0; text-align: center; font-size: 3em; font-weight: 300; color: #C63D3A">Acesso Negado!</h1>');
endif;

echo "<div class='workcontrol_account_view'>";
echo "<p class='wc_account_title'><span>Meus Downloads:</span><p>";

$Page = (!empty($URL[2]) ? $URL[2] : 1);
$Pager = new Pager("{$AccountBaseUI}/downloads/", "<<", ">>", 2);
$Pager->ExePager($Page, 10);
$Read->ExeRead("mdp_user_downloads", "WHERE user_id = :id ORDER BY down_date DESC LIMIT :limit OFFSET :offset", "id={$user_id}&limit={$Pager->getLimit()}&offset={$Pager->getOffset()}");
if (!$Read->getResult()):
    $Pager->ReturnPage();
    Erro("<b>Você ainda não realizou nenhum download em nosso site!</b>");
else:
    $cor = 0;
    foreach ($Read->getResult() as $down):
        if($cor%2 != 0):
        $color = 'background:#fff;padding: 0 10px;border:1px solid #eee;';
        else:
            $color = 'background:#fbfbfb;padding: 0 10px;border:1px solid #eee;';
        endif;
      
        extract($down);
     
        echo "<div style='{$color}' class='wc_account_order cor'><p><b>". Check::Words($pdt_title,2)."</b></p><p>" . date('d/m/Y H\hi', strtotime($down_date)) . "</p><p><b>(". ($down_count < 10 ? '0'.$down_count : $down_count) .")</b> ". ($down_count = 1 ? 'Download' : 'Downloads') ." </p><p>". ($down_sendmail >= 1 ? '<a style="cursor:none" class="btn btn_green icon-mail">Email Enviado</a>': '<a class="btn btn_red icon-mail"> Email Pendente </a>') ."</p><p><form style='float:right;margin-top:-31px' name='newdown'  class='ajax_off' method='POST' enctype='multipart/form-data' action=''><input type='hidden' name='pdt_id' value='{$pdt_id}'><input type='hidden' name='pdt_urldown' value='{$pdt_urldown}'><button name='newdown' type='submit'  class='btn btn_green icon-mail'>Baixar</button></form></p></div>";
     $cor++;
    endforeach;
endif;

$Pager->ExePaginator("mdp_user_downloads", "WHERE user_id = :id", "id={$user_id}", "#acc");
echo $Pager->getPaginator("acc");
echo "</div>";
