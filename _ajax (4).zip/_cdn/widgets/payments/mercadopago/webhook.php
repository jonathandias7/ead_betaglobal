<?php
require '../../../../_app/Config.inc.php';
$get = filter_input_array(INPUT_GET, FILTER_DEFAULT);
$type = $get['type'];

if (!$get) {
    die('Acess denied');
} else {
    $mp = new MPCrud();
    $Read = new Read;
    $Update = new Update;
    $Email = new Email;
	
 	$pay_info = $mp->resourceGet("/v1/payments/{$get['data_id']}");    
    $response = $pay_info['response'];
	
    if($pay_info['status'] === 200) {
        switch($response["status"]):
            case "approved"     : $status = "Aprovado"; break;
            case "pending"      : $status = "Aguardando pagamento"; break;
            case "in_process"   : $status = "Processando pagamento"; break;
            case "rejected"     : $status = "Cancelado"; break;
            case "refunded"     : $status = "Devolvido"; break;
            case "cancelled"    : $status = "Cancelado"; break;
            case "in_mediation" : $status = "Disputa"; break;
        endswitch;

        switch($response['payment_type_id']):
            case 'ticket':
                $payment_type = 'Boleto bancário';
            break;
            default:
                $payment_type = 'Cartão de crédito';
            break;
        endswitch;

        try {
            $PaymentOrder = $response['id'];
            $PaymentStatus = $response["status"];

            $Read->ExeRead(DB_ORDERS, "WHERE order_code = :orid", "orid={$PaymentOrder}");
            if ($Read->getResult()) {
                extract($Read->getResult()[0]);

                $Read->ExeRead(DB_USERS, "WHERE user_id = :usr", "usr={$user_id}");
                $Client = $Read->getResult()[0];

                if ($PaymentStatus === 'pending') {
                    /*
                     * AGUARDANDO PAGAMENTO
                     */
                    $Read->ExeRead(DB_ORDERS_ITEMS, "WHERE order_id = :order", "order={$order_id}");
                    if ($Read->getResult()) {
                        $orderItens = $Read->getResult();
                        $i = 0;
                        $ItemsPrice = 0;
                        $ItemsAmount = 0;

                        foreach ($Read->getResult() as $Item) {
                            $Read->FullRead("SELECT stock_code, stock_code_title, stock_color, stock_color_title FROM " . DB_PDT_STOCK . " WHERE stock_id = :stid",
                                "stid={$Item['stock_id']}");
                            $PdtVariation = ($Read->getResult() && $Read->getResult()[0]['stock_color'] != 'default' && $Read->getResult()[0]['stock_code'] == 'default' ? " ({$Read->getResult()[0]['stock_color_title']})" : ($Read->getResult() && $Read->getResult()[0]['stock_color'] == 'default' && $Read->getResult()[0]['stock_code'] != 'default' ? " ({$Read->getResult()[0]['stock_code_title']})" : ($Read->getResult() && $Read->getResult()[0]['stock_color'] != 'default' && $Read->getResult()[0]['stock_code'] != 'default' ? " ({$Read->getResult()[0]['stock_color_title']} ({$Read->getResult()[0]['stock_code_title']}))" : '')));

                            $i++;
                            $ItemsAmount += $Item['item_amount'];
                            $ItemsPrice += $Item['item_amount'] * $Item['item_price'];
                            $somaItems = $Item['item_amount'] * $Item['item_price'];

                            $produtos[] = array_merge($Item,
                                ['pdt_variation' => $PdtVariation, 'totalItem' => $somaItems, 'ic' => $i]);
                        }
                        if (!empty($order_installments) && $order_installments > 1) {
                            $totalinstallments = $order_installments * $order_installment;
                        } else {
                            $totalinstallments = '';
                        }
                    }

                    $Read->ExeRead(DB_MODELS_EMAILS, "WHERE email_section = :section", "section=payment_1");
                    if ($Read->getResult()) {
                        $modelEmail = $Read->getResult()[0];

                        $templateBody = $twig->createTemplate($modelEmail['email_message']);
                        $mailMessage = $templateBody->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'encode_orderid' => base64_encode($order_id),
                            'order_date' => date('d/m/Y H\hi', strtotime($order_date)),
                            'order_price' => $order_price,
                            'order_payment' => getOrderPayment($order_payment),
                            'order_billet' => $order_billet,
                            'orderItens' => $orderItens,
                            'i' => str_pad($i, 5, 0, STR_PAD_LEFT),
                            'items_amount' => $ItemsAmount,
                            'produtos' => $produtos,
                            'order_coupon' => $order_coupon,
                            'items_price' => number_format($ItemsPrice * ($order_coupon / 100), '2', ',', '.'),
                            'order_shipcode' => $order_shipcode,
                            'order_via_shipcode' => getShipmentTag($order_shipcode),
                            'order_shipprice' => $order_shipprice,
                            'order_installments' => $order_installments,
                            'order_installment' => $order_installment,
                            'totalinstallments' => $totalinstallments
                        ));

                        $templateSubject = $twig->createTemplate($modelEmail['email_subject']);
                        $mailSubject = $templateSubject->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'encode_orderid' => base64_encode($order_id),
                            'order_date' => date('d/m/Y H\hi', strtotime($order_date)),
                            'order_price' => $order_price
                        ));

                        $mailSender = (!empty($modelEmail['email_sender']) ? $modelEmail['email_sender'] : MAIL_USER);
                        $mailSenderName = (!empty($modelEmail['email_sender_name']) ? $modelEmail['email_sender_name'] : SITE_NAME);

                        $Email = new Email;
                        $Email->EnviarMontando(
                            $mailSubject,
                            $mailMessage,
                            $mailSenderName,
                            $mailSender,
                            "{$Client['user_name']} {$Client['user_lastname']}",
                            $Client['user_email']
                        );
                    }

                } elseif ($PaymentStatus === 'in_process') {
                    /*
                     * EM ANÁLISE
                     */
                    $Read->ExeRead(DB_ORDERS_ITEMS, "WHERE order_id = :order", "order={$order_id}");
                    if ($Read->getResult()) {
                        $orderItens = $Read->getResult();
                        $i = 0;
                        $ItemsPrice = 0;
                        $ItemsAmount = 0;
                        foreach ($Read->getResult() as $Item) {
                            $Read->FullRead("SELECT stock_code, stock_code_title, stock_color, stock_color_title FROM " . DB_PDT_STOCK . " WHERE stock_id = :stid",
                                "stid={$Item['stock_id']}");
                            $PdtVariation = ($Read->getResult() && $Read->getResult()[0]['stock_color'] != 'default' && $Read->getResult()[0]['stock_code'] == 'default' ? " ({$Read->getResult()[0]['stock_color_title']})" : ($Read->getResult() && $Read->getResult()[0]['stock_color'] == 'default' && $Read->getResult()[0]['stock_code'] != 'default' ? " ({$Read->getResult()[0]['stock_code_title']})" : ($Read->getResult() && $Read->getResult()[0]['stock_color'] != 'default' && $Read->getResult()[0]['stock_code'] != 'default' ? " ({$Read->getResult()[0]['stock_color_title']} ({$Read->getResult()[0]['stock_code_title']}))" : '')));

                            $i++;
                            $ItemsAmount += $Item['item_amount'];
                            $ItemsPrice += $Item['item_amount'] * $Item['item_price'];
                            $somaItems = $Item['item_amount'] * $Item['item_price'];

                            $produtos[] = array_merge($Item,
                                ['pdt_variation' => $PdtVariation, 'totalItem' => $somaItems, 'ic' => $i]);
                        }

                        if (!empty($order_installments) && $order_installments > 1) {
                            $totalinstallments = $order_installments * $order_installment;
                        } else {
                            $totalinstallments = '';
                        }
                    }

                    $Read->ExeRead(DB_MODELS_EMAILS, "WHERE email_section = :section", "section=payment_2");
                    if ($Read->getResult()) {
                        $modelEmail = $Read->getResult()[0];

                        $templateBody = $twig->createTemplate($modelEmail['email_message']);
                        $mailMessage = $templateBody->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'encode_orderid' => base64_encode($order_id),
                            'order_date' => date('d/m/Y H\hi', strtotime($order_date)),
                            'order_price' => $order_price,
                            'order_payment' => getOrderPayment($order_payment),
                            'order_billet' => $order_billet,
                            'orderItens' => $orderItens,
                            'i' => str_pad($i, 5, 0, STR_PAD_LEFT),
                            'items_amount' => $ItemsAmount,
                            'produtos' => $produtos,
                            'order_coupon' => $order_coupon,
                            'items_price' => number_format($ItemsPrice * ($order_coupon / 100), '2', ',', '.'),
                            'order_shipcode' => $order_shipcode,
                            'order_via_shipcode' => getShipmentTag($order_shipcode),
                            'order_shipprice' => $order_shipprice,
                            'order_installments' => $order_installments,
                            'order_installment' => $order_installment,
                            'totalinstallments' => $totalinstallments
                        ));

                        $templateSubject = $twig->createTemplate($modelEmail['email_subject']);
                        $mailSubject = $templateSubject->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'encode_orderid' => base64_encode($order_id),
                            'order_date' => date('d/m/Y H\hi', strtotime($order_date)),
                            'order_price' => $order_price
                        ));

                        $mailSender = (!empty($modelEmail['email_sender']) ? $modelEmail['email_sender'] : MAIL_USER);
                        $mailSenderName = (!empty($modelEmail['email_sender_name']) ? $modelEmail['email_sender_name'] : SITE_NAME);

                        $Email = new Email;
                        $Email->EnviarMontando(
                            $mailSubject,
                            $mailMessage,
                            $mailSenderName,
                            $mailSender,
                            "{$Client['user_name']} {$Client['user_lastname']}",
                            $Client['user_email']
                        );
                    }

                } elseif ($PaymentStatus === 'approved') {
                    /*
                     * PAGO
                     */
                    if (ECOMMERCE_STOCK) {
                        $Read->FullRead("SELECT pdt_id, stock_id, item_amount FROM " . DB_ORDERS_ITEMS . " WHERE order_id = :id",
                            "id={$order_id}");
                        foreach ($Read->getResult() as $OrderStockManage) {
                            //STOCK UPDATE
                            $Read->FullRead("SELECT stock_inventory, stock_sold FROM " . DB_PDT_STOCK . " WHERE stock_id = :id",
                                "id={$OrderStockManage['stock_id']}");
                            $UpdatePdtStock = [
                                'stock_inventory' => $Read->getResult()[0]['stock_inventory'] - $OrderStockManage['item_amount'],
                                'stock_sold' => $Read->getResult()[0]['stock_sold'] + $OrderStockManage['item_amount']
                            ];
                            $Update->ExeUpdate(DB_PDT_STOCK, $UpdatePdtStock, "WHERE stock_id = :id",
                                "id={$OrderStockManage['stock_id']}");

                            //INVENTORY UPDATE
                            $Read->FullRead("SELECT pdt_inventory, pdt_delivered FROM " . DB_PDT . " WHERE pdt_id = :id",
                                "id={$OrderStockManage['pdt_id']}");
                            $UpdatePdtInventory = [
                                'pdt_inventory' => $Read->getResult()[0]['pdt_inventory'] - $OrderStockManage['item_amount'],
                                'pdt_delivered' => $Read->getResult()[0]['pdt_delivered'] + $OrderStockManage['item_amount']
                            ];
                            $Update->ExeUpdate(DB_PDT, $UpdatePdtInventory, "WHERE pdt_id = :id",
                                "id={$OrderStockManage['pdt_id']}");
                        }
                    }

                    $Read->ExeRead(DB_ORDERS_ITEMS, "WHERE order_id = :order", "order={$order_id}");
                    if ($Read->getResult()) {
                        $orderItens = $Read->getResult();
                        $i = 0;
                        $ItemsPrice = 0;
                        $ItemsAmount = 0;
                        foreach ($Read->getResult() as $Item) {
                            $Read->FullRead("SELECT stock_code, stock_code_title, stock_color, stock_color_title FROM " . DB_PDT_STOCK . " WHERE stock_id = :stid",
                                "stid={$Item['stock_id']}");
                            $PdtVariation = ($Read->getResult() && $Read->getResult()[0]['stock_color'] != 'default' && $Read->getResult()[0]['stock_code'] == 'default' ? " ({$Read->getResult()[0]['stock_color_title']})" : ($Read->getResult() && $Read->getResult()[0]['stock_color'] == 'default' && $Read->getResult()[0]['stock_code'] != 'default' ? " ({$Read->getResult()[0]['stock_code_title']})" : ($Read->getResult() && $Read->getResult()[0]['stock_color'] != 'default' && $Read->getResult()[0]['stock_code'] != 'default' ? " ({$Read->getResult()[0]['stock_color_title']} ({$Read->getResult()[0]['stock_code_title']}))" : '')));

                            $i++;
                            $ItemsAmount += $Item['item_amount'];
                            $ItemsPrice += $Item['item_amount'] * $Item['item_price'];
                            $somaItems = $Item['item_amount'] * $Item['item_price'];

                            $produtos[] = array_merge($Item,
                                ['pdt_variation' => $PdtVariation, 'totalItem' => $somaItems, 'ic' => $i]);
                        }

                        if (!empty($order_installments) && $order_installments > 1) {
                            $totalinstallments = $order_installments * $order_installment;
                        } else {
                            $totalinstallments = '';
                        }
                    }

                    $Read->ExeRead(DB_MODELS_EMAILS, "WHERE email_section = :section", "section=payment_3");
                    if ($Read->getResult()) {
                        $modelEmail = $Read->getResult()[0];

                        $templateBody = $twig->createTemplate($modelEmail['email_message']);
                        $mailMessage = $templateBody->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'encode_orderid' => base64_encode($order_id),
                            'order_date' => date('d/m/Y H\hi', strtotime($order_date)),
                            'order_price' => $order_price,
                            'order_payment' => getOrderPayment($order_payment),
                            'order_billet' => $order_billet,
                            'orderItens' => $orderItens,
                            'i' => str_pad($i, 5, 0, STR_PAD_LEFT),
                            'items_amount' => $ItemsAmount,
                            'produtos' => $produtos,
                            'order_coupon' => $order_coupon,
                            'items_price' => number_format($ItemsPrice * ($order_coupon / 100), '2', ',', '.'),
                            'order_shipcode' => $order_shipcode,
                            'order_via_shipcode' => getShipmentTag($order_shipcode),
                            'order_shipprice' => $order_shipprice,
                            'order_installments' => $order_installments,
                            'order_installment' => $order_installment,
                            'totalinstallments' => $totalinstallments
                        ));

                        $templateSubject = $twig->createTemplate($modelEmail['email_subject']);
                        $mailSubject = $templateSubject->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'encode_orderid' => base64_encode($order_id),
                            'order_date' => date('d/m/Y H\hi', strtotime($order_date)),
                            'order_price' => $order_price
                        ));

                        $mailSender = (!empty($modelEmail['email_sender']) ? $modelEmail['email_sender'] : MAIL_USER);
                        $mailSenderName = (!empty($modelEmail['email_sender_name']) ? $modelEmail['email_sender_name'] : SITE_NAME);

                        $Email = new Email;
                        $Email->EnviarMontando(
                            $mailSubject,
                            $mailMessage,
                            $mailSenderName,
                            $mailSender,
                            "{$Client['user_name']} {$Client['user_lastname']}",
                            $Client['user_email']
                        );
                    }

                    $UpdateOrder = [
                        'order_status' => 6,
                        'order_update' => date('Y-m-d H:i:s'),
                        'order_mail_processing' => 1
                    ];
                    $Update->ExeUpdate(DB_ORDERS, $UpdateOrder, "WHERE order_id = :orid", "orid={$order_id}");

                    //NOTIFICAÇÃO DE ENVIO
                    $Read->ExeRead(DB_MODELS_EMAILS, "WHERE email_section = :section",
                        "section=administra_notify_orderpaid");
                    if ($Read->getResult()) {
                        $modelEmail = $Read->getResult()[0];

                        $templateBody = $twig->createTemplate($modelEmail['email_message']);
                        $mailMessage = $templateBody->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'order_price' => $order_price,
                            'str_order_date' => date("d/m/Y \a\s H\hi", strtotime($order_date)),
                            'order_code' => $order_code,
                        ));

                        $templateSubject = $twig->createTemplate($modelEmail['email_subject']);
                        $mailSubject = $templateSubject->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                        ));

                        $mailSender = (!empty($modelEmail['email_sender']) ? $modelEmail['email_sender'] : MAIL_USER);
                        $mailSenderName = (!empty($modelEmail['email_sender_name']) ? $modelEmail['email_sender_name'] : SITE_NAME);

                        $Email = new Email;
                        $Email->EnviarMontando(
                            $mailSubject,
                            $mailMessage,
                            $mailSenderName,
                            $mailSender,
                            MAIL_SENDER,
                            PAGSEGURO_NOTIFICATION_EMAIL
                        );
                    }

                } elseif ($PaymentStatus == 4) {
                    //DISPONÍVEL
                } elseif ($PaymentStatus === 'in_mediation') {

                    $Read->ExeRead(DB_MODELS_EMAILS, "WHERE email_section = :section",
                        "section=administra_notify_disputa");
                    if ($Read->getResult()) {
                        $modelEmail = $Read->getResult()[0];

                        $templateBody = $twig->createTemplate($modelEmail['email_message']);
                        $mailMessage = $templateBody->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'order_price' => $order_price,
                            'str_order_date' => date("d/m/Y \a\s H\hi", strtotime($order_date)),
                            'order_code' => $order_code,
                        ));

                        $templateSubject = $twig->createTemplate($modelEmail['email_subject']);
                        $mailSubject = $templateSubject->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                        ));

                        $mailSender = (!empty($modelEmail['email_sender']) ? $modelEmail['email_sender'] : MAIL_USER);
                        $mailSenderName = (!empty($modelEmail['email_sender_name']) ? $modelEmail['email_sender_name'] : SITE_NAME);

                        $Email = new Email;
                        $Email->EnviarMontando(
                            $mailSubject,
                            $mailMessage,
                            $mailSenderName,
                            $mailSender,
                            MAIL_SENDER,
                            PAGSEGURO_NOTIFICATION_EMAIL
                        );
                    }

                } elseif ($PaymentStatus === 'refunded') {
                    /**
                     * DEVOLVIDA
                     */
                    $Read->ExeRead(DB_ORDERS_ITEMS, "WHERE order_id = :order", "order={$order_id}");
                    if ($Read->getResult()) {
                        $orderItens = $Read->getResult();
                        $i = 0;
                        $ItemsPrice = 0;
                        $ItemsAmount = 0;
                        foreach ($Read->getResult() as $Item) {
                            $Read->FullRead("SELECT stock_code, stock_code_title, stock_color, stock_color_title FROM " . DB_PDT_STOCK . " WHERE stock_id = :stid",
                                "stid={$Item['stock_id']}");
                            $PdtVariation = ($Read->getResult() && $Read->getResult()[0]['stock_color'] != 'default' && $Read->getResult()[0]['stock_code'] == 'default' ? " ({$Read->getResult()[0]['stock_color_title']})" : ($Read->getResult() && $Read->getResult()[0]['stock_color'] == 'default' && $Read->getResult()[0]['stock_code'] != 'default' ? " ({$Read->getResult()[0]['stock_code_title']})" : ($Read->getResult() && $Read->getResult()[0]['stock_color'] != 'default' && $Read->getResult()[0]['stock_code'] != 'default' ? " ({$Read->getResult()[0]['stock_color_title']} ({$Read->getResult()[0]['stock_code_title']}))" : '')));

                            $i++;
                            $ItemsAmount += $Item['item_amount'];
                            $ItemsPrice += $Item['item_amount'] * $Item['item_price'];
                            $somaItems = $Item['item_amount'] * $Item['item_price'];

                            $produtos[] = array_merge($Item,
                                ['pdt_variation' => $PdtVariation, 'totalItem' => $somaItems, 'ic' => $i]);
                        }

                        if (!empty($order_installments) && $order_installments > 1) {
                            $totalinstallments = $order_installments * $order_installment;
                        } else {
                            $totalinstallments = '';
                        }
                    }

                    $Read->ExeRead(DB_MODELS_EMAILS, "WHERE email_section = :section", "section=payment_6");
                    if ($Read->getResult()) {
                        $modelEmail = $Read->getResult()[0];

                        $templateBody = $twig->createTemplate($modelEmail['email_message']);
                        $mailMessage = $templateBody->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'encode_orderid' => base64_encode($order_id),
                            'order_date' => date('d/m/Y H\hi', strtotime($order_date)),
                            'order_price' => $order_price,
                            'order_payment' => getOrderPayment($order_payment),
                            'order_billet' => $order_billet,
                            'orderItens' => $orderItens,
                            'i' => str_pad($i, 5, 0, STR_PAD_LEFT),
                            'items_amount' => $ItemsAmount,
                            'produtos' => $produtos,
                            'order_coupon' => $order_coupon,
                            'items_price' => number_format($ItemsPrice * ($order_coupon / 100), '2', ',', '.'),
                            'order_shipcode' => $order_shipcode,
                            'order_via_shipcode' => getShipmentTag($order_shipcode),
                            'order_shipprice' => $order_shipprice,
                            'order_installments' => $order_installments,
                            'order_installment' => $order_installment,
                            'totalinstallments' => $totalinstallments
                        ));

                        $templateSubject = $twig->createTemplate($modelEmail['email_subject']);
                        $mailSubject = $templateSubject->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'encode_orderid' => base64_encode($order_id),
                            'order_date' => date('d/m/Y H\hi', strtotime($order_date)),
                            'order_price' => $order_price
                        ));

                        $mailSender = (!empty($modelEmail['email_sender']) ? $modelEmail['email_sender'] : MAIL_USER);
                        $mailSenderName = (!empty($modelEmail['email_sender_name']) ? $modelEmail['email_sender_name'] : SITE_NAME);

                        $Email = new Email;
                        $Email->EnviarMontando(
                            $mailSubject,
                            $mailMessage,
                            $mailSenderName,
                            $mailSender,
                            "{$Client['user_name']} {$Client['user_lastname']}",
                            $Client['user_email']
                        );
                    }

                    //ORDER CANCEL
                    if ($order_status != 2) {
                        $UpdateOrder = ['order_status' => 2, 'order_update' => date('Y-m-d H:i:s')];
                        $Update->ExeUpdate(DB_ORDERS, $UpdateOrder, "WHERE order_id = :orid", "orid={$order_id}");

                        //STOCK MANAGER
                        if (ECOMMERCE_STOCK) {
                            $Read->FullRead("SELECT pdt_id, stock_id, item_amount FROM " . DB_ORDERS_ITEMS . " WHERE order_id = :id",
                                "id={$order_id}");
                            foreach ($Read->getResult() as $OrderStockManage) {
                                //STOCK UPDATE
                                $Read->FullRead("SELECT stock_inventory, stock_sold FROM " . DB_PDT_STOCK . " WHERE stock_id = :id",
                                    "id={$OrderStockManage['stock_id']}");
                                $UpdatePdtStock = [
                                    'stock_inventory' => $Read->getResult()[0]['stock_inventory'] + $OrderStockManage['item_amount'],
                                    'stock_sold' => $Read->getResult()[0]['stock_sold'] - $OrderStockManage['item_amount']
                                ];
                                $Update->ExeUpdate(DB_PDT_STOCK, $UpdatePdtStock, "WHERE stock_id = :id",
                                    "id={$OrderStockManage['stock_id']}");

                                //INVENTORY UPDATE
                                $Read->FullRead("SELECT pdt_inventory, pdt_delivered FROM " . DB_PDT . " WHERE pdt_id = :id",
                                    "id={$OrderStockManage['pdt_id']}");
                                $UpdatePdtInventory = [
                                    'pdt_inventory' => $Read->getResult()[0]['pdt_inventory'] + $OrderStockManage['item_amount'],
                                    'pdt_delivered' => $Read->getResult()[0]['pdt_delivered'] - $OrderStockManage['item_amount']
                                ];
                                $Update->ExeUpdate(DB_PDT, $UpdatePdtInventory, "WHERE pdt_id = :id",
                                    "id={$OrderStockManage['pdt_id']}");
                            }
                        }
                    }

                    $Read->ExeRead(DB_MODELS_EMAILS, "WHERE email_section = :section",
                        "section=administra_notify_devolvido");
                    if ($Read->getResult()) {
                        $modelEmail = $Read->getResult()[0];

                        $templateBody = $twig->createTemplate($modelEmail['email_message']);
                        $mailMessage = $templateBody->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'order_price' => $order_price,
                            'str_order_date' => date("d/m/Y \a\s H\hi", strtotime($order_date)),
                            'order_code' => $order_code,
                        ));

                        $templateSubject = $twig->createTemplate($modelEmail['email_subject']);
                        $mailSubject = $templateSubject->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                        ));

                        $mailSender = (!empty($modelEmail['email_sender']) ? $modelEmail['email_sender'] : MAIL_USER);
                        $mailSenderName = (!empty($modelEmail['email_sender_name']) ? $modelEmail['email_sender_name'] : SITE_NAME);

                        $Email = new Email;
                        $Email->EnviarMontando(
                            $mailSubject,
                            $mailMessage,
                            $mailSenderName,
                            $mailSender,
                            MAIL_SENDER,
                            PAGSEGURO_NOTIFICATION_EMAIL
                        );
                    }

                } elseif ($PaymentStatus === 'cancelled') {
                    /**
                     * CANCELADO
                     */
                    $Read->ExeRead(DB_ORDERS_ITEMS, "WHERE order_id = :order", "order={$order_id}");
                    if ($Read->getResult()) {
                        $orderItens = $Read->getResult();
                        $i = 0;
                        $ItemsPrice = 0;
                        $ItemsAmount = 0;
                        foreach ($Read->getResult() as $Item) {
                            $Read->FullRead("SELECT stock_code, stock_code_title, stock_color, stock_color_title FROM " . DB_PDT_STOCK . " WHERE stock_id = :stid",
                                "stid={$Item['stock_id']}");
                            $PdtVariation = ($Read->getResult() && $Read->getResult()[0]['stock_color'] != 'default' && $Read->getResult()[0]['stock_code'] == 'default' ? " ({$Read->getResult()[0]['stock_color_title']})" : ($Read->getResult() && $Read->getResult()[0]['stock_color'] == 'default' && $Read->getResult()[0]['stock_code'] != 'default' ? " ({$Read->getResult()[0]['stock_code_title']})" : ($Read->getResult() && $Read->getResult()[0]['stock_color'] != 'default' && $Read->getResult()[0]['stock_code'] != 'default' ? " ({$Read->getResult()[0]['stock_color_title']} ({$Read->getResult()[0]['stock_code_title']}))" : '')));

                            $i++;
                            $ItemsAmount += $Item['item_amount'];
                            $ItemsPrice += $Item['item_amount'] * $Item['item_price'];
                            $somaItems = $Item['item_amount'] * $Item['item_price'];

                            $produtos[] = array_merge($Item,
                                ['pdt_variation' => $PdtVariation, 'totalItem' => $somaItems, 'ic' => $i]);
                        }

                        if (!empty($order_installments) && $order_installments > 1) {
                            $totalinstallments = $order_installments * $order_installment;
                        } else {
                            $totalinstallments = '';
                        }
                    }

                    $Read->ExeRead(DB_MODELS_EMAILS, "WHERE email_section = :section", "section=payment_7");
                    if ($Read->getResult()) {
                        $modelEmail = $Read->getResult()[0];

                        $templateBody = $twig->createTemplate($modelEmail['email_message']);
                        $mailMessage = $templateBody->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'encode_orderid' => base64_encode($order_id),
                            'order_date' => date('d/m/Y H\hi', strtotime($order_date)),
                            'order_price' => $order_price,
                            'order_payment' => getOrderPayment($order_payment),
                            'order_billet' => $order_billet,
                            'orderItens' => $orderItens,
                            'i' => str_pad($i, 5, 0, STR_PAD_LEFT),
                            'items_amount' => $ItemsAmount,
                            'produtos' => $produtos,
                            'order_coupon' => $order_coupon,
                            'items_price' => number_format($ItemsPrice * ($order_coupon / 100), '2', ',', '.'),
                            'order_shipcode' => $order_shipcode,
                            'order_via_shipcode' => getShipmentTag($order_shipcode),
                            'order_shipprice' => $order_shipprice,
                            'order_installments' => $order_installments,
                            'order_installment' => $order_installment,
                            'totalinstallments' => $totalinstallments
                        ));

                        $templateSubject = $twig->createTemplate($modelEmail['email_subject']);
                        $mailSubject = $templateSubject->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'encode_orderid' => base64_encode($order_id),
                            'order_date' => date('d/m/Y H\hi', strtotime($order_date)),
                            'order_price' => $order_price
                        ));

                        $mailSender = (!empty($modelEmail['email_sender']) ? $modelEmail['email_sender'] : MAIL_USER);
                        $mailSenderName = (!empty($modelEmail['email_sender_name']) ? $modelEmail['email_sender_name'] : SITE_NAME);

                        $Email = new Email;
                        $Email->EnviarMontando(
                            $mailSubject,
                            $mailMessage,
                            $mailSenderName,
                            $mailSender,
                            "{$Client['user_name']} {$Client['user_lastname']}",
                            $Client['user_email']
                        );
                    }

                    //ORDER CANCEL
                    if ($order_status != 2) {
                        $UpdateOrder = ['order_status' => 2, 'order_update' => date('Y-m-d H:i:s')];
                        $Update->ExeUpdate(DB_ORDERS, $UpdateOrder, "WHERE order_id = :orid", "orid={$order_id}");
                    }

                    //NOTIFY
                    $Read->ExeRead(DB_MODELS_EMAILS, "WHERE email_section = :section",
                        "section=administra_notify_cancelamento");
                    if ($Read->getResult()) {
                        $modelEmail = $Read->getResult()[0];

                        $templateBody = $twig->createTemplate($modelEmail['email_message']);
                        $mailMessage = $templateBody->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                            'str_order_id' => str_pad($order_id, 7, 0, 0),
                            'order_price' => $order_price,
                            'str_order_date' => date("d/m/Y \a\s H\hi", strtotime($order_date)),
                            'order_code' => $order_code,
                        ));

                        $templateSubject = $twig->createTemplate($modelEmail['email_subject']);
                        $mailSubject = $templateSubject->render(array(
                            'user' => $Client,
                            'order_id' => $order_id,
                        ));

                        $mailSender = (!empty($modelEmail['email_sender']) ? $modelEmail['email_sender'] : MAIL_USER);
                        $mailSenderName = (!empty($modelEmail['email_sender_name']) ? $modelEmail['email_sender_name'] : SITE_NAME);

                        $Email = new Email;
                        $Email->EnviarMontando(
                            $mailSubject,
                            $mailMessage,
                            $mailSenderName,
                            $mailSender,
                            MAIL_SENDER,
                            PAGSEGURO_NOTIFICATION_EMAIL
                        );
                    }

                }
            }
        } catch (MercadoPagoException $e) {
            die($e->getMessage());
        }
    }
}
