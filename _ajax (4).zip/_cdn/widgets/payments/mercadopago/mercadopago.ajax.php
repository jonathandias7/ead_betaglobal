<?php
session_start();
require '../../../../_app/Config.inc.php';

$post = filter_input_array(INPUT_POST, FILTER_DEFAULT);
(empty($post) || empty($post['action']) ?  die('Access denied') : null);
$data_post = clean_post($post);

$action = new Product($post);
$mp = new MPCrud;

if(empty($_SESSION['userLogin'])):
    $callback = ['error' => 'need_login'];
elseif($post['action'] === 'billet_pay'):
    $callback = $action->payWithBillet();
elseif($post['action'] === 'credit_card_pay'):
    $callback = $action->payWithCreditCard();
elseif($post['action'] === 'remove_credit_card'):
    try {
        $get_resource = $mp->creditCardDelete($data_post['customer_id'], $data_post['credit_card_id']);
        $total = count($get_resource['response']);
        $callback = [
            'trigger' => AjaxErro("<b>{$_SESSION['userLogin']['user_name']}</b>, removemos o cartão da sua conta!"),
            'check' => $total
        ];
    } catch (MercadoPagoException $e) {
        $callback = ['trigger' => AjaxErro($e->getMessage())];
    }
endif;

echo json_encode($callback);