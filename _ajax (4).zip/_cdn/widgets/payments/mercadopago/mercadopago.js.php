<script src="<?= BASE; ?>/_cdn/widgets/payments/mercadopago/mercadopago.js"></script>
<script>
// Global vars
var mp_api_token = "<?= ((int)MP_TRANSPARENT_MODE === 1 ? MP_TRANSPARENT_PKEY_PROD : MP_TRANSPARENT_PKEY_SANDBOX); ?>";
var uri = "<?= BASE; ?>/_cdn/widgets/payments/mercadopago/mercadopago.ajax.php";
var nocard = "<?= BASE . '/' . REQUIRE_PATH; ?>/images/nocard.png";

// Initiate Mercado Pago SDK
Mercadopago.setPublishableKey(mp_api_token);

function wcIsNumeric(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
};

function wcGetInstallments() {
    var input_amount = document.querySelector('#order_amount').value;
    var input_instalments = document.querySelector('#max_instalments').value;
    var form;
    
    var is_visible = $('#wc_existing_cards_hidden').is(':visible');
    
    if(is_visible === true) {
        form = '#wc_existing_cards_hidden';
    } else {
        form = '#credit-card-mercado-pago';
    }
    
    Mercadopago.getInstallments({
        bin: getBin(), 
        amount: input_amount
    }, function(status, response){
        var Installments = response[0]['payer_costs'];
        document.querySelector(form + ' .cardInstallmentQuantity').innerHTML = '<option value="">Selecione as parcelas</option>';

        $.each(Installments, function (index, elem) {
            if(elem.installments <= input_instalments) {
                $(form + " .cardInstallmentQuantity option:last").after('<option value="' + elem.installments + 'x' + elem.installment_amount + '">' + elem.recommended_message + '</option>');
            }
        });
    });
}

function cardsHandler(){
     var card = document.querySelector('select[data-checkout="cardId"]');

     if (card[card.options.selectedIndex].getAttribute('security_code_length') === 0){
        document.querySelector("#cvv-input-block").style.display = "none";
     }else if(document.querySelector("#cvv-input-block").style.display !== "block") {
        document.querySelector("#cvv-input-block").style.display = "block";
     }
}

function getBin() {
    var exist_cc = $('select[data-checkout="cardId"]').find(':selected').data('bin');
    var ccNumber;
    var is_visible = $('#wc_existing_cards_hidden').is(':visible');
    
    if(is_visible === true) {
        ccNumber = exist_cc;
        return ccNumber;
    } else {
        ccNumber = $('input[data-checkout="cardNumber"]').val();
        return ccNumber.replace(/[ .-]/g, '').slice(0, 6);
    }
};

function setPaymentMethodInfo(status, response) {
    if (status === 200) {
        $("#credit-card-mercado-pago .payment_method_id").attr("value", response[0].id);
        $('.workcontrol_cardnumber').css('background-image', 'url(' + response[0].secure_thumbnail + ')');
        wcGetInstallments();        
    } else if(status === 400) {
        $('.workcontrol_cardnumber').css('background-image', 'url(' + nocard + ')');
    }
};

/**
 * Show installments and append payment methods
 * to form existing credit card
 * 
 * @param {type} status
 * @param {type} response
 * @returns {undefined}
 */
function setPaymentMethodInfoExistCC(status, response) {
    if (status === 200) {
        $("#wc_existing_cards_hidden .payment_method_id").attr("value", response[0].id);
        wcGetInstallments();        
    }
};

var switchCodes = function(code) {
    let newCode;

    switch(code) {
        case "011"  : newCode = "O token expirou. Reinicie o processo."; break;
        case "205"  : newCode = "Digite o número do seu cartão."; break;
        case "208"  : newCode = "Escolha um mês de expiração do seu cartão."; break;
        case "209"  : newCode = "Escolha um ano de expiração do seu cartão."; break;
        case "212"  : newCode = "O campo tipo de documento é obrigatório"; break;
        case "213"  : newCode = "Insira o seu documento."; break;
        case "214"  : newCode = "O campo número do documento é obrigatório"; break;
        case "220"  : newCode = "Digite o seu banco emissor."; break;
        case "221"  : newCode = "Insira o nome e o sobrenome."; break;
        case "224"  : newCode = "Digite o código de segurança."; break;
        case "E301" : newCode = "Há algo errado com este número. Volte a digitá-lo."; break;
        case "E302" : newCode = "Revise o código de segurança."; break;
        case "316"  : newCode = "Insira um nome válido."; break;
        case "322"  : newCode = "Revise o tipo de documento selecionado."; break;
        case "323"  : newCode = "Revise o documento informado."; break;
        case "324"  : newCode = "Revise o documento informado."; break;
        case "325"  : newCode = "Revise o mês de expiração do cartão."; break;
        case "326"  : newCode = "Revise o ano de expiração do cartão."; break;
    }

    return newCode;
};

var mpResponseHandler = function(status, response) {
    var error = '';
    
    if (response.error && status !== 200 && status !== 201) {
        $.each(response.cause, function(i,v){
            error += '<i class="fa fa-exclamation" area-hidden="true"></i> ' + switchCodes(v.code) + '<br>'; 
        });
        
        showCallback(error);
    } else {
        var is_visible = $('#wc_existing_cards_hidden').is(':visible');
        var form;
    
        if(is_visible === true) {
            form = '#wc_existing_cards_hidden';
        } else {
            form = '#credit-card-mercado-pago';
        }
    
        $(form + " .card_token_id").attr("value", response.id);
        submit_cc_form();
    }
};

function doPay(form){    
    Mercadopago.createToken(form, mpResponseHandler);
};

function closeCallback() {    
    $('body').find('.callback').animate({
        top: "-275px"
    }, 600);
}

function showCallback(error) {
    $('body').find('.callback').remove();
    $('<div class="callback error">' + error + '</div>').appendTo('body');
    $('body').find('.callback').animate({
        top: "75px"
    }, 600);
}

function submit_cc_form() {
    var form;
    var is_visible = $('#wc_existing_cards_hidden').is(':visible');
    
        if(is_visible === true) {
            form = '#wc_existing_cards_hidden';
        } else {
            form = '#credit-card-mercado-pago';
        }
        
    var form = $(form),
        formData = new FormData(form[0]);

    $.ajax({
        url: uri,
        type: 'post',
        dataType: 'json',
        data: formData,
        processData: false,
        contentType: false,
        beforeSend: function(){
            form.find('button').attr('disabled', true);
            form.find('.loading').show();
        },
        complete: function(){
            form.find('button').removeAttr('disabled');
            form.find('.loading').hide();
        },
        success: function(res){
            if(res.success){
                if (res.success === true) {
                    window.location.href =  '<?= BASE; ?>/pedido/obrigado';
                } 
            }
            
            if(res.error){
                if(res.error === 'need_login'){
                    $('.wc_callback_toggle').slideUp();
                    $('.wc_toggle_login').slideDown();
                }else{
                    var split_errors = res.error.split('-'), error;
                        error = split_errors[0].split(':')[1];

                    showCallback(switchBackendMessages(error));
                }
            }
        }
    });
}

function switchBackendMessages(code) {
    var callback;
    
    switch(code) {
        case '4033': callback = "Selecione uma das parcelas"; break;
        case '3031': callback = "Informe o código de segurança do cartão"; break;
        case '3032': callback = "O código de segurança informado está incorreto"; break;
        case '2002': callback = "O cliente não pode ser encontrado"; break;
        case '4029': callback = "Tipo de pagador inválido"; break;
        case '4020': callback = "A url de retorno é inválida. Contacte o administrador do site e informe esta mensagem com o código(" + code + ")"; break;
        case '151':
        case '2060': callback = "O usuário que está fazendo a solicitação é o mesmo usuário responsável pela conta no MP"; break;
        case '4037': callback = "Não foi possível gerar um boleto para o valor da sua compra. Tente pagar com um cartão de crédito ou entre em contato com o responsável pelo site"; break;
        default: callback = "Houve um erro não identificado(" + code + "). Verifique os dados informados no formulário de pagamento e tente novamente"; break;
    }
    
    return callback;
}

$(function(){
    /**
     * Try to do a pay when submit the form
     * 
     * @param {type} e
     * @returns {Boolean}
     */
    $('body').on('submit', 'form#credit-card-mercado-pago', function (e) {
        e.preventDefault();
        doPay($(this));
        return false;
    });
    
    /**
     * Try to do a pay when submit the form
     * 
     * @param {type} e
     * @returns {Boolean}
     */
    $('body').on('submit', '#wc_existing_cards_hidden', function (e) {
        e.preventDefault();
        doPay($(this));
        return false;
    });
    
    $('body').on('click', '', function() {
        closeCallback(); 
    });
    
    $('#nome').keyup(function () {
        $(this).val(function (i, val) {
            return val.toUpperCase();
        });
    });
    
    $("input[data-checkout='cardNumber']").bind("keyup change", function(event){
        var bin = getBin();

        if (event.type === "keyup") {
            if (bin.length >= 6) {
                Mercadopago.getPaymentMethod({"bin": bin}, setPaymentMethodInfo);
            }
        } else {
            setTimeout(function() {
                if (bin.length >= 6) {
                    Mercadopago.getPaymentMethod({"bin": bin}, setPaymentMethodInfo);
                }
            }, 100);
        }
    });
    
    $('body').on('change', 'select[data-checkout="cardId"]', function(){
        var bin = getBin();
        Mercadopago.getPaymentMethod({"bin": bin}, setPaymentMethodInfoExistCC);
        cardsHandler();
    });

    // Tabs
    $('body').on('click', '.workcontrol_pay_tabs p', function () {
        var WorkControlTab = $(this);
        var WorkControlPayTab = WorkControlTab.data('id');
        
        $('body').find('.workcontrol_pay_tabs p').removeClass('active');
        $('body').find('.wc_toggle_container').not('#' + WorkControlPayTab).hide();
        $('body').find('#' + WorkControlPayTab).show(1, function () {
            $(this).find('form').show();
            WorkControlTab.addClass('active');
            $('body').find('#wc_existing_cards_hidden').hide();
            $('body').find('.has_credit_card a').removeClass('disabled');
            $('body').find('#hidden-btn').fadeOut('slow');
        });
    });
    
    // Toggle payments by existing credit card
    $('body').on('click', '.has_credit_card a', function(e){
        e.preventDefault();
        var cc = $(this).data('id'),
            it = $(this);

        if(cc === 'exist-card'){
            it.addClass('disabled');
            $('body').find('#hidden-btn').fadeIn('slow');
            $('body').find('#credit-card-mercado-pago').hide();
            $('body').find('#wc_existing_cards_hidden').show();
        } else {
            $('body').find('.has_credit_card a').removeClass('disabled');
            $('body').find('#hidden-btn').fadeOut('slow');
            $('body').find('#credit-card-mercado-pago').show();
            $('body').find('#wc_existing_cards_hidden').hide();
        }

        return false;
    });
    
    // Remove credit card
    $('body').on('click', '.wc_cards .remove', function(){
        if(confirm('Você está prestes a remover este cartão de crédito previamente cadastrado na sua conta. Confirma a ação?')){
            let it = $(this);
            let customer_id = it.parents('li').data('customer-id');
            let credit_card_id = it.parents('li').data('card-id');
            let data = {
                customer_id: customer_id,
                credit_card_id: credit_card_id,
                action: 'remove_credit_card'
            };
            
            $.ajax({
                url: uri,
                type: 'POST',
                dataType: 'json',
                data: data,
                beforeSend: function () {
                    it.parents('li').find('.workcontrol_overlay').show();
                },
                success: function (data) {
                    if(data.trigger){
                        it.parents('li').remove();
                    }
                    
                    if(parseInt(data.check) === 0){
                        $('body').find('.wc_show_after').slideDown('slow');
                        $('body').find('.wc_empty_conditional').hide();
                    }                   
                },
                complete: function(){
                    it.find('.workcontrol_overlay').hide();
                }
            });
            return false;
        }
    });
    
    $('body').on('click', '.toggle-pay a', function(){
        $('.wc_callbacks').slideUp();
        $('.wc_callback_toggle').slideDown();
    });

    $('body').on('submit', 'form#billet-mercado-pago', function (e) {
        var form = $(this);
        var formData = new FormData(form[0]);

        $.ajax({
            url: uri,
            type: 'post',
            dataType: 'json',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function(){
                form.find('button').attr('disabled', true);
                form.find('.loading').show();
            },
            complete: function(){
                form.find('button').removeAttr('disabled');
                form.find('.loading').hide();
            },
            success: function (data) {
                // Paied successfully
                if (data.success === true) {   
                    window.location.href =  '<?= BASE; ?>/pedido/obrigado';
                }
                
                // Error
                if(data.error){
                    if(data.error === 'need_login'){
                        $('.wc_callback_toggle').slideUp();
                        $('.wc_toggle_login').slideDown();
                    }else{
                        var split_errors = data.error.split('-'), error;
                            error = split_errors[0].split(':')[1];

                        showCallback(switchBackendMessages(error));
                    }
                }

                // User need to activate your account
                if (data.need_activate === true) {
                    $('body').find('.wc_need_activate_account').slideDown('slow');
                } 
            }
        });

        e.preventDefault();
        return false;
    });
    
    // When user need to update address information
    $('body').on('submit', '.wc_order_address', function (event) {
        var form = $(this);
        var form_data = form.serialize();      

        $.ajax({
            url: uri,
            data: form_data,
            type: 'POST',
            dataType: 'json',
            beforeSend: function () {
                $('body').find('.wc_hidden_after_callback .workcontrol_overlay').show();
            },
            success: function (data) {
                if(data.success === true) {
                    $('body').find('#wc_container_payments').slideDown('slow');
                    $('body').find('#wc_container_access').slideUp('fast');
                    $('body').find('#wc_container_address').slideUp('fast');
                }
            },
            complete: function() {
                $('body').find('.wc_hidden_after_callback .workcontrol_overlay').hide();
            }
        });
        
        event.preventDefault();
        return false;
    });
});    
</script>