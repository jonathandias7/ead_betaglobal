<link rel="stylesheet" media="screen" href="../../_cdn/widgets/MercadoPago/mercadopago/mercadopago.css">
<link rel="stylesheet" media="screen" href="../../_cdn/widgets/ecommerce/cart.css">
<style>.workcontrol_load{display:none!important;}</style>
<?php

require_once 'mercadopago/mercadopago.js.php';

unset($_SESSION['wc_payorder']['order_id']);
if(empty($_SESSION['wc_payorder']['order_id'])):
    
    $NewOrder = [
                'user_id' => $_SESSION['userLogin']['user_id'],
                'order_status' => 3,
                'order_coupon' => (!empty($_SESSION['wc_cupom']) ? $_SESSION['wc_cupom'] : null),
                'order_price' => $totalplan,
                'order_payment' => 1,
                'store_domain' => NAME_STORE_DB,
                'plan_id' => $plan['plan_id'],
                'order_date' => date('Y-m-d H:i:s'),
                'order_date_end' => date('Y-m-d H:i:s', strtotime("+{$m} month")),
            ];
            $Create->ExeCreate(DB_ORDERS, $NewOrder);
            $OrderCreateId = $Create->getResult();
            $_SESSION['wc_payorder']['order_id'] =  $OrderCreateId;
endif; 
$mp = new MPCrud();
$order = $mp->getOrder($_SESSION['wc_payorder']['order_id']);
$amount = $order['order_price'];
$customer_cards = [];

if(!empty($_SESSION['userLogin']['user_email'])):
    $filters = ["email" => $_SESSION['userLogin']['user_email']];
    $customer = $mp->customerGet($filters);
    
    if(!empty($customer["response"]["results"])):
        $customer_cards = $customer["response"]["results"][0]["cards"];
    endif;
endif;
?>

<input type="hidden" id="order_amount" name="order_amount" value="<?= $amount; ?>">
<input type="hidden" id="max_instalments" name="max_instalments" value="<?= ECOMMERCE_PAY_SPLIT_NUM; ?>">

<div class="workcontrol_pay_tabs ch-tab-payment">
 
    <?php if(PAYMENT_PAGSEGURO) { ?>
        <div class="tab-img-pay"><a class="wc_tab wc_active" href="#wc_payment_pagseguro"><img src="<?= BASE; ?>/_cdn/widgets/MercadoPago/pagseguro/checkout_PagSeguro.png" alt="Pagseguro" title="Pagseguro"></a></div>
    <?php }

    if (PAYMENT_MERCADOPAGO) { ?>
        <div class="tab-img-pay"><a class="wc_tab <?= (PAYMENT_PAGSEGURO ? '' : 'wc_active'); ?>" href="#wc_payment_mercado_pago"><img src="<?= BASE; ?>/_cdn/widgets/MercadoPago/mercadopago/mercadopago.png" alt="Mercado Pago" title="Mercado Pago"></a></div>
    <?php }

    if (PAYPAL_PAYMENT || PAYPALCHECKOUT_PAYMENT) { ?>
        <div class="tab-img-pay"><a id="paypaltab" class="wc_tab" href="#wc_payment_paypal"><img src="<?= BASE; ?>/_cdn/widgets/MercadoPago/paypal/paypal.png" alt="Paypal" title="Paypal"></a></div>
    <?php }

    if (PAYMENT_DEPOSIT) { ?>
        <div class="tab-img-pay"><a class="wc_tab" href="#wc_payment_deposit"><img src="<?= BASE; ?>/_cdn/widgets/MercadoPago/deposit/checkout_TED.png" alt="Depósito Bancário" title="Depósito Bancário"></a></div>
    <?php } ?>
</div>

<div class="tab-content" id="MercadoPago-tabs">
    <div class="wc_toggle_login" style="display: <?= (empty($_SESSION['userLogin']) ? 'block' : 'none'); ?>">
        <form autocomplete="off" class="pc-forms wc_order_login" method="post" action="">
            <input type="hidden" name="source" value="wc_login_on_cart">
            <div class="row">
                <div class="-col-xs-12 col-lg-6">
                    <span>E-mail</span>
                    <input class="form-control wc_order_email" type="email" name="user_email" placeholder="Informe seu e-mail" required>
                </div>
                <div class="-col-xs-12 col-lg-6">
                    <span>Nome</span>
                    <input type="text" class="form-control" name="user_name" placeholder="Seu primeiro nome" required>
                </div>
            </div>
            <div class="row">
                <div class="-col-xs-12 col-lg-6">
                    <span>Sobrenome</span>
                    <input type="text" class="form-control" name="user_lastname" placeholder="Seu sobrenome" required>
                </div>
                <div class="-col-xs-12 col-lg-6">
                    <span>Celular</span>
                    <input class="form-control formPhone" type="text" name="user_cell" placeholder="Seu telefone de contato" required>
                </div>
            </div>
            <div class="row">
                <div class="-col-xs-12 col-lg-6 labeldocument">
                    <span>CPF</span>
                    <input class="form-control formCpf" type="text" name="user_document" placeholder="Seu CPF" required>
                </div>
                <div class="-col-xs-12 col-lg-6">
                    <span>Senha (de 5 a 11 caracteres):</span>
                    <input type="password" class="form-control" name="user_password" placeholder="Sua senha" required>
                </div>
            </div>
            <button class="btn btn_blue wc_button_cart">CONTINUAR</button>
            <img style="margin: 30px 0 0 10px; display: none;" alt="Processando dados" title="Processando dados" src="<?= BASE; ?>/_cdn/widgets/ecommerce/load_g.gif"> 
        </form>
    </div>

    <div class="wc_callback_toggle" style="display: <?= (empty($_SESSION['userLogin']) ? 'none' : 'block'); ?>">
        <?php 
        if (!PAYMENT_MERCADOPAGO && !PAYMENT_PAGSEGURO && !PAYPAL_PAYMENT && !PAYMENT_DEPOSIT && !PAYPALCHECKOUT_PAYMENT) {
            Erro("Não foi encontrado nenhum meio de pagamento ativo.", E_USER_WARNING);
           
        }

        if (PAYMENT_MERCADOPAGO) { ?>
        <div class="wc_tab_target <?= (PAYMENT_PAGSEGURO ? '' : 'wc_active'); ?>" id="wc_payment_mercado_pago" <?= (PAYMENT_PAGSEGURO ? 'style="display: none;"' : 'style="display: block;"'); ?>>
            <?php require 'mercadopago/CheckoutMP.php'; ?>
            <article  style='background:#ffffff;' id="wc_container_MercadoPago">  

                <?php if (ECOMMERCE_PAY_SPLIT): ?>
                <div  class="workcontrol_pay_tabs">
                    <div class="box box2"><p class="active" data-id="wc_form_cc">Pagar com cartão de crédito</p></div>
                
                </div>

                <!-- FORM CC MERCADO PAGO -->
                <div  id="wc_form_cc" class="wc_toggle_container">

                    <?php if(count($customer_cards) > 0): ?>

                    <p class="has_credit_card_title al_center">Você possui <b><?= count($customer_cards) . ' ' . (count($customer_cards) > 1 ? 'cartões de crédito cadastrados' : 'cartão de crédito cadastrado'); ?></b>. <?= (count($customer_cards) > 1 ? 'Gostaria de pagar com um deles?' : 'Gostaria de pagar com ele?'); ?></p>
                    <div class="has_credit_card">
                        <div class="row">
                            <div class="col-xs-12 col-lg-6">
                                <p><a data-id="exist-card" href="#" title="Pagar com um cartão cadastrado">Sim! Vou pagar com um cartão cadastrado</a></p>
                            </div>
                            <div class="col-xs-12 col-lg-6">
                                <p><a style="display: none;" id="hidden-btn" data-id="new-card" href="#" title="Pagar com um novo cartão">Obrigado! Quero pagar com um novo cartão</a></p>
                            </div>
                        </div>
                    </div>

                    <?php endif; ?>
                    
                    <!-- SHOW WHEN CHOOSE PAY WITH EXISTING CC -->
                    <form id="wc_existing_cards_hidden" name="wc_form_mp_exist_cc" class="workcontrol_pagseguro" autocomplete="off" style="display: none;">
                        <input type="hidden" class="action" name="action" value="credit_card_pay">
                        <input type="hidden" class="payment_method_id" name="payment_method_id" value="">
                        <input type="hidden" class="card_token_id" name="card_token_id" value="">
                        
                        <div class="labelline">
                            <label class="label70">
                                <span>Selecione um cartão da lista</span>
                                <select id="cardId" name="cardId" data-checkout="cardId" required>
                                    <option value=""></option>

                                    <?php foreach ($customer_cards as $card): ?>
                                    <option value="<?= $card["id"]; ?>" 
                                        data-bin="<?= $card["first_six_digits"]; ?>"
                                        first_six_digits="<?= $card["first_six_digits"]; ?>" 
                                        security_code_length="<?= $card["security_code"]["length"]; ?>">
                                        <?= ucfirst($card["payment_method"]["name"]); ?> final <?= $card["last_four_digits"]; ?>
                                    </option>
                                    <?php endforeach; ?>

                                </select>
                            </label><label class="label30">
                                <span>CVV</span>
                                <input required onkeypress="return wcIsNumeric(event)" data-checkout="securityCode" class="cvv" maxlength="4" type="text">
                            </label>
                        </div>
                        <div class="labelline">
                            <label class="label70">
                                <span>Selecione uma das parcelas</span>
                                <select required name="cardInstallmentQuantity" data-checkout="cardInstallmentQuantity" class="cardInstallmentQuantity">
                                    <option value="" disabled selected>Parcelas</option>
                                </select>
                            </label>
                        </div>
                        <button class="btn btn_blue wc_button_cart fl_left">Pagar minha compra</button>
                        <p class="loading">
                            <i class="fa fa-cog fa-spin fa-2x fa-fw"></i>
                            <span>Processando seu pagamento...</span>
                        </p>
                        <div class="clear"></div>
                    </form>
                    <!-- /SHOW WHEN CHOOSE PAY WITH EXISTING CC -->

                    <form style='background:#ffffff;'  id="credit-card-mercado-pago" name="wc_form_mp_cc" autocomplete="off" class="workcontrol_pagseguro" action="" method="post" novalidate>
                        <input type="hidden" class="action" name="action" value="credit_card_pay">
                        <input type="hidden" class="payment_method_id" name="payment_method_id" value="">
                        <input type="hidden" class="card_token_id" name="card_token_id" value="">

                        <div class="labelline">
                            <label class="label70">
                                <span>Número do cartão</span>
                                <input required type="text" onkeypress="return wcIsNumeric(event)" data-checkout="cardNumber" class="workcontrol_cardnumber" maxlength="22" id="cartaoMp">
                            </label><div class="label30 labelDate">
                                <span class="span">Data de validade</span>
                                <div class="labelline">
                                    <div class="month"><select required data-checkout="cardExpirationMonth" id="validadeMesMp">  
                                            <?php for($i = 1; $i <= 12; $i++): ?>
                                                <option value="<?= str_pad($i, 2, 0, STR_PAD_LEFT); ?>"><?= str_pad($i, 2, 0, STR_PAD_LEFT); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div><div class="year"><select required data-checkout="cardExpirationYear" id="validadeAnoMp">
                                            <?php for($i = 5; $i <= 35; $i++): ?>
                                                <option value="<?= str_pad($i, 2, 0, STR_PAD_LEFT); ?>"><?= str_pad($i, 2, 0, STR_PAD_LEFT); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="labelline">
                            <label class="label70">
                                <span>Nome impresso no cartão</span>
                                <input required type="text" id="nomeMp" data-checkout="cardholderName">
                            </label><div class="label30">
                                <label>
                                    <span>Código de segurança</span>
                                    <input required onkeypress="return wcIsNumeric(event)" data-checkout="securityCode" class="cvv" maxlength="4" type="text">
                                </label>
                            </div>
                        </div>
                        <div  style='display:none' class="workcontrol_carddata">
                          
                            <h3>Dados do titular do cartão</h3>
                            <label class="label50">
                                <span>Tipo de documento</span>
                                <select id="docType" data-checkout="docType">
                                    <option value="CPF" selected>CPF</option>
                                </select>
                            </label><div class="label50 last">
                                
                            </div>
                        </div>
                        <div style='padding-top:50px;' class="labelline labelactions">
                               <label class="label50 fl_left"><br/><br/>
                                <select required name="cardInstallmentQuantity" data-checkout="cardInstallmentQuantity" class="cardInstallmentQuantity">
                                    <option value="" disabled selected>Parcelas</option>
                                    <option value="" disabled>Informe o número do cartão para habilitar as parcelas</option>
                                </select>
                            </label> 
                         <label class="label50 last"><br/>
                                    <span>Nº do documento(CPF)</span>
                                    <input required onkeypress="return wcIsNumeric(event)" maxlength="11" type="text" id="docNumber" data-checkout="docNumber" class="">
                                </label>
                        <p style='display:none' class="loading">
                            <i class="fa fa-cog fa-spin fa-2x fa-fw"></i>
                            <span>Processando seu pagamento...</span>
                        </p>
                         <button style='margin-top:30px;' class="btn btn_green wc_button_cart fl_right">Pagar minha compra</button>
                        </div>
                        <div class="clear"></div>
                    </form>
                </div>

                <?php endif; ?>
                
                <div id="wc_form_billet" class="wc_toggle_container">
                    <form id="billet-mercado-pago" style="display: <?= (!ECOMMERCE_PAY_SPLIT ? 'block' : 'none'); ?>;" autocomplete="off" name="workcontrol_pagseguro" class="workcontrol_pagseguro workcontrol_pagseguro_billet" action="" method="post">
                        <input type="hidden" name="action" value="billet_pay">
                        <h3>Detalhes do pagamento por boleto</h3>
                        <p>Fique atento(a) ao vencimento do boleto. Você pode pagar o boleto em qualquer banco ou casa lotérica até o dia do vencimento. As compras efetuadas com boleto levam até 3 dias úteis para serem compensadas.</p>
                        <button class="btn btn_blue wc_button_cart fl_left">Gerar boleto</button>
                        <p class="loading">
                            <i class="fa fa-cog fa-spin fa-2x fa-fw"></i>
                            <span>Processando seu pagamento...</span>
                        </p>
                        <div class="clear"></div>
                    </form>
                </div>

                <div class="workcontrol_pagseguro_logo">
                    <img title="Pagamento processado pelo Mercado Pago" alt="Pagamento processado pelo Mercado Pago" src="../../_cdn/widgets/MercadoPago/mercadopago/mercadopago.gif">
                </div>
            </article><!-- /payment forms billet and cc -->
        </div>
        <?php
        }

        // Inclui o método de pagamento via paypal
        if (PAYPAL_PAYMENT || PAYPALCHECKOUT_PAYMENT) {
            require __DIR__ . '/paypal/paypal.inc.php';
        }

        if (PAYMENT_PAGSEGURO) { ?>
            <div class="wc_tab_target wc_active" id="wc_payment_pagseguro">
                <?php
                require __DIR__ . '/../ecommerce/PagSeguro/PagSeguroLibrary.php';

                $sessionId = null;
                $Yhash = substr(date("Y"), 0, 2);

                try {
                    $credentials = PagSeguroConfig::getAccountCredentials();
                    $sessionId = PagSeguroSessionService::getSession($credentials);
                    $_SESSION['wc_pagseguro'] = $sessionId;
                } catch (PagSeguroServiceException $e) {
                    Erro("Erro ao Processar Pagamento: Informe <b>{$e->getMessage()}</b> via " . AGENCY_EMAIL,
                        E_USER_ERROR);
                    $sessionId = null;
                }

                if (PAGSEGURO_ENV == 'sandbox'):
                    echo '<script type="text/javascript" src="https://stc.sandbox.pagseguro.uol.com.br/pagseguro/api/v2/checkout/pagseguro.directpayment.js"></script>';
                else:
                    echo '<script type="text/javascript" src="https://stc.pagseguro.uol.com.br/pagseguro/api/v2/checkout/pagseguro.directpayment.js"></script>';
                endif;

                require __DIR__ . '/../ecommerce/PagSeguroWc/Checkout.workcontrol.php';
                ?>
                <div class="workcontrol_load"><p class="load_message">Aguarde enquanto processamos o pagamento!</p>
                    <div class="workcontrol_load_content">
                        <div class="workcontrol_load_ajax"></div>
                        <span class="workcontrol_load_close">X Fechar</span></div>
                </div>

                <?php if (ECOMMERCE_PAY_SPLIT): ?>
                    <ul class="workcontrol_pay_tabs">
                        <li class="active" id="card">Cartão de Credito:</li><li id="billet">Boleto Bancário:</li>
                    </ul>

                    <form id="card" autocomplete="off" name="workcontrol_pagseguro" class="workcontrol_pagseguro"
                          action="" method="post">
                        <div class="labelline">
                            <label class="label70">
                                <span>Número do Cartão:</span>
                                <input required type="text" onkeypress="return wcIsNumericHit(event)"
                                       class="workcontrol_cardnumber" maxlength="22" name="cardNumber" id="cartao"
                                       placeholder="Número do cartão:"/>
                            </label><div class="label30 labelDate">
                                <span class="span">Data de Validade:</span>
                                <div class="labelline">
                                    <div class="month"><input required onkeypress="return wcIsNumericHit(event)"
                                                              maxlength="2" type="text" name="expirationMonth"
                                                              id="validadeMes" placeholder="MM"/>
                                    </div><div class="year">
                                        <input required onkeypress="return wcIsNumericHit(event)"
                                                             maxlength="2" type="text" name="expirationYear"
                                                             id="validadeAno" placeholder="YY"/></div>
                                </div>
                            </div>
                        </div>
                        <div class="labelline">
                            <label class="label70">
                                <span>Nome Impresso no Cartão:</span>
                                <input required type="text" name="cardName" id="nome"
                                       placeholder="Nome impresso no cartão:"/>
                            </label><div class="label30">
                                <label>
                                    <span>Código de Segurança:</span>
                                    <input required onkeypress="return wcIsNumericHit(event)" id="cvv" maxlength="4"
                                           type="text" name="cardCVV" placeholder="CVV:"/>
                                </label>
                            </div>
                        </div>

                        <div class="workcontrol_carddata">
                            <h3>Dados do Titular do Cartão:</h3>
                            <label class="label50 first">
                                <span>CPF:</span>
                                <input required onkeypress="return wcIsNumericHit(event)" type="text" class="formCpf"
                                       name="cardCPF" placeholder="CPF do titular do cartão:"/>
                            </label><div class="label50 last">
                                <label>
                                    <span>Data de Nascimento:</span>
                                    <input required onkeypress="return wcIsNumericHit(event)" type="text"
                                           class="formDate" name="cardBirthDate"
                                           placeholder="Data de nascimento do titular do cartão:"/>
                                </label>
                            </div>
                        </div>

                        <div class="labelline labelactions">
                            <label class="label50">
                                <select required name="cardInstallmentQuantity" id="cardInstallmentQuantity">
                                    <option value="" disabled selected>PARCELAMENTO:</option>
                                </select>
                            </label>
                            <button class="btn btn_green wc_button_cart fl_right">Comprar Agora!</button>
                        </div>
                        <div class="clear"></div>
                    </form>
                <?php endif; ?>

                <form id="billet" <?= (!ECOMMERCE_PAY_SPLIT ? 'style="display: block;"' : ''); ?> autocomplete="off"
                      name="workcontrol_pagseguro" class="workcontrol_pagseguro workcontrol_pagseguro_billet" action=""
                      method="post">
                    <div>
                        <h3>Detalhes de pagamento:</h3>
                        <p>Fique atento(a) ao vencimento do boleto. Você pode pagar o boleto em qualquer banco ou casa
                            lotérica até o dia do vencimento!</p>
                        <p>As compras efetuadas com boleto levam até 3 dias úteis para serem compensadas. Este prazo
                            deve ser estimado por você ao prazo de envio do produto!</p>
                        <h4>Valor a pagar: <b>R$ <?= number_format($order_price, '2', ',', '.'); ?></b></h4>
                    </div>
                    <div class="labelline" style="margin-top: 20px;">
                        <button class="btn btn_green wc_button_cart fl_right">Gerar Boleto!</button>
                    </div>
                    <div class="clear"></div>
                </form>

                <div class="workcontrol_pagseguro_logo"><img title="Pagamento processado pelo PagSeguro!"
                                                             alt="Pagamento processado pelo PagSeguro!"
                                                             src="<?= BASE; ?>/_cdn/widgets/ecommerce/PagSeguroWc/pagseguro.gif">
                </div>
            </div>
            <?php
        }

        if (PAYMENT_DEPOSIT) {
            // Inclui o método de pagamento via depósito
            require __DIR__ . '/deposit/deposit.inc.php';
        }
        ?>
    </div>

    <article class="wc_callbacks al_center" style="display: none;">  
        <div class="wc_pay_rejected wc_slide_up" style="display: none;">
            <div class="alert alert-danger">
                <p class="wc_icon"><i class="fa fa-meh-o fa-5x" area-hidden="true"></i></p>
                <h1>Ah não, <b><?= $_SESSION['userLogin']['user_name'] . ' ' . $_SESSION['userLogin']['user_lastname']; ?></b>!</h1>
                <h3>A sua operadora de cartão rejeitou o pagamento.</h3>
                <div class="wc_cc_reject_reason">
                    <p><b>Motivo:</b></p>
                    <p class="wc_write_reason"></p>
                </div>
                <p>Qualquer dúvida, entre em contato conosco :^]</p>
                <p class="toggle-pay"><a href="#" title="Selecionar outra forma de pagamento">Selecionar outra forma de pagamento</a></p>
            </div>
        </div>
        <div class="wc_pay_approved wc_slide_up" style="display: none;">
            <div class="alert alert-success">
                <p class="wc_icon"><i class="fa fa-smile-o fa-5x" area-hidden="true"></i></p>
                <h1>Parabéns, <b><?= $_SESSION['userLogin']['user_name'] . ' ' . $_SESSION['userLogin']['user_lastname']; ?></b>!</h1>
                <h3>Este produto foi liberado em sua conta.</h3>
                <p>Acompanhe os <a href="<?= BASE; ?>/conta/pedido/<?= $_SESSION['wc_payorder']['order_id']; ?>" target="_blank" title="Ver detalhes do pedido">detalhes do pedido</a> na sua conta.</p>
                <p>Qualquer dúvida, entre em contato conosco :^]</p>
            </div>
        </div>
        <div class="wc_billet_done wc_slide_up" style="display: none;">
            <div class="alert alert-success">
                <p class="wc_icon"><i class="fa fa-smile-o fa-5x" area-hidden="true"></i></p>
                <h1>Estamos quase lá <b><?= $_SESSION['userLogin']['user_name'] . ' ' . $_SESSION['userLogin']['user_lastname']; ?></b>!</h1>
                <h3>Realize o pagamento do boleto até a data de vencimento.</h3>
                <p class="button"><a href="" target="_blank" title="Acessar meu boleto">Acessar meu boleto</a></p>
                <p>Assim que o banco nos confirmar o pagamento, seu produto será liberado em sua conta. Você ainda pode acessar o boleto à qualquer momento em sua <a href="<?= BASE; ?>/conta/pedidos" title="Acessar meus pedidos" target="_blank">conta</a>. Qualquer dúvida, entre em contato conosco :^]</p>
                <p class="toggle-pay"><a href="#" title="Pagar com cartão de crédito">Pagar com cartão de crédito</a></p>
            </div>
        </div>
    </article><!-- /Callbacks -->
</div>
<?php if(empty( $_SESSION['mdpactive'])):
 $_SESSION['mdpactive'] = 1;
 endif;?>