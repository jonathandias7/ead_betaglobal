
<style>
    
/* products => modal */
.products_modal {
    
    -webkit-display: -webkit-box;
    -webkit-display: -webkit-flex;
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-justify-content: center;
    -webkit-box-pack: center;
    -moz-justify-content: center;
    -moz-flex-pack: center;
    -ms-justify-content: center;
    -ms-flex-pack: center;
    -o-justify-content: center;
    justify-content: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -moz-align-items: center;
    -ms-align-items: center;
    -ms-flex-align: center;
    -o-align-items: center;
    align-items: center;
    width: 100vw;
    height: calc(100vh - 96px);
    position: fixed;
    background-color: rgba(0, 0, 0, 0.7);
    z-index: 998;
}

.products_modal_content {
    width: 90%;
    height: 90%;
    position: relative;
    background-color: #ffffff;
}

.products_modal_content .product {
    max-height: calc(100% - 45px);
    overflow-y: auto;
    border-top: 10px solid #ffffff;
    border-bottom: 10px solid #ffffff;
}

.products_modal_content .product::-webkit-scrollbar {
    width: 5px;
    background-color: #ffffff;
}

.products_modal_content .product::-webkit-scrollbar-thumb {
    background-color: transparent;
    -webkit-box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    -moz-box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    -ms-box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    -o-box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.3);
    -moz-box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.3);
    -ms-box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.3);
    -o-box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.3);
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.3);
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    -ms-border-radius: 5px;
    -o-border-radius: 5px;
    border-radius: 5px;
}

.products_modal_content .product .content {
    width: 95%;
    padding: 0;
}

.products_modal_content_close.modal_pdt_mobile {
    background-color: var(--color-background-one);
    padding: 10px;
    text-align: center;
}

.products_modal_content_close.modal_pdt_mobile span {
    display: inline-block;
    font-size: 0.8em;
    color: var(--color-background-one);
    font-weight: bold;
    text-decoration: none;
    text-transform: uppercase;
    background-color: #ffffff;
    padding: 5px 20px;
    -webkit-border-radius: 5px;
    -moz-border-radius: 5px;
    -ms-border-radius: 5px;
    -o-border-radius: 5px;
    border-radius: 5px;
        background:red;
}

.products_modal_content_close.modal_pdt_mobile span:hover {
    cursor: pointer;
}

.products_modal_content_close.modal_pdt_desktop {
    display: none;
    -webkit-justify-content: center;
    -webkit-box-pack: center;
    -moz-justify-content: center;
    -moz-flex-pack: center;
    -ms-justify-content: center;
    -ms-flex-pack: center;
    -o-justify-content: center;
    justify-content: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -moz-align-items: center;
    -ms-align-items: center;
    -ms-flex-align: center;
    -o-align-items: center;
    align-items: center;
    width: 40px;
    height: 40px;
    position: absolute;
    top: -20px;
    left: -20px;
    background-color: #f1f1f1;
    -webkit-border-radius: 50%;
    -moz-border-radius: 50%;
    -ms-border-radius: 50%;
    -o-border-radius: 50%;
    border-radius: 50%;
    -webkit-transition: transform 0.3s ease-in-out;
    -moz-transition: transform 0.3s ease-in-out;
    -ms-transition: transform 0.3s ease-in-out;
    -o-transition: transform 0.3s ease-in-out;
    transition: transform 0.3s ease-in-out;
}

.products_modal_content_close.modal_pdt_desktop:hover {
    -webkit-transform: scale(1.05);
    -moz-transform: scale(1.05);
    -ms-transform: scale(1.05);
    -o-transform: scale(1.05);
    transform: scale(1.05);
    cursor: pointer;
}

.products_modal_content_close.modal_pdt_desktop i {
    font-size: 1.875em;
    color: var(--color-background-one);
}
</style>
 <div style='display:none;' class='products_modal'>
	  <div class='products_modal_content'>
	        <div style='color:#fff;' class='products_modal_content_close modal_pdt_mobile'>
		  <img style='float:left;background-size:3%; max-height:40px;'src="<?= INCLUDE_PATH?>/images/logo.png" alt="" /><b style='color:#000' title='Clique em painel Admin(Demo)'> Dados de acesso Painel Admin(demo) | Email: </b> <a style='font-size:1.5em;color:#00b594' title='e-mail do usuario demonstrativo '> demo@mdape.net </a><b style='color:#000'> | Senha:</b> <a style='font-size:1.5em;color:#00b594'   title='e-mail do usuario demonstrativo '> mdpadmindemo</a><span style='float:right' class='j_close_modal_pdp' title='Fechar'>Fechar </span> 
          </div>
 
	      
	      <div style='height:100%;' class='mdp_content'></div>
	  
    
	 </div>
</div>


 