<?php

 if(!empty($URL[0])):
 require REQUIRE_PATH . '/inc/comprovamdp.php';
 endif;


?>

