<?php
require '_cdn/widgets/ecommerce/PagSeguro/PagSeguroLibrary.php';

//variaveis do modal


$u = (!empty($_SESSION['mdp_dep_or']['user_id']) ? $_SESSION['mdp_dep_or']['user_id'] : null);
//$or = $_SESSION['wc_order'];

$DOId = (!empty($_SESSION['mdp_dep_or']['dep_or_id']) ? $_SESSION['mdp_dep_or']['dep_or_id']: null);
$User = "{$_SESSION['userLogin']['user_name']} {$_SESSION['userLogin']['user_lastname']}";

$sessionId = null;
$Yhash = substr(date("Y"), 0, 2);

try {
    $credentials = PagSeguroConfig::getAccountCredentials();
    $sessionId = PagSeguroSessionService::getSession($credentials);
    $_SESSION['wc_pagseguro'] = $sessionId;
} catch (PagSeguroServiceException $e) {
    Erro("Erro ao Processar Pagamento: Informe <b>{$e->getMessage()}</b> via " . AGENCY_EMAIL, E_USER_ERROR);
    $sessionId = null;
}

if (PAGSEGURO_ENV == 'sandbox'):
    echo '<script type="text/javascript" src="https://stc.sandbox.pagseguro.uol.com.br/pagseguro/api/v2/checkout/pagseguro.directpayment.js"></script>';
else:
    echo '<script type="text/javascript" src="https://stc.pagseguro.uol.com.br/pagseguro/api/v2/checkout/pagseguro.directpayment.js"></script>';
endif;

require 'Checkout.workcontrol.php';
?>



<!-------------------------------------------------------------------------------------------------------------->
<div id="db" style='display: none; text-align: right; margin: 20px 0 0 0;'><a class='btn btn_blue' title='Dados bancarios' href="<?=  BASE ?>/conta" target='_blank'>DADOS BANCARIOS PARA PAGAMENTO!</a></div>

<div style="display:none" class="wc_boxs">
	         <!--AVALIÇÃO MODAL(QUESTIONARIO)-->
             
			 <div class="wc_box_modal mdp_deposito">
                <span class="icon-cross icon-notext wc_box_modal_close"></span>
                <div class="wc_box_modal_content">
				 
				  <p  class="wc_box_modal_title">PEDIDO VIA DEPOSITO/TRANSFERENCIA:</p>
                    <form class="wc_form_var jwc_form_news" name="dep_add" action="" method="POST" enctype="multipart/form-data">
                       <input type="hidden" name="callback" value="MDPDepT"/>
					   <input type="hidden" name="callback_action" value="dep_cart"/>
						
					  <input type="hidden" name="user_id" value="<?= $u?>"/>
					   <input type="hidden" name="dep_or_id" value="<?= $DOId?>"/>
                      
						<div style="margin:10px 0 10px 0;" class="label_100">
					
								
					  <div class="jwc_return"></div>
						<div style="color:#fff;margin:10px;background:#158496" class="exchange_content">
						
				<h2 class="icon-info" style="text-align:center;padding:10px;font-size:1.5em"><b> INFORMAÇÕES:</b></h2><p style="font-size:1.2em;color:#fff"  class='al_center ds_block'>Caro(a) <b style="font-size:1.3em"><?= $User?></b> você selecionou a forma de pagamento: <br/><b style="font-size:1.3em"> Deposito ou Transferência Bancária</b><br/>Clique em finalizar para fechar o pedido e ir para página de pagamento.</p>
				<br/>
				</div> 
						</div>
				
                        <div style="padding-right:1%;"class="al_right wc_actions">
							<button id="ini" style="background:#158496;" class="btn  btn_medium icon-checkmark">Fechar o Pedido </button> 
                            <button id="fim" style="background:#00b594;display:none;" class="btn  btn_medium icon-checkmark">Concluir a compra </button>
                           <script>
					$(function(){
						$('#ini').click(function(){
							$('p .wc_box_modal_title').css({'background':'#00b594'});
							$('#ini').fadeOut(900);
								$('.exchange_content').fadeOut(1200);
							$('#fim').fadeIn(2000);
							
							$('#fim').click(function(){
						
						 $('.wc_boxs').fadeOut(400, function () {
							$(this).find('.wc_box_modal').fadeOut(200, function () {
								$(".trigger_ajax").remove();
								
									
							});
						});
							$('#db').fadeIn(2000);	
						$('ul, li, .mdp_dep, form').fadeOut(900);
						$('.wc_box_modal_title').css({'background':'#00b594'});
						
							
							
							
							});	
							
						});
                    
					});
					</script>
							
						   <img class="wc_load" style="display:none;" src="<?= BASE; ?>/_cdn/widgets/contact/images/load.gif" alt="Cadastrando usuário!" title="Cadastrando usuário!"/>
                        </div>
						<br/>
					
                    </form>
                </div>
            </div> 
		</DIV>   

<!-------------------------------------------------------------------------------------------------------------->
<div class="workcontrol_load"><p class="load_message">Aguarde enquanto processamos o pagamento!</p><div class="workcontrol_load_content"><div class="workcontrol_load_ajax"></div><span class="workcontrol_load_close">X Fechar</span></div></div>

<?php if (ECOMMERCE_PAY_SPLIT): ?>
<a id="ted" class="btn btn_green mdp_dep" style="width:100%;font-size:1.3em;margin-bootom:10px;">Deposito ou Transferencia</a>
    <ul class="workcontrol_pay_tabs">
	
        <li class="active" id="card">Cartão de Credito:</li><li id="billet">Boleto Bancário:</li>
    </ul>

    <form id="card" autocomplete="off" name="workcontrol_pagseguro" class="workcontrol_pagseguro" action="" method="post">
        <div class="labelline">
            <label class="label70">
                <span>Número do Cartão:</span>
                <input required type="text" onkeypress="return wcIsNumericHit(event)" class="workcontrol_cardnumber" maxlength="22" name="cardNumber" id="cartao" placeholder="Número do cartão:"/>
            </label><div class="label30 labelDate">
                <span class="span">Data de Validade:</span>
                <div class="labelline">
                    <div class="month"><input required onkeypress="return wcIsNumericHit(event)" maxlength="2" type="text" name="expirationMonth" id="validadeMes" placeholder="MM"/></div><div class="year"><input required onkeypress="return wcIsNumericHit(event)" maxlength="2" type="text" name="expirationYear" id="validadeAno" placeholder="YY"/></div>
                </div>
            </div>
        </div>
        <div class="labelline">
            <label class="label70">
                <span>Nome Impresso no Cartão:</span>
                <input required type="text" name="cardName" id="nome" placeholder="Nome impresso no cartão:"/>
            </label><div class="label30">
                <label>
                    <span>Código de Segurança:</span>
                    <input required onkeypress="return wcIsNumericHit(event)" id="cvv" maxlength="4" type="text" name="cardCVV" placeholder="CVV:"/>
                </label>
            </div>
        </div>

        <div class="workcontrol_carddata">
            <h3>Dados do Titular do Cartão:</h3>
            <label class="label50 first">
                <span>CPF:</span>
                <input required onkeypress="return wcIsNumericHit(event)" type="text" class="formCpf" name="cardCPF" placeholder="CPF do titular do cartão:"/>
            </label><div class="label50 last">
                <label>
                    <span>Data de Nascimento:</span>
                    <input required onkeypress="return wcIsNumericHit(event)" type="text" class="formDate" name="cardBirthDate" placeholder="Data de nascimento do titular do cartão:"/>
                </label>
            </div>
        </div>

        <div class="labelline labelactions">
            <label class="label50">
                <select required name="cardInstallmentQuantity" id="cardInstallmentQuantity">
                    <option value="" disabled selected>PARCELAMENTO:</option>
                </select>
            </label>
            <button class="btn btn_green wc_button_cart fl_right">Comprar Agora!</button>
        </div>
        <div class="clear"></div>
    </form>
<?php endif; ?>

<form id="billet" <?= (!ECOMMERCE_PAY_SPLIT ? 'style="display: block;"' : ''); ?> autocomplete="off" name="workcontrol_pagseguro" class="workcontrol_pagseguro workcontrol_pagseguro_billet" action="" method="post">
    <div>
        <h3>Detalhes de pagamento:</h3>
        <p>Fique atento(a) ao vencimento do boleto. Você pode pagar o boleto em qualquer banco ou casa lotérica até o dia do vencimento!</p>
        <p>As compras efetuadas com boleto levam até 3 dias úteis para serem compensadas. Este prazo deve ser estimado por você ao prazo de envio do produto!</p>
        <h4>Valor a pagar: <b>R$ <?= number_format($order_price, '2', ',', '.'); ?></b></h4>
    </div>
    <div class="labelline" style="margin-top: 20px;">
        <button class="btn btn_green wc_button_cart fl_right">Gerar Boleto!</button>
    </div>
    <div class="clear"></div>
</form>


<!--NÃO REMOVA A LOGO PAGSEGURO, É UMA REGRA DE UTILIZAÇÃO DO CHECKOUT!-->
<script src="<?= BASE;?>/_cdn/js/mdpdep.js"></script>
<div class="workcontrol_pagseguro_logo"><img title="Pagamento processado pelo PagSeguro!" alt="Pagamento processado pelo PagSeguro!" src="<?= BASE; ?>/_cdn/widgets/ecommerce/PagSeguroWc/pagseguro.gif"></div>