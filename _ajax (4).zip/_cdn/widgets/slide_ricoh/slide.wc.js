$(function () {
    var WorkControlSlideSeccont = $('.workcontroltime').attr('id');
    var WorkControlSlideAuto = setInterval(WorkControlSlideGO, parseInt(WorkControlSlideSeccont) * 1000);

    //SLIDE SLIDES
    function WorkControlSlideGO() {
        if ($('.nivoSlider.first').next('.nivoSlider').size()) {
            var WcSlideBg = $('.nivoSlider.first').next('.nivoSlider').find('img').attr('src');
            $('.slider-container').css({
                'background-image': 'url(' + WcSlideBg + ')',
                'background-size': '100% auto',
                'background-repeat': 'no-repeat'
            });
            $('.nivoSlider.first').fadeOut(400, function () {
                $(this).removeClass('first').next().fadeIn(400).addClass('first');
                WorControlSlideMark();
            });
        } else if ($('.nivoSlider').length > 1) {
            var WcSlideBg = $('.nivoSlider:eq(0)').find('img').attr('src');
            $('.slider-container').css({
                'background-image': 'url(' + WcSlideBg + ')',
                'background-size': '100% auto',
                'background-repeat': 'no-repeat'
            });

            $('.nivoSlider.first').fadeOut(400, function () {
                $('.nivoSlider').removeClass('first');
                $('.nivoSlider:eq(0)').fadeIn(400).addClass('first');
                WorControlSlideMark();
            });
        }
    }

    //SLIDE PAGER
    function WorControlSlideMark() {
        var wcSlideTHis = $('.nivoSlider.first').index() - 1;
        $('.nivo-control span').removeClass('active');
        $('.nivo-control span:eq(' + wcSlideTHis + ')').addClass('active');
    }

    //PAGER ACTION
    $('.nivo-control span').click(function () {
        $('.nivoSlider').stop();
        clearInterval(WorkControlSlideAuto);

        if (!$(this).hasClass('active')) {
            var WcMark = $(this).index();
            $('.nivo-control span').removeClass('active');
            $(this).addClass('active');

            var WcSlideBg = $('.nivoSlider:eq(' + WcMark + ')').find('img').attr('src');
            $('.slider-container').css({
                'background-image': 'url(' + WcSlideBg + ')',
                'background-size': '100% auto',
                'background-repeat': 'no-repeat'
            });

            $('.nivoSlider.first').fadeOut(400, function () {
                $('.nivoSlider').removeClass('first');
                $('.nivoSlider:eq(' + WcMark + ')').fadeIn(400).addClass('first');
            });
        }
    });

    //MOUSE STOP
    $('.nivo-control').mouseenter(function () {
        clearInterval(WorkControlSlideAuto);
    }).mouseleave(function () {
        WorkControlSlideAuto = setInterval(WorkControlSlideGO, WorkControlSlideSeccont * 1000);
    });
});