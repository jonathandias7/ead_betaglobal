<?php

echo '<div class="workcontroltime" id="' . (!empty($SlideSeconts) ? $SlideSeconts : 3) . '"></div>';
//'<link rel="stylesheet" href="' . BASE . '/_cdn/widgets/slide_ricoh/slide.wc.css"/>';
echo '<script src="' . BASE . '/_cdn/widgets/slide_ricoh/slide.wc.js"></script>';

$Read = new Read;
$Read->ExeRead(DB_SLIDES, "WHERE slide_status = 1 AND slide_start <= NOW() AND (slide_end >= NOW() OR slide_end IS NULL) ORDER BY slide_date DESC");
if ($Read->getResult()):
    $i_slide = 1;
    echo "<div class='slider-container overlay'>";
    foreach ($Read->getResult() as $Slide):
        extract($Slide);
        $SlideLink = (strstr($slide_link, 'http') ? $slide_link : BASE . "/{$slide_link}");
        $SlideTarget = (strstr($slide_link, 'http') ? ("target='_blank'") : null);
		
   echo "<div id='mainSlider' class='nivoSlider slider-image'><a {$SlideTarget} title='{$slide_title}' href='{$SlideLink}'><img title='#htmlcaption".($i_slide == 1 ? 'first' : $i_slide) . "' alt='{$slide_title}' src='" . BASE . "/tim.php?src=uploads/{$slide_image}&w=" . SLIDE_W . "&h=" . SLIDE_H . "'/></a>
			<div id='htmlcaption".($i_slide == 1 ? 'first' : $i_slide) . "' class='nivo-html-caption slider-caption-".($i_slide == 1 ? 'first' : $i_slide) . "'>
				<div class='col-md-12 col-md-offset-1 col-sm-12 col-xs-12'>
					<div class='slider-text-table'>
						<div class='slider-text-tablecell'>
							<div class='container-fluid'>
								<div class='row'> 
									<div class='hidden-xs social-media-follow'>
										<div class='social-box-inner'>
											<ul>
												<li><a href='#'><i class='zmdi zmdi-facebook'></i></a></li>
												<li><a href='#'><i class='zmdi zmdi-twitter'></i></a></li>
												<li><a href='#'><i class='zmdi zmdi-dribbble'></i></a></li>
												<li><a href='#'><i class='zmdi zmdi-pinterest'></i></a></li>
												<li><a href='#'><i class='zmdi zmdi-instagram'></i></a></li>
											</ul>	
										</div>
									</div>
									<div class='col-md-12 col-md-offset-1 col-sm-12 col-xs-12'>
										<div class='slide-text'>
											<div class='middle-text'>
												<div class='title-1 wow slideInUp' data-wow-duration='0.9s' data-wow-delay='0s'>
													<h2><a {$SlideTarget} title='{$slide_title}' href='{$SlideLink}'>{$slide_title}</a></h2>
												</div>
												<div class='desc wow slideInUp' data-wow-duration='1.1s' data-wow-delay='.3s'>
													<p>{$slide_desc}</p>
												
												</div>	
												
												<div class='learn-more wow slideInUp' data-wow-duration='1.3s' data-wow-delay='.3s'>
													<a href='{$SlideLink}'>Saiba Mais</a>
												</div>	
											</div>
										</div>
									<div class='slide-caption-img slideInUp animated' data-wow-delay='1.2s' data-wow-duration='0.5s'><div style='padding: 200px;'></div></div>	
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			</div></div>";
        $i_slide ++;
    endforeach;

    if ($Read->getRowCount() > 1):
        echo "<div class='nivo-control'>";
        echo "<span class='active'></span>";
        echo str_repeat("<span></span>", $Read->getRowCount() - 1);
        echo "</div>";
    endif;
    echo "<div class='clear'></div>";
    echo "</div>";
endif;