 //FECHA MODAL
    $('.wc_box_modal_close').click(function () {
        $('.wc_boxs').fadeOut(400, function () {
            $(this).find('.wc_box_modal').fadeOut(200, function () {
                $(".trigger_ajax").remove();
            });
        });
    });

    
    //ABRE CADASTRO
    $('.cta_evento').click(function () {
        $('.wc_boxs').fadeIn().css('display', 'flex').find('.mdp_newsletter').fadeIn();
    });
    
    $(window).load(function(){
        $('.wc_form').trigger('click');
        var Form = $(this);
        var Action = Form.find('input[name="callback"]').val();
        var Data = Form.serialize();
		

      $.ajax({
            url: BASE +"/_ajax/"+ Action + ".ajax.php",
            data: Data,
            type: 'POST',
            dataType: 'json',
            beforeSend: function (xhr) {
                Form.find(".wc_load").fadeIn();
                $(".jwc_return").fadeOut();
            },
            success: function (data) {
                if (data.trigger) {
                    setTimeout(function () {
                        $('.jwc_return').html(data.trigger).fadeIn();
                    }, 500);
                      setTimeout(function () {
                           $('.jwc_return').fadeOut();
                           if (data.inscricao) {
                       
                           window.location.reload(true);
                    
                          }
                    }, 3500);
                }
				
			
                  
                 if (data.valida) {
                 
                 $('#um').css({'display':'none'});
                 $('#dois').fadeIn();
                 
                 }
                 
                  if (data.exibe) {
                  $('#dois').css({'display':'none'});
                  $('#um').fadeIn();
                 
        
                 }
                 
                if (data.content) {
                     $('.nofilter').css({'display':'none'});
                      $('.jwc_content').html(data.content).fadeIn();
                      $('.baixar').fadeIn();
              
                }
					
			
                if (data.clear) {
                    Form.trigger('reset');
                }


                Form.find(".wc_load").fadeOut();
			
            }
        }); 
        return false;
  
        
    });
    
    
$('html').on('submit','.mdp_form',function(){
        var Form = $(this);
        var Action = Form.find('input[name="callback"]').val();
        var Data = Form.serialize();
		

      $.ajax({
            url: BASE +"/_ajax/"+ Action + ".ajax.php",
            data: Data,
            type: 'POST',
            dataType: 'json',
            beforeSend: function (xhr) {
                Form.find(".wc_load").fadeIn();
                $(".jwc_return").fadeOut();
            },
            success: function (data) {
                if (data.trigger) {
                    setTimeout(function () {
                        $('.jwc_return').html(data.trigger).fadeIn();
                    }, 500);
                      setTimeout(function () {
                           $('.jwc_return').fadeOut();
                           if (data.inscricao) {
                       
                           window.location.reload(true);
                    
                          }
                    }, 3500);
                }
				
			
                  
                
                 
                if (data.mdpcontent) {
                     
                 if (data.typeform) {
                       if (data.typeforms) {
                         $('.lproducts_modal').fadeIn();
                      $('.mdp_content_form').html(data.mdpcontent).fadeIn();
                     }else{
                          $('.mproducts_modal').fadeIn();
                      $('.mdp_content_form').html(data.mdpcontent).fadeIn();
                     }
                     }else{
                     $('.products_modal').fadeIn();
                       $('.mdp_content').html(data.mdpcontent).fadeIn();
                     }
                     
                }
					 if (data.content) {
                         $('.mdp_content_form').fadeOut();
                          $('.jwc_content').html(data.content).fadeIn();
                          
                      }
			
                if (data.clear) {
                    Form.trigger('reset');
                }


                Form.find(".wc_load").fadeOut();
			
            }
        });  
        return false;
  


});

     $('.wc_form').submit(function () {
        var Form = $(this);
        var Action = Form.find('input[name="callback"]').val();
        var Data = Form.serialize();
		

      $.ajax({
            url: BASE +"/_ajax/"+ Action + ".ajax.php",
            data: Data,
            type: 'POST',
            dataType: 'json',
            beforeSend: function (xhr) {
                Form.find(".wc_load").fadeIn();
                $(".jwc_return").fadeOut();
            },
            success: function (data) {
                if (data.trigger) {
                    setTimeout(function () {
                        $('.jwc_return').html(data.trigger).fadeIn();
                    }, 500);
                      setTimeout(function () {
                           $('.jwc_return').fadeOut();
                           if (data.inscricao) {
                       
                           window.location.reload(true);
                    
                          }
                    }, 3500);
                }
				
			
                  
                 if (data.valida) {
                 
                 $('#um').css({'display':'none'});
                 $('#dois').fadeIn();
                 
                 }
                 
                  if (data.exibe) {
                  $('#dois').css({'display':'none'});
                  $('#um').fadeIn();
                 
        
                 }
                 
                if (data.content) {
                     $('.nofilter').css({'display':'none'});
                      $('.jwc_content').html(data.content).fadeIn();
                       $('.baixar').fadeIn();
              
                }
					
			
                if (data.clear) {
                    Form.trigger('reset');
                }


                Form.find(".wc_load").fadeOut();
			
            }
        }); 
        return false;
  

});
 $('html').on('click','#entrar', function(){
    $('#contentcreate').css({'display':'none'});
    $('#contentlogin').css({'display':'block'});
    $('#cadastrar').removeClass('btn_green');   
    $('#entrar').addClass('btn_green');    
    });
 $('html').on('click','#cadastrar',function(){
      $('#contentlogin').css({'display':'none'});
       $('#contentcreate').css({'display':'block'});
      $('#entrar').removeClass('btn_green');   
      $('#cadastrar').addClass('btn_green');  
    });
    $('html').on('click', '.j_close_modal_pdp', function () {
         $('.products_modal').fadeOut();
          $('.mproducts_modal').fadeOut();
           $('.lproducts_modal').fadeOut();
    });
    
   