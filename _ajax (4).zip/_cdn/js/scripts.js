$(function () {
    //EVENTOS RESPOSTA
	
	
	

	
	
		 
	
	
    //FECHA MODAL
    $('.wc_box_modal_close').click(function () {
        $('.wc_box').fadeOut(400, function () {
            $(this).find('.wc_box_modal').fadeOut(200, function () {
                $(".trigger_ajax").remove();
            });
        });
    });

    //ABRE CADASTRO
    $('.mdp_news').click(function () {
        $('.wc_box').fadeIn().css('display', 'flex').find('.mdp_newslleter').fadeIn();
    });

	   $('.mdp_curr').click(function () {
        $('.wc_box').fadeIn().css('display', 'flex').find('.mdp_curriculo').fadeIn();
    });
	
 	 //ABRE OP
   
    //AÇÃO PADRÃO DE FORMULÁRIO
    $('.wc_form').submit(function () {
        var Form = $(this);
        var Action = Form.find('input[name="callback"]').val();
        var Data = Form.serialize();
		

      $.ajax({
            url: BASE+"/_ajax/"+ Action + ".ajax.php",
            data: Data,
            type: 'POST',
            dataType: 'json',
            beforeSend: function (xhr) {
                Form.find(".wc_load").fadeIn();
                $(".jwc_return").fadeOut();
            },
            success: function (data) {
                if (data.trigger) {
                    setTimeout(function () {
                        $('.jwc_return').html(data.trigger).fadeIn();
                    }, 500);
                }
				
			

                if (data.content) {
                    $('.').before(data.content);
                }
					
			
                if (data.clear) {
                    Form.trigger('reset');
                }


                Form.find(".wc_load").fadeOut();
			
            }
        }); 
        return false;
    });
	
	
});