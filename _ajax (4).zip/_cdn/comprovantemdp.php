<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

             
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      
    </head>

    <body>

      
        
<?php

 //$type = filter_input(INPUT_GET, 'type', FILTER_DEFAULT);
 //$OId = filter_input(INPUT_GET, 'tkt', FILTER_DEFAULT);
 //if(!empty($type) && !empty($OId)):
 $type = 1;
 $OId = "112";
 
switch($type):
case '1':
$orctype = "Desenvolvimento";
break;
case '2':
$orctype = "Customização";
break;
case '3':
$orctype = "Manutenção";
break;
case '4':
$orctype = "Upgrade";
break;
endswitch;


/*
 * EXECUTE THIS 1X HOUR
 */

if (!function_exists('MyAutoLoad')):
    require '../_app/Config.inc.php';
endif;


    if (empty($Read)):
        $Read = new Read;
    endif;
    if (empty($Update)):
        $Update = new Update;
    endif;

    
       // $Read->ExeRead(DB_ORDERS, "WHERE order_id = :id AND year(order_date) = year(NOW()) AND month(order_date) >= month(NOW()) AND day(order_date) >= day(NOW()) ORDER BY date(order_date) DESC, order_status","id={$OId}");
          // if ($Read->getResult()):
               
            //   extract($Read->getResult()[0]);
             //$url =  BASE ."/conta/pedido/{$order_id}#acc";
            
             // if($type == 1):
       
              /*if($order_status != '3'):
                  
                   ?>
                   <script>alert('Ops, algo deu errado. Tente novamente mais tarde...');window.location.href="<?=$url?>";</script>
                 <?php
                 
                 endif;
               $Read->ExeRead("mdp_embarque_setup"," WHERE set_embarque_id = :id","id={$set_embarque_id}"); 
                  if ($Read->getResult()):
                      
                      $setOrder = $Read->getResult()[0];
                      extract($Read->getResult()[0]);
                      
                  endif;
                  
                 $Read->FullRead("SELECT * FROM mdp_ponto_desembarque WHERE embarque_id = :id","id={$setOrder['embarque_id']}");
									 if ($Read->getResult()):
									    
									$desemb = $Read->getResult()[0];
									 endif;
									 
                        	 $Read->FullRead("SELECT * FROM mdp_ponto_embarque WHERE embarque_id = :id AND embarque_status = 1","id={$setOrder['embarque_id']}");
									 if ($Read->getResult()):
									     
									 $embks = $Read->getResult()[0];
									 endif;
									
									$Read->FullRead("SELECT * FROM app_cidades WHERE cidade_id = :id","id={$embks['cidade_id']}");
									 if ($Read->getResult()):
									 $embs = $Read->getResult()[0];
									 endif;
									 
									 $Read->FullRead("SELECT * FROM mdp_ponto_embarque WHERE embarque_id = :id AND embarque_status = 1","id={$desemb['embarque_dest_id']}");
									 if ($Read->getResult()):
									 $embk = $Read->getResult()[0];
									 endif;
									
									$Read->FullRead("SELECT * FROM app_cidades WHERE cidade_id = :id","id={$embk['cidade_id']}");
									 if ($Read->getResult()):
									     
									 $emb = $Read->getResult()[0];
									 endif;
									 
									$Read->ExeRead("mdp_reserva"," WHERE set_embarque_id = :id AND year(reserva_date) = year(NOW()) AND month(reserva_date) = month(NOW()) AND day(reserva_date) = day(NOW()) AND order_id = :u ORDER BY acento_id ASC", "id={$set_embarque_id}&u={$order_id}");
			if($Read->getResult()):
			foreach($Read->getResult() as $acento):			  	
                              
   */ 
   $user_name = "Fabio";
   $user_lastname = "Carvalho";
   $user_email = "fccarvalho@gmail.com";
   $user_tel = "(32) 9 9999-9999";
   
   ?>
    <div class='row qrcode' style='width:27.9cm;height:29cm;background: linear-gradient(to right, #05c2f9,#0E96E5);'>
    <div class='center-align col s12' style='padding:20px 0 0 0'>
         <img style='width:180px;height:180px;'src='<?= INCLUDE_PATH ."/images/logo.png";?>'>
    </div>
      <div class='center-align col s12'>
          <h4 style='color:#fff;'>COMPROVANTE</h4>
          <h1 style='color:#fff;margin-top:-10px'><b>#<?= str_pad($OId, 7, 0, 0);?></b></h1>
     </div>
       
               <div class='center-align col s12  '>
         
          <div class='row center-align col s12 ' style='margin:20px auto;background: linear-gradient(to right, #FbFbFb,#FbFbFb);'>
                 <table  class='centered'>
      
        <thead>
          <tr>
              
                <th>Solicitante</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Finalidade</th>
          </tr>
        </thead>
        <tbody>
           <tr style='background:#fff'>
        
             <td><?= $user_name;?> <?= $user_lastname;?> </td>

        <td><?= $user_email;?></td>
        <td><?= $user_tel;?></td>
        <td style='color:red;'><?= $orctype;?></td>
          </tr>
        </tbody>
        </table>
        
          <table class='centered'>
      
       <thead>
         <tr>
        
              
              <th>Ponto<br/>(<b>Embarque</b>)</th>
              <th>Ponto<br/>(<b>Desembarque</b>)</th>
              <th>Data<br/>(<b>Agendada</b>)</th>
          </tr>
        </thead>

        <tbody>
          <tr style='background:#fff'>
          <td>tttt<!--<?= $embks['embarque_title'];?>--></td>
            <td>aaaaa<!--<?= $embk['embarque_title'];?>--></td>
            <td>nnnnn<!--<b><?= date('d/m/Y', strtotime($order_date));?><b>--></td>
          </tr>
        </tbody>
         <thead>
          <tr style='background:#f5f5f5'>
        
              
              <th>Horario</th>
              <th>Duração</th>
               <th>Valor</th>
          </tr>
           <tbody>
          <tr style='background:#fff'>
          <td>ccccccc<!--<b><?= $set_embarque_tempo;?> Horas<b>--></td>
            <td>ddddd<!--<b><?= $set_embarque_time;?> Horas<b>--></td>
            <td>R$: <!--<b style='color:green'><?= number_format($order_price,2,',','.');?><b>--></td>
          </tr>
        </tbody>
        </thead>
         <tr style='background:#f5f5f5'>
        
              
              <th>Acento</th>
               <th>Pedido<br/>(<b>Total</b>)</th>
               <th>Valor<br/>(<b>Unitario</b>)</th>
          </tr>
         
         </thead>
           <tbody>
          <tr style='background:#fff'>
          <td><!--<b><?= $acento['acento_id'];?><b>--></td>
            <td>R$: <!--<b><?= number_format($order_price,2,',','.');?><b>--></td>
            <td>R$: <!--<b style='color:green'><?= number_format($set_embarque_price,2,',','.');?><b>--></td>
        
          </tr>
        </tbody>
       
     
      </table>
      <div id='qrcode<? /* $acento['acento_id'];*/?>' style='background:#f5f5f5;padding:auto;padding:10% 5% 10% 15%;' class='center-align'  ></div>
     
            
       </div>
          <h5 style='color:#fff;padding-bottom:10px'><B><?= SITE_ADDR_SITE;?></B></h5>
              <h6 style='color:#fff;margin-top:15px;border-top:1px #fff solid;padding-bottom:10px;'><br/> <B>MDP SOFTWARES LTDA<br/></b></h6>
     </div>
    </div>
     <!--<script src="<?= BASE;?>/_cdn/widgets/account/qrcode.js"></script>

      <script type="text/javascript">
new QRCode(document.getElementById("qrcode<?= $acento['acento_id'];?>"), "<?= BASE;?>/login/dashboard.php?wc=home&orid=<?= $OId;?>&acnt=<?= $acento['reserva_id'];?>");

</script>
    
     <?php  /*   
     endforeach;
     endif;
     else:
       if ($order_status == '6' || $order_status == 'approved' || $order_status == '1'):
               
               $Read->ExeRead("mdp_embarque_setup"," WHERE set_embarque_id = :id","id={$set_embarque_id}"); 
                  if ($Read->getResult()):
                      $setOrder = $Read->getResult()[0];
                      extract($Read->getResult()[0]);
                      
                  endif;
                  
                 $Read->FullRead("SELECT * FROM mdp_ponto_desembarque WHERE embarque_id = :id","id={$setOrder['embarque_id']}");
									 if ($Read->getResult()):
									    
									$desemb = $Read->getResult()[0];
									 endif;
									 
                        	 $Read->FullRead("SELECT * FROM mdp_ponto_embarque WHERE embarque_id = :id AND embarque_status = 1","id={$setOrder['embarque_id']}");
									 if ($Read->getResult()):
									 $embks = $Read->getResult()[0];
									 endif;
									
									$Read->FullRead("SELECT * FROM app_cidades WHERE cidade_id = :id","id={$embks['cidade_id']}");
									 if ($Read->getResult()):
									 $embs = $Read->getResult()[0];
									 endif;
									 
									 $Read->FullRead("SELECT * FROM mdp_ponto_embarque WHERE embarque_id = :id AND embarque_status = 1","id={$desemb['embarque_dest_id']}");
									 if ($Read->getResult()):
									 $embk = $Read->getResult()[0];
									 endif;
									
									$Read->FullRead("SELECT * FROM app_cidades WHERE cidade_id = :id","id={$embk['cidade_id']}");
									 if ($Read->getResult()):
									 $emb = $Read->getResult()[0];
									 endif;
									 
					$Read->ExeRead("mdp_reserva"," WHERE set_embarque_id = :id AND year(reserva_date) = year(NOW()) AND month(reserva_date) = month(NOW()) AND day(reserva_date) = day(NOW()) AND order_id = :u ORDER BY acento_id ASC", "id={$set_embarque_id}&u={$order_id}");
			if($Read->getResult()):
			foreach($Read->getResult() as $acento):			  	
                              
     ?>
     
   <div class='row' style='width:400px;background: linear-gradient(to right, #05c2f9,#0E96E5);'>
    <div class='center-align col s12' style='padding:10% 10% 2% 10%;'>
         <img style='width:100px;height:100px;'src='<?= INCLUDE_PATH ."/img/logo/logo-2.png";?>'>
    </div>
      <div class='center-align col s12'>
          <h4 style='color:#fff;'>COMPROVANTE</h4>
          <h1 style='color:#fff;margin-top:-10px'><b>#<?= str_pad($OId, 7, 0, 0);?></b></h1>
     </div>
       
               <div class='center-align col s12  '>
         
          <div class='row center-align col s12 ' style='margin:20px auto;background: linear-gradient(to right, #FbFbFb,#FbFbFb);'>
                 <table  class='centered'>
      
        <thead>
          <tr>
              
              <th>Origem</th>
              <th>Destino</th>
                <th>Status</th>
          </tr>
        </thead>
        <tbody>
           <tr style='background:#fff'>
        
            <td><?= $embs['cidade_nome'];?><br/>(<b><?= $embs['cidade_uf'];?></b>)</td>
            <td><?= $emb['cidade_nome'];?> <br/>(<b><?= $emb['cidade_uf'];?></b>)</td>
            <td style='color:green'><b>Pago<br/>(<?= getOrderPayment($order_payment);?>)<b>--></td>
          </tr>
        </tbody>
        </table>
        
          <table class='centered'>
      
        <thead>
         <tr>
        
              
              <th>Ponto<br/>(<b>Embarque</b>)</th>
              <th>Ponto<br/>(<b>Desembarque</b>)</th>
              <th>Data<br/>(<b>Agendada</b>)</th>
          </tr>
        </thead>

        <tbody>
          <tr style='background:#fff'>
          <td><?= $embks['embarque_title'];?>--></td>
            <td><?= $embk['embarque_title'];?>--></td>
            <td><!--<b><?= date('d/m/Y', strtotime($order_date));?><b>--></td>
          </tr>
        </tbody>
         <thead>
          <tr style='background:#f5f5f5'>
        
              
              <th>Horario</th>
              <th>Duração</th>
               <th>Status<br/><b>(Billet)</b></th>
          </tr>
          </thead>
           <tbody>
          <tr style='background:#fff'>
          <td><!--<b><?= $set_embarque_tempo;?> Horas<b>--></td>
            <td><!--<b><?= $set_embarque_time;?> Horas<b>--></td>
            <td><!--<b><?= ($acento['reserva_status'] == 1 ? "Inválido<br/>(<b style='color:red;'>Negado</b>)" : "Válido<br/>(<b style='color:green;'>Liberado</b>)");?><b>--></td>
        </tr>
        </tbody>
         <thead>
         <tr style='background:#f5f5f5'>
        
              
              <th>Acento</th>
               <th>Pedido<br/>(<b>Total</b>)</th>
               <th>Valor<br/>(<b>Unitario</b>)</th>
          </tr>
         
         </thead>
           <tbody>
          <tr style='background:#fff'>
          <td><!--<b><?= $acento['acento_id'];?><b>--></td>
            <td>R$: <b><?= number_format($order_price,2,',','.');?><b>--></td>
            <td>R$: <b style='color:green'><?= number_format($set_embarque_price,2,',','.');?><b>--></td>
        
          </tr>
        </tbody>
       
      </table>
       <div id='qrcode<?= $acento['acento_id'];?>' style='background:#f5f5f5;padding:auto;padding:10% 5% 10% 15%;' class='center-align'  ></div>
     
            
       </div>
          <h5 style='color:#fff;padding-bottom:10px'><B><?= SITE_ADDR_SITE;?></B></h5>
           
          
    
      <h6 style='color:#fff;margin-top:15px;border-top:1px #fff solid;padding-bottom:10px;'><br/> <B>MDP SOFTWARES LTDA<br/></b></h6>
         
     </div>
    </div>
     <script src="<?= BASE;?>/_cdn/widgets/account/qrcode.js"></script>
    <script src="<?= BASE; ?>/_cdn/jspdf.min.js"></script>   
      <script type="text/javascript">
      $('h6').css({'background':'red'});
new QRCode(document.getElementById("qrcode<?= $acento['acento_id'];?>"), "<?= BASE;?>/login/dashboard.php?wc=home&orid=<?= $OId;?>&acnt=<?= $acento['reserva_id'];?>");

            $(function(){
                var pdf = new jsPDF({
                    orientation: 'portrait'
                });
                pdf.addHTML($('.row'), function(){
                
                    //pdf.output('datauri');
                    pdf.save("Comprovante-embarque-ref-<?= str_pad($OId, 7, 0, 0); ?>.pdf");

                   
                    //window.close();
                    //window.history.back();
                });
            });
            
        
        </script>
    
     <?php     
     endforeach;
     endif;
     else:
        ?>
                   <script>alert('Ops, algo deu errado. Tente novamente mais tarde...');window.location.href="<?=$url?>";</script>
                 <?php     
             
                 endif;
    endif;
         
     endif;



endif;
?>

<!--JavaScript at end of body for optimized loading-->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
*/?>
     </body>
  </html>